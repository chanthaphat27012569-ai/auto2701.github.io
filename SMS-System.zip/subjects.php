<?php

require_once __DIR__ . '/includes/bootstrap.php';

$user = require_staff();
$pdo = db();

$errors = [];
$form = [
    'id' => 0,
    'code' => '',
    'name' => '',
    'category' => '',
    'department' => '',
    'hours' => '40',
    'credits' => '1.0',
    'status' => 'active',
];
$showForm = get_str('new') === '1' || get_int('edit') > 0;

if (get_int('edit') > 0) {
    $stmt = $pdo->prepare('SELECT * FROM subjects WHERE id = ?');
    $stmt->execute([get_int('edit')]);
    $row = $stmt->fetch();
    if ($row) {
        $form = array_merge($form, $row);
        $form['id'] = (int) $row['id'];
    }
}

if (is_post()) {
    verify_csrf();
    require_manage();
    $action = post_str('action');

    if ($action === 'delete') {
        $deleteId = (int) ($_POST['subject_id'] ?? 0);
        $stmt = $pdo->prepare('SELECT code, name FROM subjects WHERE id = ?');
        $stmt->execute([$deleteId]);
        $existing = $stmt->fetch();
        if ($existing) {
            $del = $pdo->prepare('DELETE FROM subjects WHERE id = ?');
            $del->execute([$deleteId]);
            flash('success', 'ลบรายวิชา ' . $existing['code'] . ' ' . $existing['name'] . ' เรียบร้อยแล้ว');
        } else {
            flash('danger', 'ไม่พบรายวิชาที่ต้องการลบ');
        }
        redirect('subjects.php');
    }

    if ($action === 'save') {
        foreach (['code', 'name', 'category', 'department', 'hours', 'credits'] as $key) {
            $form[$key] = post_str($key);
        }
        $form['status'] = post_str('status') === 'inactive' ? 'inactive' : 'active';

        if ($form['code'] === '') {
            $errors['code'] = 'กรุณากรอกรหัสวิชา';
        }
        if ($form['name'] === '') {
            $errors['name'] = 'กรุณากรอกชื่อรายวิชา';
        }
        if (!is_numeric($form['hours']) || (int) $form['hours'] < 0) {
            $errors['hours'] = 'ชั่วโมงเรียนต้องเป็นตัวเลข';
        }
        if (!is_numeric($form['credits']) || (float) $form['credits'] < 0) {
            $errors['credits'] = 'หน่วยกิตต้องเป็นตัวเลข';
        }
        if (!$errors) {
            $stmt = $pdo->prepare('SELECT id FROM subjects WHERE code = ? AND id <> ? LIMIT 1');
            $stmt->execute([$form['code'], $form['id']]);
            if ($stmt->fetch()) {
                $errors['code'] = 'มีรหัสวิชานี้อยู่แล้ว';
            }
        }
        if (!$errors) {
            if ($form['id'] > 0) {
                $stmt = $pdo->prepare('UPDATE subjects SET code=?, name=?, category=?, department=?, hours=?, credits=?, status=? WHERE id=?');
                $stmt->execute([$form['code'], $form['name'], $form['category'], $form['department'], (int) $form['hours'], (float) $form['credits'], $form['status'], $form['id']]);
                flash('success', 'บันทึกรายวิชา ' . $form['code'] . ' เรียบร้อยแล้ว');
            } else {
                $stmt = $pdo->prepare('INSERT INTO subjects (code, name, category, department, hours, credits, status) VALUES (?,?,?,?,?,?,?)');
                $stmt->execute([$form['code'], $form['name'], $form['category'], $form['department'], (int) $form['hours'], (float) $form['credits'], $form['status']]);
                flash('success', 'เพิ่มรายวิชา ' . $form['code'] . ' เรียบร้อยแล้ว');
            }
            redirect('subjects.php');
        }
        $showForm = true;
    }
}

$search = get_str('q');
$statusFilter = get_str('status');
$where = [];
$params = [];
if ($search !== '') {
    $where[] = '(code LIKE ? OR name LIKE ? OR department LIKE ?)';
    $like = '%' . $search . '%';
    array_push($params, $like, $like, $like);
}
if (in_array($statusFilter, ['active', 'inactive'], true)) {
    $where[] = 'status = ?';
    $params[] = $statusFilter;
}
$whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';
$stmt = $pdo->prepare("SELECT s.*,
        (SELECT COUNT(*) FROM grades g WHERE g.subject_id = s.id) AS grade_rows
    FROM subjects s $whereSql ORDER BY s.code");
$stmt->execute($params);
$subjects = $stmt->fetchAll();

$statsStmt = $pdo->query("SELECT COUNT(*) AS total, SUM(status = 'active') AS active,
    SUM(hours) AS hours, SUM(credits) AS credits FROM subjects");
$stats = $statsStmt->fetch() ?: ['total' => 0, 'active' => 0, 'hours' => 0, 'credits' => 0];

$pageTitle = 'รายวิชา';
$pageSubtitle = 'โครงสร้างหลักสูตร ชั่วโมงเรียน และหน่วยกิต';
$activeNav = 'subjects';
$pageActions = can_manage() ? '<a class="btn btn-primary btn-sm" href="' . url('subjects.php?new=1') . '">' . icon('plus', 16) . '<span>เพิ่มรายวิชา</span></a>' : '';

require_once __DIR__ . '/includes/header.php';
?>

<section class="stat-grid mb-3">
  <article class="stat-card" style="--accent:#4f46e5;--accent-soft:#eef2ff;--i:0">
    <div class="stat-icon"><?= icon('book', 22) ?></div>
    <div class="stat-value num" data-count="<?= (int) $stats['total'] ?>">0</div>
    <div class="stat-label">รายวิชาทั้งหมด</div>
    <div class="stat-foot"><span class="stat-trend up"><?= icon('check-circle', 12) ?><?= (int) $stats['active'] ?> เปิดสอน</span></div>
  </article>
  <article class="stat-card" style="--accent:#7c3aed;--accent-soft:#f5f3ff;--i:1">
    <div class="stat-icon"><?= icon('clock', 22) ?></div>
    <div class="stat-value num" data-count="<?= (int) $stats['hours'] ?>">0</div>
    <div class="stat-label">ชั่วโมงเรียนรวม</div>
    <div class="stat-foot"><span class="stat-trend neutral"><?= icon('calendar', 12) ?> ชั่วโมง / ปี</span></div>
  </article>
  <article class="stat-card" style="--accent:#0ea5e9;--accent-soft:#e0f2fe;--i:2">
    <div class="stat-icon"><?= icon('award', 22) ?></div>
    <div class="stat-value num" data-count="<?= round((float) $stats['credits'], 1) ?>" data-decimals="1">0</div>
    <div class="stat-label">หน่วยกิตรวม</div>
    <div class="stat-foot"><span class="stat-trend neutral"><?= icon('book', 12) ?> หลักสูตรปัจจุบัน</span></div>
  </article>
  <article class="stat-card" style="--accent:#10b981;--accent-soft:#ecfdf5;--i:3">
    <div class="stat-icon"><?= icon('chart', 22) ?></div>
    <div class="stat-value num" data-count="<?= count($subjects) ?>">0</div>
    <div class="stat-label">รายวิชาที่แสดงผล</div>
    <div class="stat-foot"><span class="stat-trend neutral"><?= icon('filter', 12) ?> ตามตัวกรอง</span></div>
  </article>
</section>

<?php if ($showForm): ?>
<section class="card mb-3 animate-pop">
  <div class="card-head bordered">
    <div>
      <h3 class="card-title"><?= icon($form['id'] > 0 ? 'edit' : 'plus', 19) ?> <?= $form['id'] > 0 ? 'แก้ไขรายวิชา' : 'เพิ่มรายวิชาใหม่' ?></h3>
      <p class="card-sub">ข้อมูลรหัสวิชา กลุ่มสาระ หน่วยกิต และชั่วโมงเรียน</p>
    </div>
    <div class="card-actions"><a class="btn btn-ghost btn-sm" href="<?= url('subjects.php') ?>"><?= icon('x', 15) ?> ปิด</a></div>
  </div>
  <div class="card-body">
    <form method="post" action="<?= url('subjects.php') ?>">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="save">
      <input type="hidden" name="id" value="<?= (int) $form['id'] ?>">
      <div class="form-grid">
        <div class="field">
          <label>รหัสวิชา <span class="req">*</span></label>
          <input class="input <?= isset($errors['code']) ? 'is-invalid' : '' ?>" type="text" name="code" value="<?= e($form['code']) ?>" placeholder="เช่น ท23101" required>
          <?php if (isset($errors['code'])): ?><span class="field-error"><?= e($errors['code']) ?></span><?php endif; ?>
        </div>
        <div class="field">
          <label>ชื่อรายวิชา <span class="req">*</span></label>
          <input class="input <?= isset($errors['name']) ? 'is-invalid' : '' ?>" type="text" name="name" value="<?= e($form['name']) ?>" placeholder="เช่น ภาษาไทย 3" required>
          <?php if (isset($errors['name'])): ?><span class="field-error"><?= e($errors['name']) ?></span><?php endif; ?>
        </div>
        <div class="field">
          <label>กลุ่มสาระ / หมวดวิชา</label>
          <input class="input" type="text" name="category" value="<?= e($form['category']) ?>" placeholder="เช่น ภาษาไทย">
        </div>
        <div class="field">
          <label>ฝ่าย / กลุ่มงาน</label>
          <input class="input" type="text" name="department" value="<?= e($form['department']) ?>" placeholder="เช่น กลุ่มสาระการเรียนรู้ภาษาไทย">
        </div>
        <div class="field">
          <label>ชั่วโมงเรียน</label>
          <input class="input <?= isset($errors['hours']) ? 'is-invalid' : '' ?>" type="number" name="hours" min="0" max="999" value="<?= e($form['hours']) ?>">
          <?php if (isset($errors['hours'])): ?><span class="field-error"><?= e($errors['hours']) ?></span><?php endif; ?>
        </div>
        <div class="field">
          <label>หน่วยกิต</label>
          <input class="input <?= isset($errors['credits']) ? 'is-invalid' : '' ?>" type="number" name="credits" min="0" max="9" step="0.5" value="<?= e($form['credits']) ?>">
          <?php if (isset($errors['credits'])): ?><span class="field-error"><?= e($errors['credits']) ?></span><?php endif; ?>
        </div>
        <div class="field">
          <label>สถานะ</label>
          <select class="select" name="status">
            <option value="active" <?= $form['status'] === 'active' ? 'selected' : '' ?>>เปิดสอน</option>
            <option value="inactive" <?= $form['status'] === 'inactive' ? 'selected' : '' ?>>ไม่ใช้งาน</option>
          </select>
        </div>
      </div>
      <div class="form-actions">
        <button class="btn btn-primary" type="submit"><?= icon('save', 17) ?> บันทึกรายวิชา</button>
        <a class="btn btn-ghost" href="<?= url('subjects.php') ?>">ยกเลิก</a>
      </div>
    </form>
  </div>
</section>
<?php endif; ?>

<form class="toolbar" method="get" action="<?= url('subjects.php') ?>">
  <div class="toolbar-left">
    <div class="searchbox">
      <?= icon('search', 17) ?>
      <input class="input" type="search" name="q" value="<?= e($search) ?>" placeholder="ค้นหารหัสวิชา ชื่อวิชา หรือกลุ่มสาระ…">
    </div>
    <select class="select" name="status">
      <option value="">ทุกสถานะ</option>
      <option value="active" <?= $statusFilter === 'active' ? 'selected' : '' ?>>เปิดสอน</option>
      <option value="inactive" <?= $statusFilter === 'inactive' ? 'selected' : '' ?>>ไม่ใช้งาน</option>
    </select>
    <button class="btn btn-primary btn-sm" type="submit"><?= icon('filter', 15) ?> กรองข้อมูล</button>
    <?php if ($where): ?><a class="btn btn-ghost btn-sm" href="<?= url('subjects.php') ?>"><?= icon('refresh', 15) ?> ล้าง</a><?php endif; ?>
  </div>
</form>

<div class="table-wrap">
  <table class="table">
    <thead>
      <tr>
        <th>รหัสวิชา</th>
        <th>ชื่อรายวิชา</th>
        <th>กลุ่มสาระ</th>
        <th class="text-right">ชั่วโมง</th>
        <th class="text-right">หน่วยกิต</th>
        <th>สถานะ</th>
        <th class="text-right">จัดการ</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach ($subjects as $subject): ?>
      <tr>
        <td><span class="doc-no"><?= e($subject['code']) ?></span></td>
        <td>
          <b style="font-weight:700"><?= e($subject['name']) ?></b>
          <div class="text-xs text-muted"><?= e($subject['department'] ?: '—') ?></div>
        </td>
        <td><span class="badge badge-violet"><?= e($subject['category'] ?: 'ทั่วไป') ?></span></td>
        <td class="text-right num"><?= (int) $subject['hours'] ?></td>
        <td class="text-right num"><b><?= number_format((float) $subject['credits'], 1) ?></b></td>
        <td>
          <span class="badge badge-<?= $subject['status'] === 'active' ? 'success' : 'muted' ?>"><span class="dot"></span><?= $subject['status'] === 'active' ? 'เปิดสอน' : 'ไม่ใช้งาน' ?></span>
        </td>
        <td>
          <div class="cell-actions">
            <a class="icon-btn" href="<?= url('gradebook.php?subject_id=' . (int) $subject['id']) ?>" title="บันทึกผลการเรียน"><?= icon('edit', 16) ?></a>
            <?php if (can_manage()): ?>
              <a class="icon-btn" href="<?= url('subjects.php?edit=' . (int) $subject['id']) ?>" title="แก้ไข"><?= icon('settings', 16) ?></a>
              <form method="post" action="<?= url('subjects.php') ?>" data-confirm="ต้องการลบรายวิชา <?= e($subject['code'] . ' ' . $subject['name']) ?> ใช่หรือไม่? คะแนนและเกรดที่เกี่ยวข้องจะถูกลบด้วย">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="subject_id" value="<?= (int) $subject['id'] ?>">
                <button class="icon-btn danger" type="submit" title="ลบ"><?= icon('trash', 16) ?></button>
              </form>
            <?php endif; ?>
          </div>
        </td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$subjects): ?>
      <tr><td colspan="7">
        <div class="empty-state">
          <div class="empty-ico"><?= icon('book', 30) ?></div>
          <h3>ไม่พบรายวิชา</h3>
          <p>ลองปรับเงื่อนไขการค้นหา หรือเพิ่มรายวิชาใหม่</p>
          <?php if (can_manage()): ?><a class="btn btn-primary btn-sm" href="<?= url('subjects.php?new=1') ?>"><?= icon('plus', 15) ?> เพิ่มรายวิชา</a><?php endif; ?>
        </div>
      </td></tr>
    <?php endif; ?>
    </tbody>
  </table>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
