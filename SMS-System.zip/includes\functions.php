<?php

function e(?string $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function url(string $path = ''): string
{
    return BASE_URL . '/' . ltrim($path, '/');
}

function redirect(string $path): void
{
    header('Location: ' . url($path));
    exit;
}

function is_post(): bool
{
    return ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST';
}

function flash(string $type, string $message): void
{
    $_SESSION['flashes'][] = ['type' => $type, 'message' => $message];
}

function pull_flashes(): array
{
    $items = $_SESSION['flashes'] ?? [];
    unset($_SESSION['flashes']);
    return $items;
}

function post_str(string $key, string $default = ''): string
{
    return trim((string) ($_POST[$key] ?? $default));
}

function get_str(string $key, string $default = ''): string
{
    return trim((string) ($_GET[$key] ?? $default));
}

function get_int(string $key, int $default = 0): int
{
    return (int) ($_GET[$key] ?? $default);
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="_token" value="' . e(csrf_token()) . '">';
}

function verify_csrf(): void
{
    $token = (string) ($_POST['_token'] ?? '');
    if ($token === '' || !hash_equals((string) ($_SESSION['csrf_token'] ?? ''), $token)) {
        http_response_code(419);
        exit('คำขอไม่ถูกต้องหรือหมดอายุ กรุณากลับไปลองใหม่อีกครั้ง');
    }
}

const THAI_MONTHS = [
    1 => 'มกราคม', 'กุมภาพันธ์', 'มีนาคม', 'เมษายน', 'พฤษภาคม', 'มิถุนายน',
    'กรกฎาคม', 'สิงหาคม', 'กันยายน', 'ตุลาคม', 'พฤศจิกายน', 'ธันวาคม',
];
const THAI_MONTHS_SHORT = [
    1 => 'ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.',
    'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.',
];
const THAI_DAYS = ['อาทิตย์', 'จันทร์', 'อังคาร', 'พุธ', 'พฤหัสบดี', 'ศุกร์', 'เสาร์'];

function thai_date(?string $date, string $style = 'full'): string
{
    if (!$date || str_starts_with($date, '0000')) {
        return '—';
    }
    try {
        $dt = new DateTime(strlen($date) > 10 ? $date : $date . ' 00:00:00');
    } catch (Exception $e) {
        return $date;
    }
    $d = (int) $dt->format('j');
    $m = (int) $dt->format('n');
    $y = (int) $dt->format('Y') + 543;
    if ($style === 'short') {
        return $d . ' ' . THAI_MONTHS_SHORT[$m] . ' ' . substr((string) $y, -2);
    }
    $text = $d . ' ' . THAI_MONTHS[$m] . ' ' . $y;
    if ($style === 'day') {
        $text = 'วัน' . THAI_DAYS[(int) $dt->format('w')] . 'ที่ ' . $text;
    }
    return $text;
}

function thai_datetime(?string $datetime, bool $short = false): string
{
    if (!$datetime || str_starts_with($datetime, '0000')) {
        return '—';
    }
    try {
        $dt = new DateTime($datetime);
    } catch (Exception $e) {
        return $datetime;
    }
    return thai_date($dt->format('Y-m-d'), $short ? 'short' : 'full')
        . ' · ' . $dt->format('H:i') . ' น.';
}

function attendance_meta(): array
{
    return [
        'present'  => ['label' => 'มาเรียน', 'short' => 'ม', 'class' => 'present'],
        'late'     => ['label' => 'มาสาย', 'short' => 'ส', 'class' => 'late'],
        'sick'     => ['label' => 'ลาป่วย', 'short' => 'ป', 'class' => 'sick'],
        'business' => ['label' => 'ลากิจ', 'short' => 'ก', 'class' => 'business'],
        'absent'   => ['label' => 'ขาดเรียน', 'short' => 'ข', 'class' => 'absent'],
        'truant'   => ['label' => 'หนีเรียน', 'short' => 'ห', 'class' => 'truant'],
    ];
}

function attendance_rate(array $counts): float
{
    $total = array_sum($counts);
    if ($total <= 0) {
        return 0.0;
    }
    return (($counts['present'] ?? 0) + ($counts['late'] ?? 0)) / $total * 100;
}

function grade_from_score($score): string
{
    if ($score === null || $score === '' || !is_numeric($score)) {
        return '—';
    }
    $score = (float) $score;
    if ($score >= 80) return '4.0';
    if ($score >= 75) return '3.5';
    if ($score >= 70) return '3.0';
    if ($score >= 65) return '2.5';
    if ($score >= 60) return '2.0';
    if ($score >= 55) return '1.5';
    if ($score >= 50) return '1.0';
    return '0.0';
}

function grade_point(string $grade): float
{
    return is_numeric($grade) ? (float) $grade : 0.0;
}

function gpa_from_grades(array $grades): float
{
    $points = [];
    foreach ($grades as $grade) {
        if (is_numeric($grade)) {
            $points[] = (float) $grade;
        }
    }
    return $points ? array_sum($points) / count($points) : 0.0;
}

function grade_class(string $grade): string
{
    return match ($grade) {
        '4.0' => 'g4',
        '3.5' => 'g35',
        '3.0' => 'g3',
        '2.5' => 'g25',
        '2.0' => 'g2',
        '1.5' => 'g15',
        '1.0' => 'g1',
        default => 'g0',
    };
}

function doc_types(): array
{
    return [
        'pp1' => ['label' => 'ปพ.1', 'name' => 'ทะเบียนนักเรียน', 'icon' => 'clipboard'],
        'pp2' => ['label' => 'ปพ.2', 'name' => 'ระเบียนสะสม', 'icon' => 'book'],
        'pp3' => ['label' => 'ปพ.3', 'name' => 'ระเบียนแสดงผลการเรียน', 'icon' => 'chart'],
        'pp4' => ['label' => 'ปพ.4', 'name' => 'หนังสือรับรองการเป็นนักเรียน', 'icon' => 'award'],
        'pp5' => ['label' => 'ปพ.5', 'name' => 'แบบรายงานผลการเรียน', 'icon' => 'file'],
        'pp6' => ['label' => 'ปพ.6', 'name' => 'สมุดรายงานประจำตัวนักเรียน', 'icon' => 'file'],
        'pp7' => ['label' => 'ปพ.7', 'name' => 'ใบรับรองผลการศึกษา', 'icon' => 'award'],
        'pp8' => ['label' => 'ปพ.8', 'name' => 'ระเบียนผลการเรียน', 'icon' => 'file'],
        'pp9' => ['label' => 'ปพ.9', 'name' => 'หนังสือรับรองการจบการศึกษา', 'icon' => 'graduation'],
    ];
}

function doc_type(string $key): array
{
    $types = doc_types();
    return $types[$key] ?? ['label' => strtoupper($key), 'name' => 'เอกสารทางการศึกษา', 'icon' => 'file'];
}

function student_name(array $student, bool $withPrefix = true): string
{
    $name = trim(($student['firstname'] ?? '') . ' ' . ($student['lastname'] ?? ''));
    return $withPrefix ? trim(($student['prefix'] ?? '') . $name) : $name;
}

function name_initials(string $firstname, string $lastname = ''): string
{
    $first = $firstname !== '' ? mb_substr($firstname, 0, 1, 'UTF-8') : '?';
    $last = $lastname !== '' ? mb_substr($lastname, 0, 1, 'UTF-8') : '';
    return $first . $last;
}

function fullname_initials(string $fullname): string
{
    $clean = preg_replace('/^(ดร\.|นางสาว|นาง|นาย|Mr\.|Mrs\.|Ms\.|ครู)\s*/u', '', trim($fullname));
    $parts = preg_split('/\s+/u', (string) $clean, -1, PREG_SPLIT_NO_EMPTY);
    return name_initials($parts[0] ?? '?', $parts[1] ?? '');
}

function avatar_class(string $seed): string
{
    $index = abs(crc32($seed)) % 8;
    return 'av-' . $index;
}

function student_status_meta(): array
{
    return [
        'studying'    => ['label' => 'กำลังศึกษา', 'class' => 'success'],
        'graduated'   => ['label' => 'จบการศึกษา', 'class' => 'info'],
        'transferred' => ['label' => 'ย้ายสถานศึกษา', 'class' => 'warning'],
        'inactive'    => ['label' => 'พ้นสภาพ', 'class' => 'muted'],
    ];
}

function portal_tables_ready(): bool
{
    static $ready = null;
    if ($ready !== null) {
        return $ready;
    }
    try {
        $ready = (bool) db()->query("SHOW TABLES LIKE 'student_profiles'")->fetchColumn();
    } catch (Throwable $e) {
        $ready = false;
    }
    return $ready;
}

function student_profile_defaults(): array{
    $profile = ['student_id' => 0];
    $columns = [
        'avatar', 'portal_hash', 'nickname', 'prefix_en', 'firstname_en', 'lastname_en', 'phone',
        'birth_province', 'ethnicity', 'parent_marital_status',
        'brothers_older', 'sisters_older', 'brothers_younger', 'sisters_younger', 'birth_order', 'siblings_studying',
        'father_citizen_id', 'father_prefix', 'father_firstname', 'father_lastname', 'father_occupation', 'father_income', 'father_phone',
        'mother_citizen_id', 'mother_prefix', 'mother_firstname', 'mother_lastname', 'mother_occupation', 'mother_income', 'mother_phone',
        'guardian_citizen_id', 'guardian_relation',
        'plan', 'application_no', 'student_type', 'gpa', 'gpax_p6', 'gpax_junior',
        'registered_house_code', 'registered_house_no', 'registered_moo', 'registered_road',
        'registered_subdistrict', 'registered_district', 'registered_province', 'registered_postcode',
        'current_house_code', 'current_house_no', 'current_moo', 'current_road',
        'current_subdistrict', 'current_district', 'current_province', 'current_postcode',
        'weight', 'height', 'accommodation', 'travel_method', 'travel_minutes',
        'distance_dirt', 'distance_asphalt', 'distance_water',
        'shortage_uniform', 'shortage_stationery', 'shortage_books', 'shortage_lunch',
        'disability', 'updated_at',
    ];
    foreach ($columns as $column) {
        $profile[$column] = '';
    }
    return $profile;
}

function student_profile(int $studentId, bool $refresh = false): array
{
    static $cache = [];
    if (!$refresh && isset($cache[$studentId])) {
        return $cache[$studentId];
    }
    $profile = student_profile_defaults();
    $profile['student_id'] = $studentId;
    if ($studentId > 0) {
        try {
            $stmt = db()->prepare('SELECT * FROM student_profiles WHERE student_id = ? LIMIT 1');
            $stmt->execute([$studentId]);
            $row = $stmt->fetch();
            if ($row) {
                $profile = array_merge($profile, $row);
            }
        } catch (Throwable $e) {
            // ฐานข้อมูลรุ่นเก่าที่ยังไม่ได้นำเข้า student-portal.sql
        }
    }
    $cache[$studentId] = $profile;
    return $profile;
}

function student_avatar_url(array $student): string
{
    $profile = $student['profile'] ?? student_profile((int) ($student['id'] ?? 0));
    $avatar = trim((string) ($profile['avatar'] ?? ($student['avatar'] ?? '')));
    if ($avatar === '') {
        return '';
    }
    $avatar = ltrim(str_replace('\\', '/', $avatar), '/');
    if (str_contains($avatar, '..') || !preg_match('#^[A-Za-z0-9_\-./]+$#', $avatar)) {
        return '';
    }
    return url($avatar);
}

function student_avatar(array $student, string $class = ''): string
{
    $classes = trim('avatar ' . $class);
    $url = student_avatar_url($student);
    if ($url !== '') {
        return '<span class="' . e($classes) . ' avatar-photo"><img src="' . e($url) . '" alt="' . e(student_name($student, false)) . '" loading="lazy"></span>';
    }
    $seed = (string) ($student['firstname'] ?? '');
    return '<span class="' . e($classes) . ' ' . avatar_class($seed) . '">'
        . e(name_initials((string) ($student['firstname'] ?? ''), (string) ($student['lastname'] ?? '')))
        . '</span>';
}

function activity_status_meta(): array
{
    return [
        'present' => ['label' => 'เข้าร่วม', 'class' => 'success'],
        'late'    => ['label' => 'มาสาย', 'class' => 'warning'],
        'leave'   => ['label' => 'ลา', 'class' => 'info'],
        'absent'  => ['label' => 'ไม่เข้าร่วม', 'class' => 'danger'],
        'truant'  => ['label' => 'หนีกิจกรรม', 'class' => 'danger'],
    ];
}

function student_age(?string $birthDate): string
{
    if (!$birthDate || str_starts_with($birthDate, '0000')) {
        return '—';
    }
    try {
        $birth = new DateTime($birthDate);
        $diff = $birth->diff(new DateTime('today'));
        return $diff->y . ' ปี';
    } catch (Exception $e) {
        return '—';
    }
}

function behavior_score_meta(int $score): array
{
    if ($score >= 90) {
        return ['label' => 'ดีมาก', 'class' => 'success', 'color' => '#10b981'];
    }
    if ($score >= 80) {
        return ['label' => 'ดี', 'class' => 'info', 'color' => '#3b82f6'];
    }
    if ($score >= 60) {
        return ['label' => 'พอใช้', 'class' => 'warning', 'color' => '#f59e0b'];
    }
    return ['label' => 'ควรปรับปรุง', 'class' => 'danger', 'color' => '#ef4444'];
}

function role_label(string $role): string
{
    return match ($role) {
        'admin' => 'ผู้ดูแลระบบ',
        'director' => 'ผู้อำนวยการ',
        'deputy' => 'รองผู้อำนวยการ',
        'registrar' => 'นายทะเบียน',
        'teacher' => 'ครูผู้สอน',
        'staff' => 'เจ้าหน้าที่',
        default => $role,
    };
}

function role_options(): array
{
    return [
        'admin' => 'ผู้ดูแลระบบ',
        'director' => 'ผู้อำนวยการ',
        'deputy' => 'รองผู้อำนวยการ',
        'registrar' => 'นายทะเบียน',
        'teacher' => 'ครูผู้สอน',
        'staff' => 'เจ้าหน้าที่',
    ];
}

function academic_context(array $school): array
{
    return [
        'year' => (string) ($school['academic_year'] ?? '2569'),
        'semester' => (int) ($school['semester'] ?? 1),
    ];
}

function format_number($number, int $decimals = 0): string
{
    return number_format((float) $number, $decimals);
}

function percent_text(float $value, int $decimals = 1): string
{
    return number_format($value, $decimals) . '%';
}

function school_logo_svg(int $size = 44, string $class = ''): string
{
    return '<svg class="' . e($class) . '" width="' . $size . '" height="' . $size . '" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
  <defs><linearGradient id="smsLogoGrad" x1="0" y1="0" x2="100" y2="100" gradientUnits="userSpaceOnUse"><stop stop-color="#6366F1"/><stop offset="1" stop-color="#8B5CF6"/></linearGradient></defs>
  <rect width="100" height="100" rx="26" fill="url(#smsLogoGrad)"/>
  <path d="M50 14L18 35V79C18 81.2 19.8 83 22 83H78C80.2 83 82 81.2 82 79V35L50 14Z" fill="#FDE68A"/>
  <path d="M50 14L82 35H18L50 14Z" fill="#F59E0B"/>
  <circle cx="50" cy="41" r="10" fill="#FFFFFF"/><circle cx="50" cy="41" r="7.6" fill="#F8FAFC"/>
  <line x1="50" y1="41" x2="50" y2="35" stroke="#4F46E5" stroke-width="2" stroke-linecap="round"/>
  <line x1="50" y1="41" x2="54.6" y2="41" stroke="#EC4899" stroke-width="2" stroke-linecap="round"/>
  <rect x="28" y="57" width="13" height="13" rx="3.5" fill="#38BDF8"/>
  <line x1="34.5" y1="57" x2="34.5" y2="70" stroke="#FFFFFF" stroke-width="1.4"/>
  <line x1="28" y1="63.5" x2="41" y2="63.5" stroke="#FFFFFF" stroke-width="1.4"/>
  <rect x="59" y="57" width="13" height="13" rx="3.5" fill="#38BDF8"/>
  <line x1="65.5" y1="57" x2="65.5" y2="70" stroke="#FFFFFF" stroke-width="1.4"/>
  <line x1="59" y1="63.5" x2="72" y2="63.5" stroke="#FFFFFF" stroke-width="1.4"/>
  <path d="M43 83V66C43 64.3 44.3 63 46 63H54C55.7 63 57 64.3 57 66V83H43Z" fill="#EC4899"/>
  <circle cx="53" cy="74" r="1.8" fill="#FDE047"/>
  <path d="M85 18L87 23L92 24L87 27L85 32L83 27L78 24L83 23L85 18Z" fill="#F43F5E"/>
</svg>';
}

function icon(string $name, int $size = 20, string $class = ''): string
{
    $paths = [
        'dashboard' => '<rect x="3" y="3" width="7" height="9" rx="2"/><rect x="14" y="3" width="7" height="5" rx="2"/><rect x="14" y="12" width="7" height="9" rx="2"/><rect x="3" y="16" width="7" height="5" rx="2"/>',
        'users' => '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
        'user' => '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
        'building' => '<path d="M3 21h18"/><path d="M5 21V7l7-4 7 4v14"/><path d="M9 9h.01M9 13h.01M9 17h.01M15 9h.01M15 13h.01M15 17h.01"/>',
        'book' => '<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2Z"/>',
        'check' => '<path d="M22 11.1V12a10 10 0 1 1-5.93-9.14"/><path d="m9 11 3 3L22 4"/>',
        'chart' => '<path d="M3 3v18h18"/><path d="m7 14 4-4 4 4 5-6"/>',
        'file' => '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="M16 13H8M16 17H8M10 9H8"/>',
        'settings' => '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1Z"/>',
        'shield' => '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"/><path d="m9 12 2 2 4-4"/>',
        'logout' => '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5"/><path d="M21 12H9"/>',
        'plus' => '<path d="M12 5v14M5 12h14"/>',
        'search' => '<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/>',
        'edit' => '<path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z"/>',
        'trash' => '<path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><path d="M10 11v6M14 11v6"/>',
        'eye' => '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/>',
        'arrow-left' => '<path d="M19 12H5"/><path d="m12 19-7-7 7-7"/>',
        'arrow-right' => '<path d="M5 12h14"/><path d="m12 5 7 7-7 7"/>',
        'calendar' => '<rect x="3" y="4" width="18" height="18" rx="3"/><path d="M16 2v4M8 2v4M3 10h18"/>',
        'printer' => '<path d="M6 9V2h12v7"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8" rx="1"/>',
        'download' => '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m7 10 5 5 5-5"/><path d="M12 15V3"/>',
        'graduation' => '<path d="M22 10 12 5 2 10l10 5 10-5Z"/><path d="M6 12v5c0 2 2.5 3 6 3s6-1 6-3v-5"/><path d="M22 10v6"/>',
        'clock' => '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
        'bell' => '<path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/>',
        'menu' => '<path d="M4 6h16M4 12h16M4 18h16"/>',
        'x' => '<path d="M18 6 6 18M6 6l12 12"/>',
        'sparkles' => '<path d="m12 3 1.9 5.8L20 10.7l-6.1 1.9L12 18.4l-1.9-5.8L4 10.7l6.1-1.9Z"/><path d="M19 3v4M21 5h-4M5 17v4M7 19H3"/>',
        'save' => '<path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2Z"/><path d="M17 21v-8H7v8M7 3v5h8"/>',
        'filter' => '<path d="M22 3H2l8 9.5V19l4 2v-8.5Z"/>',
        'chevron-down' => '<path d="m6 9 6 6 6-6"/>',
        'chevron-right' => '<path d="m9 18 6-6-6-6"/>',
        'key' => '<circle cx="7.5" cy="15.5" r="5.5"/><path d="m21 2-9.6 9.6"/><path d="m15.5 7.5 3 3L22 7l-3-3"/>',
        'phone' => '<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.4 2.1L8.1 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2Z"/>',
        'mail' => '<rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 6-10 7L2 6"/>',
        'map-pin' => '<path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/>',
        'award' => '<circle cx="12" cy="8" r="6"/><path d="m9 13-2 9 5-3 5 3-2-9"/>',
        'refresh' => '<path d="M3 12a9 9 0 0 1 15.5-6.4L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-15.5 6.4L3 16"/><path d="M3 21v-5h5"/>',
        'alert' => '<path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0Z"/><path d="M12 9v4M12 17h.01"/>',
        'info' => '<circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/>',
        'clipboard' => '<rect x="8" y="2" width="8" height="4" rx="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><path d="M9 12h6M9 16h6"/>',
        'check-circle' => '<path d="M22 11.1V12a10 10 0 1 1-5.93-9.14"/><path d="m9 11 3 3L22 4"/>',
        'x-circle' => '<circle cx="12" cy="12" r="10"/><path d="m15 9-6 6M9 9l6 6"/>',
        'lock' => '<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
        'home' => '<path d="m3 10 9-7 9 7v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2Z"/><path d="M9 22V12h6v10"/>',
        'star' => '<path d="m12 2 3.1 6.3 6.9 1-5 4.9 1.2 6.8L12 17.7 5.8 21l1.2-6.8-5-4.9 6.9-1Z"/>',
        'trending' => '<path d="m23 6-9.5 9.5-5-5L1 18"/><path d="M17 6h6v6"/>',
        'dot' => '<circle cx="12" cy="12" r="3" fill="currentColor"/>',
    ];
    $inner = $paths[$name] ?? $paths['dot'];
    return '<svg class="ico ' . e($class) . '" width="' . $size . '" height="' . $size . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $inner . '</svg>';
}

function bar_width(float $value, float $max = 100): string
{
    if ($max <= 0) {
        return '0%';
    }
    return max(0, min(100, $value / $max * 100)) . '%';
}

function next_school_day(?string $from = null): string
{
    $date = new DateTime($from ?: 'today');
    do {
        $date->modify('+1 day');
    } while ((int) $date->format('N') >= 6);
    return $date->format('Y-m-d');
}

function prev_school_day(?string $from = null): string
{
    $date = new DateTime($from ?: 'today');
    do {
        $date->modify('-1 day');
    } while ((int) $date->format('N') >= 6);
    return $date->format('Y-m-d');
}

function month_label(string $month): string
{
    $parts = explode('-', $month);
    if (count($parts) !== 2) {
        return $month;
    }
    $m = (int) $parts[1];
    if ($m < 1 || $m > 12) {
        return $month;
    }
    return THAI_MONTHS[$m] . ' ' . ((int) $parts[0] + 543);
}
