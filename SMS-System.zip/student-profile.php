<?php

require_once __DIR__ . '/includes/bootstrap.php';

$portalActive = 'profile';
$pageTitle = 'ข้อมูลส่วนตัว';
$pageSubtitle = 'ข้อมูลทะเบียนและข้อมูลติดต่อของฉัน';
require __DIR__ . '/includes/student-context.php';

$studentId = (int) $student['id'];
$portalTablesReady = portal_tables_ready();
$editMode = get_str('edit') === '1' && !$isPreview;
$errors = [];

$stringFields = [
    'nickname' => 80, 'prefix_en' => 20, 'firstname_en' => 80, 'lastname_en' => 80, 'phone' => 30,
    'birth_province' => 100, 'ethnicity' => 50, 'parent_marital_status' => 50,
    'father_citizen_id' => 20, 'father_prefix' => 20, 'father_firstname' => 80, 'father_lastname' => 80,
    'father_occupation' => 100, 'father_phone' => 30,
    'registered_house_code' => 30, 'registered_house_no' => 30, 'registered_moo' => 10, 'registered_road' => 120,
    'registered_subdistrict' => 80, 'registered_district' => 80, 'registered_province' => 80, 'registered_postcode' => 10,
    'current_house_code' => 30, 'current_house_no' => 30, 'current_moo' => 10, 'current_road' => 120,
    'current_subdistrict' => 80, 'current_district' => 80, 'current_province' => 80, 'current_postcode' => 10,
    'accommodation' => 100, 'travel_method' => 100, 'disability' => 190,
    'shortage_uniform' => 20, 'shortage_stationery' => 20, 'shortage_books' => 20, 'shortage_lunch' => 20,
];
$intFields = ['brothers_older' => 15, 'sisters_older' => 15, 'brothers_younger' => 15, 'sisters_younger' => 15, 'birth_order' => 15, 'siblings_studying' => 15, 'travel_minutes' => 600];
$decimalFields = ['father_income' => 9999999, 'weight' => 300, 'height' => 250, 'distance_dirt' => 999, 'distance_asphalt' => 999, 'distance_water' => 999];

if (is_post() && !$isPreview) {
    verify_csrf();
    $action = post_str('action', 'save_profile');

    if ($action === 'save_avatar') {
        if (!$portalTablesReady) {
            flash('danger', 'ยังไม่ได้นำเข้าฐานข้อมูลพอร์ทัลนักเรียน กรุณาติดต่อเจ้าหน้าที่');
            redirect('student-profile.php');
        }
        if (empty($_FILES['avatar']) || ($_FILES['avatar']['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
            flash('warning', 'กรุณาเลือกไฟล์รูปภาพก่อนอัปโหลด');
            redirect('student-profile.php');
        }
        $file = $_FILES['avatar'];
        if (($file['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK) {
            flash('danger', 'อัปโหลดรูปไม่สำเร็จ กรุณาลองใหม่อีกครั้ง');
            redirect('student-profile.php');
        }
        if ((int) $file['size'] > 2 * 1024 * 1024) {
            flash('danger', 'ไฟล์รูปต้องมีขนาดไม่เกิน 2 MB');
            redirect('student-profile.php');
        }
        $mime = '';
        if (class_exists('finfo')) {
            $mime = (string) (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
        }
        $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
        if (!isset($allowed[$mime]) || @getimagesize($file['tmp_name']) === false) {
            flash('danger', 'รองรับเฉพาะไฟล์ JPG, PNG หรือ WebP');
            redirect('student-profile.php');
        }
        $uploadDir = __DIR__ . '/uploads/avatars';
        if (!is_dir($uploadDir) && !mkdir($uploadDir, 0775, true) && !is_dir($uploadDir)) {
            flash('danger', 'ไม่สามารถสร้างโฟลเดอร์สำหรับเก็บรูปได้');
            redirect('student-profile.php');
        }
        $filename = 'student-' . $studentId . '-' . bin2hex(random_bytes(6)) . '.' . $allowed[$mime];
        if (!move_uploaded_file($file['tmp_name'], $uploadDir . '/' . $filename)) {
            flash('danger', 'บันทึกไฟล์รูปไม่สำเร็จ');
            redirect('student-profile.php');
        }
        try {
            $stmt = $pdo->prepare('INSERT INTO student_profiles (student_id) VALUES (?) ON DUPLICATE KEY UPDATE student_id = student_id');
            $stmt->execute([$studentId]);
            $old = (string) ($profile['avatar'] ?? '');
            $update = $pdo->prepare('UPDATE student_profiles SET avatar = ? WHERE student_id = ?');
            $update->execute(['uploads/avatars/' . $filename, $studentId]);
            $oldPath = __DIR__ . '/' . ltrim(str_replace('\\', '/', $old), '/');
            if ($old !== '' && str_starts_with($old, 'uploads/avatars/') && is_file($oldPath)) {
                @unlink($oldPath);
            }
            flash('success', 'อัปเดตรูปโปรไฟล์เรียบร้อยแล้ว');
        } catch (Throwable $e) {
            @unlink($uploadDir . '/' . $filename);
            flash('danger', 'บันทึกรูปไม่สำเร็จ: ' . $e->getMessage());
        }
        redirect('student-profile.php');
    }

    if ($action === 'remove_avatar') {
        if ($portalTablesReady) {
            try {
                $old = (string) ($profile['avatar'] ?? '');
                $stmt = $pdo->prepare('UPDATE student_profiles SET avatar = "" WHERE student_id = ?');
                $stmt->execute([$studentId]);
                $oldPath = __DIR__ . '/' . ltrim(str_replace('\\', '/', $old), '/');
                if ($old !== '' && str_starts_with($old, 'uploads/avatars/') && is_file($oldPath)) {
                    @unlink($oldPath);
                }
                flash('success', 'ลบรูปโปรไฟล์แล้ว');
            } catch (Throwable $e) {
                flash('danger', 'ลบรูปไม่สำเร็จ');
            }
        }
        redirect('student-profile.php');
    }

    $values = [];
    foreach ($stringFields as $field => $max) {
        $values[$field] = mb_substr(post_str($field), 0, $max, 'UTF-8');
    }
    foreach ($intFields as $field => $max) {
        $values[$field] = max(0, min($max, (int) ($_POST[$field] ?? 0)));
    }
    foreach ($decimalFields as $field => $max) {
        $values[$field] = max(0, min($max, (float) ($_POST[$field] ?? 0)));
    }

    foreach (['phone', 'father_phone'] as $phoneField) {
        if ($values[$phoneField] !== '' && !preg_match('/^[0-9+\-\s()]{6,30}$/', $values[$phoneField])) {
            $errors[] = 'หมายเลขโทรศัพท์ไม่ถูกต้อง';
        }
    }
    foreach (['registered_postcode', 'current_postcode'] as $postalField) {
        if ($values[$postalField] !== '' && !preg_match('/^\d{5}$/', $values[$postalField])) {
            $errors[] = 'รหัสไปรษณีย์ต้องเป็นตัวเลข 5 หลัก';
        }
    }
    if ($values['father_citizen_id'] !== '' && !preg_match('/^\d{13}$/', preg_replace('/\D/', '', $values['father_citizen_id']))) {
        $errors[] = 'เลขประจำตัวประชาชนของบิดาต้องเป็นตัวเลข 13 หลัก';
    }

    if ($errors) {
        $profile = array_merge($profile, $values);
        $editMode = true;
    } else {
        if (!$portalTablesReady) {
            $errors[] = 'ยังไม่ได้นำเข้าฐานข้อมูลพอร์ทัลนักเรียน กรุณาติดต่อเจ้าหน้าที่';
            $editMode = true;
        } else {
            try {
                $stmt = $pdo->prepare('INSERT INTO student_profiles (student_id) VALUES (?) ON DUPLICATE KEY UPDATE student_id = student_id');
                $stmt->execute([$studentId]);
                $columns = array_keys($values);
                $set = implode(', ', array_map(fn($column) => '`' . $column . '` = ?', $columns));
                $params = array_values($values);
                $params[] = $studentId;
                $update = $pdo->prepare('UPDATE student_profiles SET ' . $set . ' WHERE student_id = ?');
                $update->execute($params);
                flash('success', 'บันทึกข้อมูลส่วนตัวเรียบร้อยแล้ว');
                redirect('student-profile.php');
            } catch (Throwable $e) {
                $errors[] = 'บันทึกข้อมูลไม่สำเร็จ: ' . $e->getMessage();
                $profile = array_merge($profile, $values);
                $editMode = true;
            }
        }
    }
}

$completenessFields = ['nickname', 'phone', 'birth_province', 'ethnicity', 'father_firstname', 'mother_firstname', 'registered_province', 'current_province', 'weight', 'height', 'travel_method', 'guardian_relation'];
$filled = 0;
foreach ($completenessFields as $field) {
    if (trim((string) ($profile[$field] ?? '')) !== '' && (string) ($profile[$field] ?? '') !== '0') {
        $filled++;
    }
}
$completeness = (int) round($filled / max(1, count($completenessFields)) * 100);
$genderLabel = $student['gender'] === 'female' ? 'หญิง' : 'ชาย';
$incomeText = fn($value) => (float) $value > 0 ? number_format((float) $value) . ' บาท' : '—';
$fieldValue = fn($key, $default = '—') => trim((string) ($profile[$key] ?? '')) !== '' ? (string) $profile[$key] : $default;
$addressLines = function (string $prefix) use ($profile): array {
    $line1 = trim(implode(' ', array_filter([
        $profile[$prefix . 'house_no'] !== '' ? 'บ้านเลขที่ ' . $profile[$prefix . 'house_no'] : '',
        $profile[$prefix . 'moo'] !== '' ? 'หมู่ ' . $profile[$prefix . 'moo'] : '',
        $profile[$prefix . 'house_code'] !== '' ? '(' . $profile[$prefix . 'house_code'] . ')' : '',
        $profile[$prefix . 'road'] !== '' ? 'ถนน' . $profile[$prefix . 'road'] : '',
    ])));
    $line2 = trim(implode(' ', array_filter([
        $profile[$prefix . 'subdistrict'] !== '' ? 'ตำบล/แขวง' . $profile[$prefix . 'subdistrict'] : '',
        $profile[$prefix . 'district'] !== '' ? 'อำเภอ/เขต' . $profile[$prefix . 'district'] : '',
        $profile[$prefix . 'province'] !== '' ? 'จังหวัด' . $profile[$prefix . 'province'] : '',
        $profile[$prefix . 'postcode'] !== '' ? $profile[$prefix . 'postcode'] : '',
    ])));
    return [$line1 ?: '—', $line2 ?: '—'];
};
[$registeredLine1, $registeredLine2] = $addressLines('registered_');
[$currentLine1, $currentLine2] = $addressLines('current_');

$maritalOptions = ['อยู่ด้วยกัน', 'แยกกันอยู่', 'หย่าร้าง', 'บิดาหรือมารดาเสียชีวิต', 'อื่น ๆ'];
$accommodationOptions = ['บ้านของบิดามารดา', 'บ้านญาติ', 'หอพัก', 'วัด', 'อื่น ๆ'];
$travelOptions = ['เดิน', 'รถจักรยาน', 'รถจักรยานยนต์', 'รถโดยสารประจำทาง', 'รถรับส่ง', 'รถยนต์ส่วนตัว', 'อื่น ๆ'];
$shortageOptions = ['ไม่ขาดแคลน', 'ขาดแคลน'];
$prefixOptions = ['นาย', 'นาง', 'นางสาว', 'ดร.', 'เด็กชาย', 'เด็กหญิง'];

require __DIR__ . '/includes/student-portal-top.php';
?>

<section class="profile-hero-card">
  <?= student_avatar($student, 'xl') ?>
  <div class="profile-hero-info">
    <span class="badge badge-<?= e($statusOfStudent['class']) ?>"><span class="dot"></span><?= e($statusOfStudent['label']) ?></span>
    <h1><?= e(student_name($student)) ?></h1>
    <p><?= e($classText ?: 'ไม่ระบุชั้นเรียน') ?> · เลขที่ <?= (int) $student['student_number'] ?> · รหัส <?= e($student['student_code']) ?></p>
    <div class="profile-chips">
      <span class="chip"><?= icon('user', 13) ?> <?= e($genderLabel) ?></span>
      <span class="chip"><?= icon('calendar', 13) ?> <?= e($student['birth_date'] ? thai_date($student['birth_date']) : 'ไม่ระบุวันเกิด') ?></span>
      <span class="chip"><?= icon('phone', 13) ?> <?= e($fieldValue('phone', $student['guardian_phone'] ?: 'ยังไม่ระบุ')) ?></span>
    </div>
  </div>
  <div class="profile-hero-side">
    <div class="completeness">
      <div class="completeness-head"><span>ความสมบูรณ์ของข้อมูล</span><b><?= $completeness ?>%</b></div>
      <div class="score-meter"><span style="width:<?= $completeness ?>%"></span></div>
    </div>
    <?php if (!$isPreview): ?>
      <?php if ($editMode): ?>
        <a class="btn btn-ghost" href="<?= e(portal_url('student-profile.php')) ?>"><?= icon('arrow-left', 15) ?> กลับหน้าข้อมูล</a>
      <?php else: ?>
        <a class="btn btn-primary" href="<?= e(portal_url('student-profile.php', ['edit' => 1])) ?>"><?= icon('edit', 16) ?> แก้ไขข้อมูล</a>
      <?php endif; ?>
    <?php else: ?>
      <span class="badge badge-muted"><?= icon('eye', 13) ?> โหมดอ่านอย่างเดียว</span>
    <?php endif; ?>
  </div>
</section>

<?php if ($errors): ?>
  <div class="notice notice-danger mb-2"><?= icon('alert', 18) ?><div><?php foreach ($errors as $error): ?><div><?= e($error) ?></div><?php endforeach; ?></div></div>
<?php endif; ?>
<?php if (!$portalTablesReady): ?>
  <div class="notice notice-warning mb-2"><?= icon('alert', 18) ?><div>ยังไม่ได้นำเข้า <code>database/student-portal.sql</code> ข้อมูลส่วนตัวแบบละเอียดจึงยังไม่พร้อมใช้งาน</div></div>
<?php endif; ?>

<?php if (!$editMode): ?>
  <div class="grid grid-1-2 mt-3">
    <div class="stack">
      <article class="card">
        <div class="card-head bordered"><div><h3 class="card-title"><?= icon('user', 19) ?> รูปโปรไฟล์</h3><p class="card-sub">ใช้แสดงในพอร์ทัลนักเรียน</p></div></div>
        <div class="card-body">
          <div class="avatar-manage">
            <?= student_avatar($student, 'xl') ?>
            <?php if (!$isPreview): ?>
              <div class="avatar-manage-body">
                <form method="post" enctype="multipart/form-data" class="avatar-form">
                  <?= csrf_field() ?>
                  <input type="hidden" name="action" value="save_avatar">
                  <input class="input input-sm" type="file" name="avatar" accept="image/jpeg,image/png,image/webp" required>
                  <button type="submit" class="btn btn-soft btn-sm"><?= icon('download', 15) ?> อัปโหลดรูป</button>
                </form>
                <?php if (student_avatar_url($student) !== ''): ?>
                  <form method="post" data-confirm="ต้องการลบรูปโปรไฟล์ปัจจุบันหรือไม่">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="remove_avatar">
                    <button type="submit" class="btn btn-ghost btn-sm"><?= icon('trash', 14) ?> ลบรูป</button>
                  </form>
                <?php endif; ?>
                <small class="field-hint">รองรับ JPG, PNG, WebP ขนาดไม่เกิน 2 MB</small>
              </div>
            <?php endif; ?>
          </div>
        </div>
      </article>

      <article class="card">
        <div class="card-head"><div><h3 class="card-title"><?= icon('graduation', 19) ?> ข้อมูลการเรียน</h3><p class="card-sub">ข้อมูลที่โรงเรียนบันทึก</p></div><div class="card-actions"><span class="badge badge-muted"><?= icon('lock', 12) ?> อ่านอย่างเดียว</span></div></div>
        <div class="card-body" style="padding-top:6px">
          <div class="stack" style="gap:8px">
            <div class="kv-row"><span>แผนการเรียน</span><b><?= e($fieldValue('plan')) ?></b></div>
            <div class="kv-row"><span>เลขที่ใบสมัคร</span><b><?= e($fieldValue('application_no')) ?></b></div>
            <div class="kv-row"><span>ประเภทนักเรียน</span><b><?= e($fieldValue('student_type')) ?></b></div>
            <div class="kv-row"><span>เกรดเฉลี่ยสะสม</span><b><?= $fieldValue('gpa') !== '—' ? number_format((float) $profile['gpa'], 2) : '—' ?></b></div>
            <div class="kv-row"><span>GPAX ป.6</span><b><?= $fieldValue('gpax_p6') !== '—' ? number_format((float) $profile['gpax_p6'], 2) : '—' ?></b></div>
            <div class="kv-row"><span>GPAX ม.ต้น</span><b><?= $fieldValue('gpax_junior') !== '—' ? number_format((float) $profile['gpax_junior'], 2) : '—' ?></b></div>
            <div class="kv-row"><span>วันเข้าศึกษา</span><b><?= e($student['admission_date'] ? thai_date($student['admission_date']) : '—') ?></b></div>
          </div>
        </div>
      </article>
    </div>

    <div class="stack">
      <article class="card">
        <div class="card-head bordered"><div><h3 class="card-title"><?= icon('user', 19) ?> ข้อมูลหลัก</h3><p class="card-sub">ข้อมูลทะเบียนนักเรียน</p></div></div>
        <div class="card-body">
          <div class="info-grid">
            <div class="info-item"><span>ชื่อ-นามสกุล</span><b><?= e(student_name($student)) ?></b></div>
            <div class="info-item"><span>ชื่อเล่น</span><b><?= e($fieldValue('nickname')) ?></b></div>
            <div class="info-item"><span>ชื่อ-นามสกุล (อังกฤษ)</span><b><?= e(trim(($profile['prefix_en'] ?? '') . ' ' . ($profile['firstname_en'] ?? '') . ' ' . ($profile['lastname_en'] ?? '')) ?: '—') ?></b></div>
            <div class="info-item"><span>รหัสนักเรียน</span><b><?= e($student['student_code']) ?></b></div>
            <div class="info-item"><span>ชั้นเรียน / เลขที่</span><b><?= e($classText ?: '—') ?> · <?= (int) $student['student_number'] ?></b></div>
            <div class="info-item"><span>สถานะ</span><b><?= e($statusOfStudent['label']) ?></b></div>
            <div class="info-item"><span>เพศ</span><b><?= e($genderLabel) ?></b></div>
            <div class="info-item"><span>วันเกิด / อายุ</span><b><?= e($student['birth_date'] ? thai_date($student['birth_date']) : '—') ?> · <?= e(student_age($student['birth_date'])) ?></b></div>
            <div class="info-item"><span>เลขประจำตัวประชาชน</span><b><?= e($student['citizen_id'] ?: '—') ?></b></div>
            <div class="info-item"><span>เบอร์โทรศัพท์</span><b><?= e($fieldValue('phone', $student['guardian_phone'] ?: '—')) ?></b></div>
            <div class="info-item"><span>สัญชาติ</span><b><?= e($student['nationality'] ?: '—') ?></b></div>
            <div class="info-item"><span>ศาสนา</span><b><?= e($student['religion'] ?: '—') ?></b></div>
            <div class="info-item"><span>กรุ๊ปเลือด</span><b><?= e($student['blood_type'] ?: '—') ?></b></div>
            <div class="info-item"><span>ครูประจำชั้น</span><b><?= e($homeroom ?: '—') ?></b></div>
          </div>
        </div>
      </article>

      <article class="card">
        <div class="card-head bordered"><div><h3 class="card-title"><?= icon('users', 19) ?> ครอบครัวและชาติพันธุ์</h3><p class="card-sub">ข้อมูลพื้นฐานของครอบครัว</p></div></div>
        <div class="card-body">
          <div class="info-grid">
            <div class="info-item"><span>จังหวัดเกิด</span><b><?= e($fieldValue('birth_province', $student['birth_place'] ?: '—')) ?></b></div>
            <div class="info-item"><span>เชื้อชาติ</span><b><?= e($fieldValue('ethnicity')) ?></b></div>
            <div class="info-item"><span>สถานภาพบิดามารดา</span><b><?= e($fieldValue('parent_marital_status')) ?></b></div>
            <div class="info-item"><span>ลำดับบุตร</span><b><?= $fieldValue('birth_order') !== '—' ? 'คนที่ ' . (int) $profile['birth_order'] : '—' ?></b></div>
            <div class="info-item"><span>พี่ชาย / พี่สาว</span><b><?= (int) $profile['brothers_older'] ?> / <?= (int) $profile['sisters_older'] ?> คน</b></div>
            <div class="info-item"><span>น้องชาย / น้องสาว</span><b><?= (int) $profile['brothers_younger'] ?> / <?= (int) $profile['sisters_younger'] ?> คน</b></div>
            <div class="info-item"><span>พี่น้องกำลังศึกษา</span><b><?= (int) $profile['siblings_studying'] ?> คน</b></div>
            <div class="info-item"><span>ความสัมพันธ์ผู้ปกครอง</span><b><?= e($fieldValue('guardian_relation')) ?></b></div>
          </div>
        </div>
      </article>
    </div>
  </div>

  <div class="grid grid-2 mt-2">
    <article class="card">
      <div class="card-head bordered"><div><h3 class="card-title"><?= icon('user', 19) ?> ข้อมูลบิดา</h3><p class="card-sub">ข้อมูลผู้ปกครองฝ่ายบิดา</p></div></div>
      <div class="card-body">
        <div class="info-grid">
          <div class="info-item"><span>ชื่อ-นามสกุล</span><b><?= e(trim(($profile['father_prefix'] ?? '') . ' ' . ($profile['father_firstname'] ?? '') . ' ' . ($profile['father_lastname'] ?? '')) ?: '—') ?></b></div>
          <div class="info-item"><span>เลขประจำตัวประชาชน</span><b><?= e($fieldValue('father_citizen_id')) ?></b></div>
          <div class="info-item"><span>อาชีพ</span><b><?= e($fieldValue('father_occupation')) ?></b></div>
          <div class="info-item"><span>รายได้ต่อเดือน</span><b><?= e($incomeText($profile['father_income'])) ?></b></div>
          <div class="info-item" style="grid-column:1/-1"><span>เบอร์โทรศัพท์</span><b><?= e($fieldValue('father_phone')) ?></b></div>
        </div>
      </div>
    </article>

    <article class="card">
      <div class="card-head bordered"><div><h3 class="card-title"><?= icon('users', 19) ?> ข้อมูลมารดา / ผู้ปกครอง</h3><p class="card-sub">ข้อมูลที่โรงเรียนบันทึก</p></div><div class="card-actions"><span class="badge badge-muted"><?= icon('lock', 12) ?> แก้ไขไม่ได้</span></div></div>
      <div class="card-body">
        <div class="info-grid">
          <div class="info-item"><span>ชื่อ-นามสกุลมารดา</span><b><?= e(trim(($profile['mother_prefix'] ?? '') . ' ' . ($profile['mother_firstname'] ?? '') . ' ' . ($profile['mother_lastname'] ?? '')) ?: '—') ?></b></div>
          <div class="info-item"><span>เลขประจำตัวประชาชน</span><b><?= e($fieldValue('mother_citizen_id')) ?></b></div>
          <div class="info-item"><span>อาชีพ</span><b><?= e($fieldValue('mother_occupation')) ?></b></div>
          <div class="info-item"><span>รายได้ต่อเดือน</span><b><?= e($incomeText($profile['mother_income'])) ?></b></div>
          <div class="info-item"><span>เบอร์โทรศัพท์</span><b><?= e($fieldValue('mother_phone')) ?></b></div>
          <div class="info-item"><span>ผู้ปกครองตามทะเบียน</span><b><?= e($student['parent_name'] ?: '—') ?></b></div>
          <div class="info-item"><span>ความสัมพันธ์</span><b><?= e($fieldValue('guardian_relation', $student['parent_relation'] ?: '—')) ?></b></div>
          <div class="info-item"><span>เบอร์ผู้ปกครอง</span><b><?= e($student['guardian_phone'] ?: $student['parent_phone'] ?: '—') ?></b></div>
        </div>
        <p class="field-hint mt-2"><?= icon('info', 13) ?> ข้อมูลมารดาและผู้ปกครองแก้ไขได้โดยเจ้าหน้าที่ทะเบียนเท่านั้น</p>
      </div>
    </article>
  </div>

  <div class="grid grid-2 mt-2">
    <article class="card">
      <div class="card-head bordered"><div><h3 class="card-title"><?= icon('home', 19) ?> ที่อยู่ตามทะเบียนบ้าน</h3></div></div>
      <div class="card-body"><div class="address-box"><b><?= e($registeredLine1) ?></b><span><?= e($registeredLine2) ?></span></div></div>
    </article>
    <article class="card">
      <div class="card-head bordered"><div><h3 class="card-title"><?= icon('map-pin', 19) ?> ที่อยู่ปัจจุบัน</h3></div></div>
      <div class="card-body"><div class="address-box"><b><?= e($currentLine1) ?></b><span><?= e($currentLine2) ?></span></div></div>
    </article>
  </div>

  <article class="card mt-2">
    <div class="card-head bordered"><div><h3 class="card-title"><?= icon('shield', 19) ?> สุขภาพ การเดินทาง และความช่วยเหลือ</h3><p class="card-sub">ข้อมูลเพื่อการดูแลนักเรียน</p></div></div>
    <div class="card-body">
      <div class="info-grid">
        <div class="info-item"><span>น้ำหนัก / ส่วนสูง</span><b><?= (float) $profile['weight'] > 0 ? number_format((float) $profile['weight'], 1) . ' กก.' : '—' ?> / <?= (float) $profile['height'] > 0 ? number_format((float) $profile['height'], 1) . ' ซม.' : '—' ?></b></div>
        <div class="info-item"><span>ที่พักอาศัย</span><b><?= e($fieldValue('accommodation')) ?></b></div>
        <div class="info-item"><span>วิธีเดินทาง</span><b><?= e($fieldValue('travel_method')) ?></b></div>
        <div class="info-item"><span>เวลาเดินทาง</span><b><?= (int) $profile['travel_minutes'] > 0 ? (int) $profile['travel_minutes'] . ' นาที' : '—' ?></b></div>
        <div class="info-item"><span>ระยะทางถนนลูกรัง / ลาดยาง / ทางน้ำ</span><b><?= number_format((float) $profile['distance_dirt'], 1) ?> / <?= number_format((float) $profile['distance_asphalt'], 1) ?> / <?= number_format((float) $profile['distance_water'], 1) ?> กม.</b></div>
        <div class="info-item"><span>ความช่วยเหลือที่ได้รับ</span><b><?= e(implode(' · ', array_filter([
            (string) $profile['shortage_uniform'] === 'ขาดแคลน' ? 'เครื่องแบบ' : '',
            (string) $profile['shortage_stationery'] === 'ขาดแคลน' ? 'เครื่องเขียน' : '',
            (string) $profile['shortage_books'] === 'ขาดแคลน' ? 'หนังสือ' : '',
            (string) $profile['shortage_lunch'] === 'ขาดแคลน' ? 'อาหารกลางวัน' : '',
        ])) ?: 'ไม่ขาดแคลน') ?></b></div>
        <div class="info-item" style="grid-column:1/-1"><span>ความบกพร่อง / โรคประจำตัว</span><b><?= e($fieldValue('disability', 'ไม่มี')) ?></b></div>
      </div>
    </div>
  </article>

<?php else: ?>
  <form method="post" class="profile-edit-form mt-3" autocomplete="off">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="save_profile">

    <div class="notice notice-info mb-2"><?= icon('info', 18) ?><div>แก้ไขได้เฉพาะข้อมูลของบัญชีนักเรียนที่เข้าสู่ระบบอยู่เท่านั้น ข้อมูลทะเบียนหลัก ข้อมูลมารดา ผู้ปกครอง และผลการเรียนแก้ไขได้โดยเจ้าหน้าที่</div></div>

    <section class="form-section">
      <h3 class="form-section-title"><?= icon('user', 18) ?> ข้อมูลหลัก</h3>
      <div class="form-grid">
        <div class="field"><label>ชื่อเล่น</label><input class="input" name="nickname" maxlength="80" value="<?= e($profile['nickname']) ?>" placeholder="ชื่อเล่นที่ใช้เรียก"></div>
        <div class="field"><label>เบอร์โทรศัพท์นักเรียน</label><input class="input" name="phone" maxlength="30" value="<?= e($profile['phone']) ?>" placeholder="08x-xxx-xxxx"></div>
        <div class="field"><label>คำนำหน้าชื่อ (อังกฤษ)</label><input class="input" name="prefix_en" maxlength="20" value="<?= e($profile['prefix_en']) ?>" placeholder="Mr. / Miss"></div>
        <div class="field"><label>ชื่อ (อังกฤษ)</label><input class="input" name="firstname_en" maxlength="80" value="<?= e($profile['firstname_en']) ?>"></div>
        <div class="field"><label>นามสกุล (อังกฤษ)</label><input class="input" name="lastname_en" maxlength="80" value="<?= e($profile['lastname_en']) ?>"></div>
        <div class="field"><label>ชื่อ-นามสกุล (ไทย)</label><input class="input" value="<?= e(student_name($student)) ?>" disabled></div>
      </div>
    </section>

    <section class="form-section">
      <h3 class="form-section-title"><?= icon('users', 18) ?> ข้อมูลครอบครัวและชาติพันธุ์</h3>
      <div class="form-grid">
        <div class="field"><label>จังหวัดเกิด</label><input class="input" name="birth_province" maxlength="100" value="<?= e($profile['birth_province']) ?>"></div>
        <div class="field"><label>เชื้อชาติ</label><input class="input" name="ethnicity" maxlength="50" value="<?= e($profile['ethnicity']) ?>"></div>
        <div class="field"><label>สถานภาพบิดามารดา</label>
          <select class="select" name="parent_marital_status">
            <option value="">— เลือก —</option>
            <?php foreach ($maritalOptions as $option): ?><option value="<?= e($option) ?>" <?= $profile['parent_marital_status'] === $option ? 'selected' : '' ?>><?= e($option) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="field"><label>ลำดับบุตร</label><input class="input" type="number" min="0" max="15" name="birth_order" value="<?= (int) $profile['birth_order'] ?>"></div>
        <div class="field"><label>พี่ชาย (คน)</label><input class="input" type="number" min="0" max="15" name="brothers_older" value="<?= (int) $profile['brothers_older'] ?>"></div>
        <div class="field"><label>พี่สาว (คน)</label><input class="input" type="number" min="0" max="15" name="sisters_older" value="<?= (int) $profile['sisters_older'] ?>"></div>
        <div class="field"><label>น้องชาย (คน)</label><input class="input" type="number" min="0" max="15" name="brothers_younger" value="<?= (int) $profile['brothers_younger'] ?>"></div>
        <div class="field"><label>น้องสาว (คน)</label><input class="input" type="number" min="0" max="15" name="sisters_younger" value="<?= (int) $profile['sisters_younger'] ?>"></div>
        <div class="field"><label>พี่น้องกำลังศึกษา (คน)</label><input class="input" type="number" min="0" max="15" name="siblings_studying" value="<?= (int) $profile['siblings_studying'] ?>"></div>
      </div>
    </section>

    <section class="form-section">
      <h3 class="form-section-title"><?= icon('user', 18) ?> ข้อมูลบิดา</h3>
      <div class="form-grid">
        <div class="field"><label>คำนำหน้า</label>
          <select class="select" name="father_prefix">
            <option value="">— เลือก —</option>
            <?php foreach ($prefixOptions as $option): ?><option value="<?= e($option) ?>" <?= $profile['father_prefix'] === $option ? 'selected' : '' ?>><?= e($option) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="field"><label>เลขประจำตัวประชาชน</label><input class="input" name="father_citizen_id" maxlength="20" value="<?= e($profile['father_citizen_id']) ?>"></div>
        <div class="field"><label>ชื่อ</label><input class="input" name="father_firstname" maxlength="80" value="<?= e($profile['father_firstname']) ?>"></div>
        <div class="field"><label>นามสกุล</label><input class="input" name="father_lastname" maxlength="80" value="<?= e($profile['father_lastname']) ?>"></div>
        <div class="field"><label>อาชีพ</label><input class="input" name="father_occupation" maxlength="100" value="<?= e($profile['father_occupation']) ?>"></div>
        <div class="field"><label>รายได้ต่อเดือน (บาท)</label><input class="input" type="number" step="0.01" min="0" name="father_income" value="<?= e($profile['father_income']) ?>"></div>
        <div class="field"><label>เบอร์โทรศัพท์</label><input class="input" name="father_phone" maxlength="30" value="<?= e($profile['father_phone']) ?>"></div>
      </div>
    </section>

    <section class="form-section">
      <h3 class="form-section-title"><?= icon('lock', 18) ?> ข้อมูลมารดาและผู้ปกครอง</h3>
      <div class="readonly-grid">
        <div class="kv-row"><span>มารดา</span><b><?= e(trim(($profile['mother_prefix'] ?? '') . ' ' . ($profile['mother_firstname'] ?? '') . ' ' . ($profile['mother_lastname'] ?? '')) ?: '—') ?></b></div>
        <div class="kv-row"><span>อาชีพมารดา</span><b><?= e($fieldValue('mother_occupation')) ?></b></div>
        <div class="kv-row"><span>เบอร์โทรศัพท์มารดา</span><b><?= e($fieldValue('mother_phone')) ?></b></div>
        <div class="kv-row"><span>ผู้ปกครองตามทะเบียน</span><b><?= e($student['parent_name'] ?: '—') ?></b></div>
      </div>
      <p class="field-hint mt-2"><?= icon('info', 13) ?> หากต้องการแก้ไขข้อมูลมารดาหรือผู้ปกครอง กรุณาติดต่อฝ่ายทะเบียนของโรงเรียน</p>
    </section>

    <section class="form-section">
      <h3 class="form-section-title"><?= icon('home', 18) ?> ที่อยู่ตามทะเบียนบ้าน</h3>
      <div class="form-grid">
        <div class="field"><label>รหัสบ้าน</label><input class="input" name="registered_house_code" maxlength="30" value="<?= e($profile['registered_house_code']) ?>"></div>
        <div class="field"><label>บ้านเลขที่</label><input class="input" name="registered_house_no" maxlength="30" value="<?= e($profile['registered_house_no']) ?>"></div>
        <div class="field"><label>หมู่ที่</label><input class="input" name="registered_moo" maxlength="10" value="<?= e($profile['registered_moo']) ?>"></div>
        <div class="field"><label>ถนน</label><input class="input" name="registered_road" maxlength="120" value="<?= e($profile['registered_road']) ?>"></div>
        <div class="field"><label>ตำบล / แขวง</label><input class="input" name="registered_subdistrict" maxlength="80" value="<?= e($profile['registered_subdistrict']) ?>"></div>
        <div class="field"><label>อำเภอ / เขต</label><input class="input" name="registered_district" maxlength="80" value="<?= e($profile['registered_district']) ?>"></div>
        <div class="field"><label>จังหวัด</label><input class="input" name="registered_province" maxlength="80" value="<?= e($profile['registered_province']) ?>"></div>
        <div class="field"><label>รหัสไปรษณีย์</label><input class="input" name="registered_postcode" maxlength="10" value="<?= e($profile['registered_postcode']) ?>"></div>
      </div>
    </section>

    <section class="form-section">
      <h3 class="form-section-title"><?= icon('map-pin', 18) ?> ที่อยู่ปัจจุบัน</h3>
      <div class="form-grid">
        <div class="field"><label>รหัสบ้าน</label><input class="input" name="current_house_code" maxlength="30" value="<?= e($profile['current_house_code']) ?>"></div>
        <div class="field"><label>บ้านเลขที่</label><input class="input" name="current_house_no" maxlength="30" value="<?= e($profile['current_house_no']) ?>"></div>
        <div class="field"><label>หมู่ที่</label><input class="input" name="current_moo" maxlength="10" value="<?= e($profile['current_moo']) ?>"></div>
        <div class="field"><label>ถนน</label><input class="input" name="current_road" maxlength="120" value="<?= e($profile['current_road']) ?>"></div>
        <div class="field"><label>ตำบล / แขวง</label><input class="input" name="current_subdistrict" maxlength="80" value="<?= e($profile['current_subdistrict']) ?>"></div>
        <div class="field"><label>อำเภอ / เขต</label><input class="input" name="current_district" maxlength="80" value="<?= e($profile['current_district']) ?>"></div>
        <div class="field"><label>จังหวัด</label><input class="input" name="current_province" maxlength="80" value="<?= e($profile['current_province']) ?>"></div>
        <div class="field"><label>รหัสไปรษณีย์</label><input class="input" name="current_postcode" maxlength="10" value="<?= e($profile['current_postcode']) ?>"></div>
      </div>
    </section>

    <section class="form-section">
      <h3 class="form-section-title"><?= icon('shield', 18) ?> สุขภาพ การเดินทาง และความช่วยเหลือ</h3>
      <div class="form-grid">
        <div class="field"><label>น้ำหนัก (กก.)</label><input class="input" type="number" step="0.1" min="0" name="weight" value="<?= e($profile['weight']) ?>"></div>
        <div class="field"><label>ส่วนสูง (ซม.)</label><input class="input" type="number" step="0.1" min="0" name="height" value="<?= e($profile['height']) ?>"></div>
        <div class="field"><label>ที่พักอาศัย</label>
          <select class="select" name="accommodation">
            <option value="">— เลือก —</option>
            <?php foreach ($accommodationOptions as $option): ?><option value="<?= e($option) ?>" <?= $profile['accommodation'] === $option ? 'selected' : '' ?>><?= e($option) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="field"><label>วิธีเดินทาง</label>
          <select class="select" name="travel_method">
            <option value="">— เลือก —</option>
            <?php foreach ($travelOptions as $option): ?><option value="<?= e($option) ?>" <?= $profile['travel_method'] === $option ? 'selected' : '' ?>><?= e($option) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="field"><label>เวลาเดินทาง (นาที)</label><input class="input" type="number" min="0" max="600" name="travel_minutes" value="<?= (int) $profile['travel_minutes'] ?>"></div>
        <div class="field"><label>ระยะทางถนนลูกรัง (กม.)</label><input class="input" type="number" step="0.1" min="0" name="distance_dirt" value="<?= e($profile['distance_dirt']) ?>"></div>
        <div class="field"><label>ระยะทางถนนลาดยาง (กม.)</label><input class="input" type="number" step="0.1" min="0" name="distance_asphalt" value="<?= e($profile['distance_asphalt']) ?>"></div>
        <div class="field"><label>ระยะทางทางน้ำ (กม.)</label><input class="input" type="number" step="0.1" min="0" name="distance_water" value="<?= e($profile['distance_water']) ?>"></div>
        <?php foreach ([['shortage_uniform', 'เครื่องแบบ'], ['shortage_stationery', 'เครื่องเขียน'], ['shortage_books', 'หนังสือเรียน'], ['shortage_lunch', 'อาหารกลางวัน']] as [$field, $label]): ?>
          <div class="field"><label><?= e($label) ?></label>
            <select class="select" name="<?= e($field) ?>">
              <option value="">— เลือก —</option>
              <?php foreach ($shortageOptions as $option): ?><option value="<?= e($option) ?>" <?= $profile[$field] === $option ? 'selected' : '' ?>><?= e($option) ?></option><?php endforeach; ?>
            </select>
          </div>
        <?php endforeach; ?>
        <div class="field span-2"><label>ความบกพร่อง / โรคประจำตัว</label><input class="input" name="disability" maxlength="190" value="<?= e($profile['disability']) ?>" placeholder="ระบุหากมี หากไม่มีให้เว้นว่าง"></div>
      </div>
    </section>

    <div class="form-actions">
      <button type="submit" class="btn btn-primary"><?= icon('save', 17) ?> บันทึกข้อมูล</button>
      <a class="btn btn-ghost" href="<?= e(portal_url('student-profile.php')) ?>">ยกเลิก</a>
      <span class="field-hint" style="margin-left:auto"><?= icon('lock', 13) ?> ข้อมูลถูกบันทึกเฉพาะบัญชีของ <?= e($student['student_code']) ?></span>
    </div>
  </form>
<?php endif; ?>

<?php require __DIR__ . '/includes/student-portal-bottom.php'; ?>
