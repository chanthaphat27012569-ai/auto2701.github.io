<?php

require_once __DIR__ . '/includes/bootstrap.php';

if (current_staff()) {
    redirect('dashboard.php');
}

$tab = get_str('tab', 'staff');
$errorStaff = '';
$errorStudent = '';
$username = '';
$studentCode = '';

if (is_post()) {
    verify_csrf();
    $action = post_str('action');
    $tab = post_str('tab', 'staff');

    if ($action === 'staff') {
        $username = post_str('username');
        $password = (string) ($_POST['password'] ?? '');
        if ($username === '' || $password === '') {
            $errorStaff = 'กรุณากรอกชื่อผู้ใช้งานและรหัสผ่าน';
        } else {
            $user = staff_login($username, $password);
            if (!$user) {
                $errorStaff = 'ชื่อผู้ใช้งานหรือรหัสผ่านไม่ถูกต้อง กรุณาลองอีกครั้ง';
            } else {
                flash('success', 'ยินดีต้อนรับ ' . $user['fullname']);
                redirect('dashboard.php');
            }
        }
    } elseif ($action === 'student') {
        $studentCode = post_str('student_code');
        $pin = post_str('pin');
        if ($studentCode === '' || $pin === '') {
            $errorStudent = 'กรุณากรอกรหัสนักเรียนและรหัส PIN';
        } else {
            $student = student_login($studentCode, $pin);
            if (!$student) {
                $errorStudent = 'รหัสนักเรียนหรือ PIN ไม่ถูกต้อง กรุณาตรวจสอบอีกครั้ง';
            } else {
                flash('success', 'ยินดีต้อนรับ ' . student_name($student));
                redirect('portal.php');
            }
        }
    }
}

$stats = ['students' => 0, 'classes' => 0, 'attendance' => 0.0, 'documents' => 0];
try {
    $stats['students'] = (int) db()->query("SELECT COUNT(*) FROM students WHERE status = 'studying'")->fetchColumn();
    $stats['classes'] = (int) db()->query("SELECT COUNT(*) FROM classes WHERE status = 'active'")->fetchColumn();
    $stats['documents'] = (int) db()->query('SELECT COUNT(*) FROM documents')->fetchColumn();
    $stmt = db()->prepare("SELECT status, COUNT(*) AS total FROM attendance WHERE DATE_FORMAT(att_date, '%Y-%m') = ? GROUP BY status");
    $stmt->execute([date('Y-m')]);
    $counts = ['present' => 0, 'late' => 0, 'sick' => 0, 'business' => 0, 'absent' => 0, 'truant' => 0];
    foreach ($stmt->fetchAll() as $row) {
        $counts[$row['status']] = (int) $row['total'];
    }
    $stats['attendance'] = attendance_rate($counts);
    if ($stats['attendance'] == 0) {
        $rows = db()->query('SELECT status, COUNT(*) AS total FROM attendance GROUP BY status')->fetchAll();
        $counts = ['present' => 0, 'late' => 0, 'sick' => 0, 'business' => 0, 'absent' => 0, 'truant' => 0];
        foreach ($rows as $row) {
            $counts[$row['status']] = (int) $row['total'];
        }
        $stats['attendance'] = attendance_rate($counts);
    }
} catch (Throwable $e) {
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="theme-color" content="#4f46e5">
<title>เข้าสู่ระบบ · <?= e(APP_TITLE) ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Itim&family=Sarabun:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,400;1,700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= url('assets/css/app.css') ?>?v=<?= APP_VERSION ?>">
</head>
<body class="auth-body">
<div class="auth-grid" aria-hidden="true"></div>
<div class="auth-orb a1" aria-hidden="true"></div>
<div class="auth-orb a2" aria-hidden="true"></div>
<div class="auth-orb a3" aria-hidden="true"></div>

<main class="auth-shell">
  <section class="auth-brand">
    <div class="auth-brand-top">
      <span class="brand-logo"><?= school_logo_svg(52) ?></span>
      <div>
        <span class="auth-kicker">SMART SCHOOL MANAGEMENT</span>
        <strong><?= e($school['name']) ?></strong>
      </div>
    </div>

    <div class="auth-hero">
      <span class="tag"><?= icon('sparkles', 15) ?> ระบบเดียว ครบทุกงานโรงเรียน</span>
      <h1>เรียนดี ดูแลครบ<br><span>จบในระบบเดียว</span></h1>
      <p>บริหารข้อมูลนักเรียน เช็คชื่อประจำวัน บันทึกผลการเรียน และออกเอกสารทางการศึกษา ปพ.1–ปพ.9 พร้อมรายงานที่อ่านง่าย ในระบบ PHP + MySQL ที่รวดเร็วและปลอดภัย</p>

      <div class="auth-features">
        <div class="auth-feature"><?= icon('check', 20) ?><b>เช็คชื่ออัจฉริยะ</b>รายวัน · รายเดือน</div>
        <div class="auth-feature"><?= icon('file', 20) ?><b>เอกสาร ปพ.1–9</b>พิมพ์ได้ทันที</div>
        <div class="auth-feature"><?= icon('chart', 20) ?><b>รายงานผลการเรียน</b>เกรดและ GPA</div>
      </div>

      <div class="auth-stats">
        <div class="auth-stat"><b class="num" data-count="<?= (int) $stats['students'] ?>">—</b><span>นักเรียน</span></div>
        <div class="auth-stat"><b class="num" data-count="<?= (int) $stats['classes'] ?>">—</b><span>ชั้นเรียน</span></div>
        <div class="auth-stat"><b class="num" data-count="<?= round($stats['attendance'], 1) ?>" data-decimals="1" data-suffix="%">—</b><span>อัตรามาเรียน</span></div>
        <div class="auth-stat"><b class="num" data-count="<?= (int) $stats['documents'] ?>">—</b><span>เอกสารที่ออก</span></div>
      </div>

      <div class="auth-brand-foot"><span class="live-dot"></span> ระบบพร้อมใช้งาน · ข้อมูลจัดเก็บในฐานข้อมูล MySQL อย่างปลอดภัย</div>
    </div>
  </section>

  <section class="auth-panel">
    <div class="auth-panel-head">
      <div class="mini-logo"><?= school_logo_svg(46) ?></div>
      <div>
        <h2>ยินดีต้อนรับ</h2>
        <p>เลือกประเภทผู้ใช้งานเพื่อเข้าสู่ระบบ</p>
      </div>
    </div>

    <div class="auth-tabs" role="tablist" aria-label="ประเภทผู้ใช้งาน">
      <button type="button" class="auth-tab <?= $tab === 'student' ? '' : 'is-active' ?>" data-auth-tab="staff" role="tab" aria-selected="<?= $tab === 'student' ? 'false' : 'true' ?>">
        <?= icon('user', 17) ?> เจ้าหน้าที่
      </button>
      <button type="button" class="auth-tab <?= $tab === 'student' ? 'is-active' : '' ?>" data-auth-tab="student" role="tab" aria-selected="<?= $tab === 'student' ? 'true' : 'false' ?>">
        <?= icon('graduation', 17) ?> นักเรียน / ผู้ปกครอง
      </button>
    </div>

    <form class="auth-form <?= $tab === 'student' ? 'hidden' : '' ?>" data-auth-panel="staff" method="post" action="<?= url('login.php') ?>" autocomplete="on">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="staff">
      <input type="hidden" name="tab" value="staff">

      <div class="auth-field">
        <label for="loginUsername">ชื่อผู้ใช้งาน</label>
        <div class="auth-input">
          <?= icon('user', 17) ?>
          <input class="input" id="loginUsername" type="text" name="username" placeholder="กรอกชื่อผู้ใช้งาน" value="<?= e($username) ?>" autocomplete="username" required>
        </div>
      </div>

      <div class="auth-field">
        <label for="loginPassword">รหัสผ่าน</label>
        <div class="auth-input">
          <?= icon('lock', 17) ?>
          <input class="input" id="loginPassword" type="password" name="password" placeholder="กรอกรหัสผ่าน" autocomplete="current-password" required style="padding-right:44px">
          <button type="button" class="pwd-toggle" data-pwd-toggle="loginPassword" aria-label="แสดงรหัสผ่าน"><?= icon('eye', 17) ?></button>
        </div>
      </div>

      <?php if ($errorStaff !== ''): ?>
        <div class="auth-error show"><?= icon('alert', 17) ?><span><?= e($errorStaff) ?></span></div>
      <?php endif; ?>

      <button type="submit" class="btn btn-primary auth-submit">
        <span>เข้าสู่ระบบ</span><?= icon('arrow-right', 17) ?>
      </button>

      <div class="auth-demo">
        <div class="auth-demo-head"><span>ทดลองใช้งานด่วน</span><b>รหัสผ่าน 1234</b></div>
        <div class="demo-chips">
          <button type="button" class="demo-chip" data-demo-user="admin">ผู้ดูแลระบบ</button>
          <button type="button" class="demo-chip" data-demo-user="teacher.deputy">รองผู้อำนวยการ</button>
          <button type="button" class="demo-chip" data-demo-user="registrar">นายทะเบียน</button>
          <button type="button" class="demo-chip" data-demo-user="teacher.sunee">ครูผู้สอน</button>
        </div>
      </div>
    </form>

    <form class="auth-form <?= $tab === 'student' ? '' : 'hidden' ?>" data-auth-panel="student" method="post" action="<?= url('login.php') ?>" autocomplete="off">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="student">
      <input type="hidden" name="tab" value="student">

      <div class="auth-field">
        <label for="studentCode">รหัสนักเรียน</label>
        <div class="auth-input">
          <?= icon('graduation', 17) ?>
          <input class="input" id="studentCode" type="text" name="student_code" placeholder="เช่น 1001" value="<?= e($studentCode) ?>" inputmode="numeric" required>
        </div>
      </div>

      <div class="auth-field">
        <label for="studentPin">รหัส PIN</label>
        <div class="auth-input">
          <?= icon('key', 17) ?>
          <input class="input" id="studentPin" type="password" name="pin" placeholder="PIN 4 หลัก" value="" inputmode="numeric" maxlength="8" required>
        </div>
      </div>

      <?php if ($errorStudent !== ''): ?>
        <div class="auth-error show"><?= icon('alert', 17) ?><span><?= e($errorStudent) ?></span></div>
      <?php endif; ?>

      <button type="submit" class="btn btn-primary auth-submit" style="background:linear-gradient(135deg,#10b981,#0d9488);box-shadow:0 10px 22px rgba(13,148,136,.28)">
        <span>เปิดพอร์ทัลนักเรียน</span><?= icon('arrow-right', 17) ?>
      </button>

      <div class="auth-demo">
        <div class="auth-demo-head"><span>ทดลองใช้งานด่วน</span><b>PIN = รหัสนักเรียน</b></div>
        <div class="demo-chips">
          <button type="button" class="demo-chip" data-demo-student="1001" data-demo-pin="1001">1001 · ธนภัทร</button>
          <button type="button" class="demo-chip" data-demo-student="1002" data-demo-pin="1002">1002 · อรวรรณ</button>
          <button type="button" class="demo-chip" data-demo-student="1009" data-demo-pin="1009">1009 · นักเรียน ม.2</button>
        </div>
        <div class="auth-hint"><?= icon('info', 14) ?> ผู้ปกครองสามารถตรวจดูผลการเรียน เวลาเรียน และเอกสาร ปพ. ของบุตรหลานได้ โดยใช้รหัสนักเรียนและ PIN ที่โรงเรียนกำหนด</div>
      </div>
    </form>

    <div class="auth-links">
      <span>© <?= date('Y') + 543 ?> <?= e($school['name']) ?></span>
      <a href="<?= url('install.php') ?>"><?= icon('settings', 13) ?> ตั้งค่าฐานข้อมูล</a>
    </div>
  </section>
</main>

<script src="<?= url('assets/js/app.js') ?>?v=<?= APP_VERSION ?>"></script>
</body>
</html>
