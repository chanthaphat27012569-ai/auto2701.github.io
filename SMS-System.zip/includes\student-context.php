<?php

$staff = current_staff();
$pdo = db();
$isPreview = false;
$previewStudents = [];

if ($staff) {
    $isPreview = true;
    $previewStudents = $pdo->query("SELECT id, student_code, prefix, firstname, lastname
        FROM students WHERE status IN ('studying','graduated') ORDER BY student_code")->fetchAll();
    $previewId = get_int('student');
    if ($previewId <= 0) {
        $previewId = (int) ($previewStudents[0]['id'] ?? 0);
    }
    $previewStmt = $pdo->prepare('SELECT s.*, c.name AS class_name, c.level, c.level_short, c.room
        FROM students s LEFT JOIN classes c ON c.id = s.class_id WHERE s.id = ? LIMIT 1');
    $previewStmt->execute([$previewId]);
    $student = $previewStmt->fetch();
    if (!$student) {
        flash('danger', 'ไม่พบนักเรียนสำหรับแสดงตัวอย่างพอร์ทัล');
        redirect('dashboard.php');
    }
} else {
    $student = require_student();
}

$student['profile'] = student_profile((int) $student['id']);
$student['avatar'] = (string) ($student['profile']['avatar'] ?? '');
$profile = $student['profile'];

$year = academic_year();
$semester = academic_semester();
$statusOfStudent = student_status_meta()[$student['status']] ?? student_status_meta()['studying'];
$classText = (string) ($student['class_name'] ?: ($student['level_short'] ?? ''));
$homeroom = '';
$homeroomStmt = $pdo->prepare('SELECT homeroom FROM classes WHERE id = ? LIMIT 1');
$homeroomStmt->execute([(int) ($student['class_id'] ?? 0)]);
$homeroom = (string) ($homeroomStmt->fetchColumn() ?: '');

$portalActive = $portalActive ?? 'home';
$pageTitle = $pageTitle ?? 'พอร์ทัลนักเรียน';
$pageSubtitle = $pageSubtitle ?? '';

if (!function_exists('portal_url')) {
    function portal_url(string $page = 'portal.php', array $query = []): string
    {
        global $isPreview, $student;
        $hash = '';
        if (str_contains($page, '#')) {
            [$page, $hash] = explode('#', $page, 2);
        }
        if ($isPreview) {
            $query = array_merge(['student' => (int) $student['id']], $query);
        }
        $qs = http_build_query($query);
        return url($page . ($qs !== '' ? '?' . $qs : '') . ($hash !== '' ? '#' . $hash : ''));
    }
}
