    </main>

    <footer class="app-footer">
      <span>© <?= date('Y') + 543 ?> <?= e(school('name', APP_TITLE)) ?></span>
      <span class="footer-dot"></span>
      <span><?= e(APP_TITLE) ?> v<?= e(APP_VERSION) ?></span>
      <span class="footer-spacer"></span>
      <span class="footer-status"><span class="live-dot"></span>ระบบทำงานปกติ</span>
    </footer>
  </div>
</div>

<div class="toast-stack" id="toastStack" aria-live="polite">
  <?php foreach ($flashes as $flash): ?>
    <div class="toast toast-<?= e($flash['type']) ?>" data-toast>
      <span class="toast-icon"><?= icon(match ($flash['type']) { 'success' => 'check-circle', 'danger' => 'x-circle', 'warning' => 'alert', default => 'info' }, 20) ?></span>
      <p><?= e($flash['message']) ?></p>
      <button type="button" class="toast-close" data-toast-close aria-label="ปิด"><?= icon('x', 15) ?></button>
      <span class="toast-timer"></span>
    </div>
  <?php endforeach; ?>
</div>

<div class="modal" id="confirmModal" aria-hidden="true">
  <div class="modal-backdrop" data-modal-close></div>
  <div class="modal-card" role="dialog" aria-modal="true" aria-labelledby="confirmTitle">
    <div class="modal-icon"><?= icon('alert', 26) ?></div>
    <h3 id="confirmTitle">ยืนยันการทำรายการ</h3>
    <p id="confirmText">ต้องการดำเนินการต่อหรือไม่</p>
    <div class="modal-actions">
      <button type="button" class="btn btn-ghost" data-modal-close>ยกเลิก</button>
      <button type="button" class="btn btn-danger" id="confirmOk">ยืนยัน</button>
    </div>
  </div>
</div>

<script>window.SMS = { base: <?= json_encode(BASE_URL) ?>, version: <?= json_encode(APP_VERSION) ?> };</script>
<script src="<?= url('assets/js/app.js') ?>?v=<?= APP_VERSION ?>"></script>
</body>
</html>
