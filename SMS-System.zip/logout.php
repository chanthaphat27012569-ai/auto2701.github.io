<?php

require_once __DIR__ . '/includes/bootstrap.php';

logout_staff();
logout_student();
flash('info', 'ออกจากระบบเรียบร้อยแล้ว');
redirect('login.php');
