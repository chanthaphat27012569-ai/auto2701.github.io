<?php

require_once __DIR__ . '/includes/bootstrap.php';

$portalActive = 'attendance';
$pageTitle = 'ประวัติเช็คชื่อ';
$pageSubtitle = 'การเข้าแถวหน้าเสาธงและการเช็คชื่อรายวิชา';
require __DIR__ . '/includes/student-context.php';

$studentId = (int) $student['id'];
$portalTablesReady = portal_tables_ready();
$statusMeta = attendance_meta();
$badgeClass = ['present' => 'success', 'late' => 'warning', 'sick' => 'info', 'business' => 'violet', 'absent' => 'danger', 'truant' => 'danger'];

$flagStmt = $pdo->prepare("SELECT COUNT(*) AS total,
        COALESCE(SUM(status = 'present'), 0) AS present, COALESCE(SUM(status = 'late'), 0) AS late,
        COALESCE(SUM(status = 'sick'), 0) AS sick, COALESCE(SUM(status = 'business'), 0) AS business,
        COALESCE(SUM(status = 'absent'), 0) AS absent, COALESCE(SUM(status = 'truant'), 0) AS truant
    FROM attendance WHERE student_id = ?");
$flagStmt->execute([$studentId]);
$flagCounts = $flagStmt->fetch() ?: [];
foreach (['present', 'late', 'sick', 'business', 'absent', 'truant'] as $key) {
    $flagCounts[$key] = (int) ($flagCounts[$key] ?? 0);
}
$flagTotal = (int) ($flagCounts['total'] ?? 0);
$flagRate = attendance_rate($flagCounts);

$flagHistoryStmt = $pdo->prepare('SELECT a.*, u.fullname AS recorder FROM attendance a
    LEFT JOIN users u ON u.id = a.recorded_by
    WHERE a.student_id = ? ORDER BY a.att_date DESC LIMIT 80');
$flagHistoryStmt->execute([$studentId]);
$flagHistory = $flagHistoryStmt->fetchAll();

$subjectCounts = ['present' => 0, 'late' => 0, 'sick' => 0, 'business' => 0, 'absent' => 0, 'truant' => 0];
$subjectTotal = 0;
$subjectRate = 0.0;
$subjectHistory = [];
$subjectBreakdown = [];
$todaySubject = null;

if ($portalTablesReady) {
    $subjectStmt = $pdo->prepare("SELECT COUNT(*) AS total,
            COALESCE(SUM(status = 'present'), 0) AS present, COALESCE(SUM(status = 'late'), 0) AS late,
            COALESCE(SUM(status = 'sick'), 0) AS sick, COALESCE(SUM(status = 'business'), 0) AS business,
            COALESCE(SUM(status = 'absent'), 0) AS absent, COALESCE(SUM(status = 'truant'), 0) AS truant
        FROM subject_attendance WHERE student_id = ?");
    $subjectStmt->execute([$studentId]);
    $row = $subjectStmt->fetch() ?: [];
    foreach ($subjectCounts as $key => $value) {
        $subjectCounts[$key] = (int) ($row[$key] ?? 0);
    }
    $subjectTotal = (int) ($row['total'] ?? 0);
    $subjectRate = attendance_rate($subjectCounts);

    $historyStmt = $pdo->prepare('SELECT sa.*, sub.code, sub.name AS subject_name, u.fullname AS recorder
        FROM subject_attendance sa
        JOIN subjects sub ON sub.id = sa.subject_id
        LEFT JOIN users u ON u.id = sa.recorded_by
        WHERE sa.student_id = ?
        ORDER BY sa.att_date DESC, sa.period DESC LIMIT 100');
    $historyStmt->execute([$studentId]);
    $subjectHistory = $historyStmt->fetchAll();

    $breakdownStmt = $pdo->prepare("SELECT sub.code, sub.name, COUNT(*) AS total,
            COALESCE(SUM(sa.status = 'present'), 0) AS present, COALESCE(SUM(sa.status = 'late'), 0) AS late,
            COALESCE(SUM(sa.status = 'absent'), 0) + COALESCE(SUM(sa.status = 'truant'), 0) AS missed
        FROM subject_attendance sa JOIN subjects sub ON sub.id = sa.subject_id
        WHERE sa.student_id = ?
        GROUP BY sub.id, sub.code, sub.name ORDER BY sub.code");
    $breakdownStmt->execute([$studentId]);
    $subjectBreakdown = $breakdownStmt->fetchAll();

    $todaySubjectStmt = $pdo->prepare('SELECT COUNT(*) AS total,
            COALESCE(SUM(status = "present"), 0) AS present, COALESCE(SUM(status = "late"), 0) AS late,
            COALESCE(SUM(status = "absent"), 0) + COALESCE(SUM(status = "truant"), 0) AS missed
        FROM subject_attendance WHERE student_id = ? AND att_date = CURDATE()');
    $todaySubjectStmt->execute([$studentId]);
    $todaySubject = $todaySubjectStmt->fetch() ?: null;
}

require __DIR__ . '/includes/student-portal-top.php';
?>

<div class="page-heading">
  <div>
    <span class="hero-kicker dark"><?= icon('check-circle', 15) ?> เวลาเรียนของฉัน</span>
    <h1>ประวัติการเช็คชื่อ</h1>
    <p>แสดงเฉพาะข้อมูลของ <?= e(student_name($student, false)) ?> รหัส <?= e($student['student_code']) ?></p>
  </div>
  <span class="badge badge-<?= e($statusOfStudent['class']) ?>"><span class="dot"></span><?= e($statusOfStudent['label']) ?></span>
</div>

<?php if (!$portalTablesReady): ?>
  <div class="notice notice-warning mb-2"><?= icon('alert', 18) ?><div><strong>ยังไม่มีข้อมูลเช็คชื่อรายวิชา</strong><br>กรุณาให้เจ้าหน้าที่นำเข้าไฟล์ <code>database/student-portal.sql</code> เพื่อเปิดใช้งานประวัติรายวิชา</div></div>
<?php endif; ?>

<div class="grid grid-4 stat-grid mb-2">
  <article class="stat-card" style="--accent:#10b981;--accent-soft:#ecfdf5;--i:0"><div class="stat-icon"><?= icon('check', 22) ?></div><div class="stat-value num" data-count="<?= $flagCounts['present'] ?>">0</div><div class="stat-label">หน้าเสาธง · มาเรียน</div></article>
  <article class="stat-card" style="--accent:#f59e0b;--accent-soft:#fffbeb;--i:1"><div class="stat-icon"><?= icon('clock', 22) ?></div><div class="stat-value num" data-count="<?= $flagCounts['late'] ?>">0</div><div class="stat-label">หน้าเสาธง · มาสาย</div></article>
  <article class="stat-card" style="--accent:#3b82f6;--accent-soft:#eff6ff;--i:2"><div class="stat-icon"><?= icon('file', 22) ?></div><div class="stat-value num" data-count="<?= $flagCounts['sick'] + $flagCounts['business'] ?>">0</div><div class="stat-label">หน้าเสาธง · ลา</div></article>
  <article class="stat-card" style="--accent:#ef4444;--accent-soft:#fff1f2;--i:3"><div class="stat-icon"><?= icon('x-circle', 22) ?></div><div class="stat-value num" data-count="<?= $flagCounts['absent'] + $flagCounts['truant'] ?>">0</div><div class="stat-label">หน้าเสาธง · ขาด/หนี</div></article>
</div>

<div class="tabs portal-tabs" data-tab-group role="tablist" aria-label="ประวัติเช็คชื่อ">
  <button type="button" class="tab is-active" data-tab="flag" role="tab" aria-selected="true"><?= icon('users', 15) ?> หน้าเสาธง</button>
  <button type="button" class="tab" data-tab="subject" role="tab" aria-selected="false"><?= icon('book', 15) ?> รายวิชา</button>
</div>

<div class="tab-panel is-active" data-tab-panel="flag" id="tab-flag">
  <div class="grid grid-2-1">
    <article class="card">
      <div class="card-head bordered">
        <div><h3 class="card-title"><?= icon('calendar', 19) ?> ประวัติเช็คชื่อหน้าเสาธง</h3><p class="card-sub"><?= number_format($flagTotal) ?> ครั้ง · อัตรามาเรียน <?= number_format($flagRate, 1) ?>%</p></div>
        <div class="card-actions"><span class="badge badge-success"><span class="dot"></span><?= number_format($flagCounts['present'] + $flagCounts['late']) ?> ครั้งที่มา</span></div>
      </div>
      <div class="table-wrap" style="border:0;box-shadow:none;border-radius:0">
        <table class="table">
          <thead><tr><th>วันที่</th><th>วัน</th><th>สถานะ</th><th>ผู้บันทึก</th><th>หมายเหตุ</th></tr></thead>
          <tbody>
            <?php foreach ($flagHistory as $row): ?>
              <?php $meta = $statusMeta[$row['status']] ?? $statusMeta['present']; ?>
              <tr>
                <td class="text-sm"><?= e(thai_date($row['att_date'], 'short')) ?></td>
                <td class="text-sm text-muted">วัน<?= e(THAI_DAYS[(int) date('w', strtotime($row['att_date']))]) ?></td>
                <td><span class="badge badge-<?= e($badgeClass[$row['status']] ?? 'muted') ?>"><?= e($meta['label']) ?></span></td>
                <td class="text-sm text-muted"><?= e($row['recorder'] ?: '—') ?></td>
                <td class="text-sm text-muted"><?= e($row['note'] ?: '—') ?></td>
              </tr>
            <?php endforeach; ?>
            <?php if (!$flagHistory): ?><tr><td colspan="5"><div class="empty-state"><div class="empty-ico"><?= icon('calendar', 28) ?></div><h3>ยังไม่มีประวัติ</h3><p>เมื่อครูบันทึกการเช็คชื่อ ประวัติจะแสดงที่นี่</p></div></td></tr><?php endif; ?>
          </tbody>
        </table>
      </div>
    </article>

    <div class="stack">
      <article class="card">
        <div class="card-head"><div><h3 class="card-title"><?= icon('chart', 19) ?> อัตรามาเรียนหน้าเสาธง</h3><p class="card-sub">ตลอดปีการศึกษา</p></div></div>
        <div class="card-body" style="display:flex;flex-direction:column;align-items:center">
          <div class="donut-wrap">
            <svg class="donut-svg" viewBox="0 0 120 120" aria-hidden="true">
              <defs><linearGradient id="flagDonut" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#34d399"/><stop offset=".55" stop-color="#10b981"/><stop offset="1" stop-color="#0d9488"/></linearGradient></defs>
              <circle class="donut-track" cx="60" cy="60" r="48"/>
              <circle class="donut-value" cx="60" cy="60" r="48" data-donut="<?= round($flagRate, 1) ?>" style="stroke:url(#flagDonut)"/>
            </svg>
            <div class="donut-center"><b><?= number_format($flagRate, 1) ?><span style="font-size:.8rem">%</span></b><span>มาเรียน</span></div>
          </div>
          <div class="legend" style="width:100%;margin-top:16px">
            <?php foreach ($statusMeta as $key => $meta): ?>
              <div class="legend-item"><span class="swatch" style="background:<?= ['present' => '#10b981', 'late' => '#f59e0b', 'sick' => '#3b82f6', 'business' => '#8b5cf6', 'absent' => '#ef4444', 'truant' => '#be123c'][$key] ?>"></span><?= e($meta['label']) ?><b><?= number_format($flagCounts[$key]) ?></b></div>
            <?php endforeach; ?>
          </div>
        </div>
      </article>

      <article class="card">
        <div class="card-head"><div><h3 class="card-title"><?= icon('info', 19) ?> สรุปการเช็คชื่อ</h3></div></div>
        <div class="card-body" style="padding-top:6px">
          <div class="stack" style="gap:8px">
            <div class="kv-row"><span>จำนวนวันที่มีบันทึก</span><b><?= number_format($flagTotal) ?> วัน</b></div>
            <div class="kv-row"><span>มาเรียน / มาสาย</span><b><?= number_format($flagCounts['present']) ?> / <?= number_format($flagCounts['late']) ?> วัน</b></div>
            <div class="kv-row"><span>ลาป่วย / ลากิจ</span><b><?= number_format($flagCounts['sick']) ?> / <?= number_format($flagCounts['business']) ?> วัน</b></div>
            <div class="kv-row"><span>ขาดเรียน / หนีเรียน</span><b><?= number_format($flagCounts['absent']) ?> / <?= number_format($flagCounts['truant']) ?> วัน</b></div>
          </div>
        </div>
      </article>
    </div>
  </div>
</div>

<div class="tab-panel" data-tab-panel="subject" id="tab-subject">
  <?php if ($portalTablesReady): ?>
    <div class="grid grid-4 stat-grid mb-2">
      <article class="stat-card" style="--accent:#6366f1;--accent-soft:#eef2ff;--i:0"><div class="stat-icon"><?= icon('book', 22) ?></div><div class="stat-value num" data-count="<?= $subjectTotal ?>">0</div><div class="stat-label">คาบที่ถูกเช็คชื่อ</div></article>
      <article class="stat-card" style="--accent:#10b981;--accent-soft:#ecfdf5;--i:1"><div class="stat-icon"><?= icon('check', 22) ?></div><div class="stat-value num" data-count="<?= $subjectCounts['present'] ?>">0</div><div class="stat-label">มาเรียน</div></article>
      <article class="stat-card" style="--accent:#f59e0b;--accent-soft:#fffbeb;--i:2"><div class="stat-icon"><?= icon('clock', 22) ?></div><div class="stat-value num" data-count="<?= $subjectCounts['late'] ?>">0</div><div class="stat-label">มาสาย</div></article>
      <article class="stat-card" style="--accent:#ef4444;--accent-soft:#fff1f2;--i:3"><div class="stat-icon"><?= icon('x-circle', 22) ?></div><div class="stat-value num" data-count="<?= $subjectCounts['absent'] + $subjectCounts['truant'] ?>">0</div><div class="stat-label">ขาด / หนีเรียน</div></article>
    </div>

    <?php if ($todaySubject && (int) $todaySubject['total'] > 0): ?>
      <div class="notice notice-info mb-2">
        <?= icon('clock', 18) ?>
        <div><strong>วันนี้มีการเช็คชื่อรายวิชาแล้ว <?= (int) $todaySubject['total'] ?> คาบ</strong> · มา <?= (int) $todaySubject['present'] ?> · สาย <?= (int) $todaySubject['late'] ?> · ขาด <?= (int) $todaySubject['missed'] ?></div>
      </div>
    <?php endif; ?>

    <div class="grid grid-2-1">
      <article class="card">
        <div class="card-head bordered">
          <div><h3 class="card-title"><?= icon('book', 19) ?> ประวัติเช็คชื่อรายวิชา</h3><p class="card-sub">100 ระเบียนล่าสุด · <?= number_format($subjectTotal) ?> คาบ</p></div>
          <div class="card-actions"><span class="badge badge-brand"><?= number_format($subjectRate, 1) ?>% มาเรียน</span></div>
        </div>
        <div class="table-wrap" style="border:0;box-shadow:none;border-radius:0">
          <table class="table">
            <thead><tr><th>วันที่</th><th>คาบ</th><th>รายวิชา</th><th>สถานะ</th><th>ผู้บันทึก</th></tr></thead>
            <tbody>
              <?php foreach ($subjectHistory as $row): ?>
                <?php $meta = $statusMeta[$row['status']] ?? $statusMeta['present']; ?>
                <tr>
                  <td class="text-sm"><?= e(thai_date($row['att_date'], 'short')) ?></td>
                  <td class="text-center text-sm"><?= (int) $row['period'] ?></td>
                  <td><b style="font-weight:600;font-size:.8rem"><?= e($row['subject_name']) ?></b><small class="text-muted" style="display:block;font-size:.68rem"><?= e($row['code']) ?></small></td>
                  <td><span class="badge badge-<?= e($badgeClass[$row['status']] ?? 'muted') ?>"><?= e($meta['label']) ?></span></td>
                  <td class="text-sm text-muted"><?= e($row['recorder'] ?: '—') ?></td>
                </tr>
              <?php endforeach; ?>
              <?php if (!$subjectHistory): ?><tr><td colspan="5"><div class="empty-state"><div class="empty-ico"><?= icon('book', 28) ?></div><h3>ยังไม่มีประวัติรายวิชา</h3><p>เมื่อครูเช็คชื่อรายวิชา ประวัติจะแสดงที่นี่</p></div></td></tr><?php endif; ?>
            </tbody>
          </table>
        </div>
      </article>

      <div class="stack">
        <article class="card">
          <div class="card-head"><div><h3 class="card-title"><?= icon('chart', 19) ?> สรุปรายวิชา</h3><p class="card-sub">อัตราการเข้าเรียนแต่ละวิชา</p></div></div>
          <div class="card-body" style="padding-top:6px">
            <?php if ($subjectBreakdown): ?>
              <div class="stack" style="gap:12px">
                <?php foreach ($subjectBreakdown as $subjectRow): ?>
                  <?php $rate = (int) $subjectRow['total'] > 0 ? ((int) $subjectRow['present'] + (int) $subjectRow['late']) / (int) $subjectRow['total'] * 100 : 0; ?>
                  <div class="subject-stat">
                    <div class="subject-stat-head">
                      <span><b><?= e($subjectRow['name']) ?></b><small><?= e($subjectRow['code']) ?> · <?= (int) $subjectRow['total'] ?> คาบ</small></span>
                      <span class="badge badge-<?= $rate >= 80 ? 'success' : ($rate >= 60 ? 'warning' : 'danger') ?>"><?= number_format($rate, 0) ?>%</span>
                    </div>
                    <div class="score-meter"><span style="width:<?= number_format(min(100, max(0, $rate)), 1, '.', '') ?>%;background:linear-gradient(90deg,#6366f1,#8b5cf6)"></span></div>
                    <div class="subject-stat-foot"><span>มา <?= (int) $subjectRow['present'] ?> · สาย <?= (int) $subjectRow['late'] ?></span><span>ขาด <?= (int) $subjectRow['missed'] ?></span></div>
                  </div>
                <?php endforeach; ?>
              </div>
            <?php else: ?>
              <div class="empty-state" style="padding:24px 12px"><p>ยังไม่มีข้อมูลรายวิชา</p></div>
            <?php endif; ?>
          </div>
        </article>

        <article class="card">
          <div class="card-head"><div><h3 class="card-title"><?= icon('info', 19) ?> สรุปการเช็คชื่อรายวิชา</h3></div></div>
          <div class="card-body" style="padding-top:6px">
            <div class="stack" style="gap:8px">
              <div class="kv-row"><span>คาบทั้งหมด</span><b><?= number_format($subjectTotal) ?> คาบ</b></div>
              <div class="kv-row"><span>ลาป่วย / ลากิจ</span><b><?= number_format($subjectCounts['sick']) ?> / <?= number_format($subjectCounts['business']) ?> คาบ</b></div>
              <div class="kv-row"><span>ขาด / หนีเรียน</span><b><?= number_format($subjectCounts['absent']) ?> / <?= number_format($subjectCounts['truant']) ?> คาบ</b></div>
              <div class="kv-row"><span>อัตราการเข้าเรียน</span><b><?= number_format($subjectRate, 1) ?>%</b></div>
            </div>
          </div>
        </article>
      </div>
    </div>
  <?php else: ?>
    <div class="empty-state card"><div class="empty-ico"><?= icon('book', 30) ?></div><h3>ยังไม่มีข้อมูลเช็คชื่อรายวิชา</h3><p>กรุณาให้เจ้าหน้าที่นำเข้า database/student-portal.sql</p></div>
  <?php endif; ?>
</div>

<?php require __DIR__ . '/includes/student-portal-bottom.php'; ?>
