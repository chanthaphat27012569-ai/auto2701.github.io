<?php

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/includes/functions.php';

$sqlFile = __DIR__ . '/database/database.sql';
$portalSqlFile = __DIR__ . '/database/student-portal.sql';
$sqlFiles = [$sqlFile, $portalSqlFile];
$sqlReady = is_file($sqlFile) && is_file($portalSqlFile);
$checks = [
    'php' => ['label' => 'PHP 8.0 ขึ้นไป', 'ok' => version_compare(PHP_VERSION, '8.0.0', '>='), 'value' => PHP_VERSION],
    'pdo' => ['label' => 'ส่วนขยาย PDO MySQL', 'ok' => extension_loaded('pdo_mysql'), 'value' => extension_loaded('pdo_mysql') ? 'พร้อมใช้งาน' : 'ไม่พบ extension'],
    'sql' => ['label' => 'ไฟล์ฐานข้อมูล', 'ok' => $sqlReady, 'value' => $sqlReady ? number_format((int) (filesize($sqlFile) + filesize($portalSqlFile)) / 1024, 0) . ' KB · 2 ไฟล์' : 'ไม่พบ database.sql หรือ student-portal.sql'],
];

$pdo = null;
$connectError = '';
$directDb = false;
$pdoOptions = [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, PDO::ATTR_TIMEOUT => 10];

// Shared hosting usually blocks CREATE DATABASE; connect straight to the assigned database.
try {
    $pdo = new PDO(
        sprintf('mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4', DB_HOST, DB_PORT, DB_NAME),
        DB_USER,
        DB_PASS,
        $pdoOptions
    );
    $directDb = true;
    $checks['mysql'] = ['label' => 'เชื่อมต่อฐานข้อมูล', 'ok' => true, 'value' => DB_NAME . ' · เชื่อมต่อสำเร็จ'];
} catch (PDOException $e) {
    $connectError = $e->getMessage();
}

$dbExists = false;
$installed = false;
if ($directDb) {
    $dbExists = true;
    $installed = (bool) $pdo->query("SHOW TABLES LIKE 'users'")->fetchColumn();
} else {
    try {
        $pdo = new PDO(
            sprintf('mysql:host=%s;port=%s;charset=utf8mb4', DB_HOST, DB_PORT),
            DB_USER,
            DB_PASS,
            $pdoOptions
        );
        $checks['mysql'] = ['label' => 'เชื่อมต่อ MySQL / MariaDB', 'ok' => true, 'value' => 'เชื่อมต่อเซิร์ฟเวอร์สำเร็จ'];
        $stmt = $pdo->prepare('SELECT COUNT(*) FROM information_schema.schemata WHERE schema_name = ?');
        $stmt->execute([DB_NAME]);
        $dbExists = (int) $stmt->fetchColumn() > 0;
        if ($dbExists) {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = ? AND table_name = 'users'");
            $stmt->execute([DB_NAME]);
            $installed = (int) $stmt->fetchColumn() > 0;
        }
    } catch (PDOException $e) {
        $pdo = null;
        $checks['mysql'] = ['label' => 'เชื่อมต่อ MySQL / MariaDB', 'ok' => false, 'value' => 'เชื่อมต่อไม่ได้'];
        $connectError = $e->getMessage();
    }
}

$allReady = $checks['php']['ok'] && $checks['pdo']['ok'] && $checks['sql']['ok'] && $checks['mysql']['ok'];
$error = '';
$done = false;
$imported = 0;

function install_split_sql(string $sql): array
{
    $statements = [];
    $buffer = '';
    $length = strlen($sql);
    $single = false;
    $double = false;
    $backtick = false;
    $lineComment = false;
    $blockComment = false;

    for ($i = 0; $i < $length; $i++) {
        $ch = $sql[$i];
        $next = $i + 1 < $length ? $sql[$i + 1] : '';

        if ($lineComment) {
            if ($ch === "\n") {
                $lineComment = false;
            }
            continue;
        }
        if ($blockComment) {
            if ($ch === '*' && $next === '/') {
                $blockComment = false;
                $i++;
            }
            continue;
        }
        if ($ch === '\\' && ($single || $double)) {
            $buffer .= $ch . $next;
            $i++;
            continue;
        }
        if (!$single && !$double && !$backtick) {
            if ($ch === '-' && $next === '-') {
                $lineComment = true;
                $i++;
                continue;
            }
            if ($ch === '#') {
                $lineComment = true;
                continue;
            }
            if ($ch === '/' && $next === '*') {
                $blockComment = true;
                $i++;
                continue;
            }
            if ($ch === ';') {
                if (trim($buffer) !== '') {
                    $statements[] = trim($buffer);
                }
                $buffer = '';
                continue;
            }
        }
        if ($ch === "'" && !$double && !$backtick) {
            $single = !$single;
        } elseif ($ch === '"' && !$single && !$backtick) {
            $double = !$double;
        } elseif ($ch === '`' && !$single && !$double) {
            $backtick = !$backtick;
        }
        $buffer .= $ch;
    }
    if (trim($buffer) !== '') {
        $statements[] = trim($buffer);
    }
    return $statements;
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST' && isset($_POST['install'])) {
    if (!$allReady) {
        $error = 'กรุณาแก้ไขข้อกำหนดของระบบให้ครบก่อนติดตั้ง';
    } elseif ($installed && !isset($_POST['force'])) {
        $error = 'พบฐานข้อมูลที่ติดตั้งแล้ว หากต้องการติดตั้งใหม่ทั้งหมด กรุณายืนยันการลบข้อมูลเดิม';
    } else {
        @set_time_limit(120);
        try {
            $portalTables = [
                'elective_registrations', 'club_registrations', 'clubs', 'activity_attendance',
                'activities', 'behavior_records', 'subject_attendance', 'timetable', 'student_profiles',
            ];
            $pdo->exec('SET FOREIGN_KEY_CHECKS = 0');
            foreach ($portalTables as $table) {
                $pdo->exec('DROP TABLE IF EXISTS `' . $table . '`');
            }
            $pdo->exec('SET FOREIGN_KEY_CHECKS = 1');

            $quoted = '`' . str_replace('`', '``', DB_NAME) . '`';
            foreach ($sqlFiles as $file) {
                if (!is_file($file)) {
                    continue;
                }
                $sql = (string) file_get_contents($file);
                $sql = preg_replace('/CREATE DATABASE IF NOT EXISTS `[^`]+`/i', 'CREATE DATABASE IF NOT EXISTS ' . $quoted, $sql, 1);
                $sql = preg_replace('/^USE `[^`]+`;/mi', 'USE ' . $quoted . ';', $sql, 1);

                $statements = install_split_sql($sql);
                foreach ($statements as $statement) {
                    $trimmed = ltrim($statement);
                    if ($directDb && preg_match('/^(CREATE\s+DATABASE|USE\s+)/i', $trimmed)) {
                        continue;
                    }
                    $pdo->exec($statement);
                    $imported++;
                    if (preg_match('/^CREATE TABLE/i', $trimmed)) {
                        $installed = true;
                    }
                }
            }
            $done = true;
            $installed = true;
        } catch (Throwable $e) {
            $error = 'ติดตั้งไม่สำเร็จ: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ติดตั้งระบบ · <?= e(APP_TITLE) ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Itim&family=Sarabun:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<style>
  * { box-sizing: border-box; }
  body {
    margin: 0; min-height: 100vh; display: grid; place-items: center; padding: 28px;
    font-family: 'Sarabun', sans-serif; color: #1e1b4b;
    background: radial-gradient(1200px 600px at 8% -10%, #e0e7ff 0%, transparent 55%),
                radial-gradient(900px 500px at 100% 0%, #fce7f3 0%, transparent 50%),
                radial-gradient(900px 600px at 50% 120%, #d1fae5 0%, transparent 55%), #eef1fb;
    overflow-x: hidden;
  }
  .orb { position: fixed; border-radius: 50%; filter: blur(28px); opacity: .45; animation: float 12s ease-in-out infinite; pointer-events: none; }
  .orb.o1 { width: 320px; height: 320px; background: #c7d2fe; top: -80px; left: -60px; }
  .orb.o2 { width: 260px; height: 260px; background: #fbcfe8; right: -70px; bottom: 40px; animation-delay: -4s; }
  .orb.o3 { width: 200px; height: 200px; background: #a7f3d0; left: 55%; top: 8%; animation-delay: -7s; }
  @keyframes float { 0%,100% { transform: translateY(0) scale(1); } 50% { transform: translateY(-26px) scale(1.06); } }
  @keyframes pop { from { opacity: 0; transform: translateY(20px) scale(.98); } to { opacity: 1; transform: none; } }
  @keyframes shine { from { transform: translateX(-120%) rotate(18deg); } to { transform: translateX(220%) rotate(18deg); } }
  .shell { position: relative; width: min(980px, 100%); display: grid; grid-template-columns: 1.05fr .95fr; gap: 0; border-radius: 28px; overflow: hidden; background: #fff; box-shadow: 0 40px 100px rgba(49, 46, 129, .22); animation: pop .55s cubic-bezier(.22,1,.36,1) both; }
  .brand { position: relative; overflow: hidden; padding: 38px 36px; color: #fff; background: linear-gradient(150deg, #4338ca 0%, #6d28d9 45%, #db2777 100%); }
  .brand::before, .brand::after { content: ''; position: absolute; border-radius: 50%; background: rgba(255,255,255,.12); }
  .brand::before { width: 260px; height: 260px; right: -110px; top: -100px; animation: float 9s ease-in-out infinite; }
  .brand::after { width: 170px; height: 170px; left: -70px; bottom: -60px; animation: float 11s ease-in-out infinite reverse; }
  .logo { width: 64px; height: 64px; border-radius: 18px; background: rgba(255,255,255,.16); border: 1px solid rgba(255,255,255,.3); display: grid; place-items: center; margin-bottom: 22px; backdrop-filter: blur(6px); }
  .kicker { font-size: .66rem; letter-spacing: 2.2px; text-transform: uppercase; opacity: .75; }
  .brand h1 { font-size: 1.75rem; line-height: 1.25; margin: 8px 0 10px; letter-spacing: -.4px; }
  .brand h1 span { color: #fde68a; }
  .brand p { font-size: .85rem; line-height: 1.7; opacity: .82; margin: 0 0 24px; }
  .feature { display: flex; align-items: center; gap: 11px; padding: 10px 12px; border-radius: 13px; background: rgba(255,255,255,.1); border: 1px solid rgba(255,255,255,.14); margin-bottom: 9px; font-size: .8rem; }
  .feature i { width: 30px; height: 30px; border-radius: 9px; background: rgba(255,255,255,.18); display: grid; place-items: center; font-style: normal; font-size: .85rem; }
  .brand-foot { margin-top: 26px; font-size: .68rem; opacity: .65; display: flex; align-items: center; gap: 7px; }
  .dot { width: 7px; height: 7px; border-radius: 50%; background: #6ee7b7; box-shadow: 0 0 0 4px rgba(110,231,183,.22); }
  .panel { padding: 34px 34px 30px; }
  .panel h2 { margin: 0 0 4px; font-size: 1.22rem; letter-spacing: -.3px; }
  .panel .sub { margin: 0 0 20px; font-size: .8rem; color: #64748b; }
  .checks { display: flex; flex-direction: column; gap: 9px; margin-bottom: 20px; }
  .check { display: flex; align-items: center; gap: 11px; padding: 11px 13px; border: 1px solid #e8ecf8; border-radius: 13px; background: #fbfcff; transition: all .2s ease; }
  .check:hover { transform: translateX(2px); border-color: #dbe2f5; }
  .check .ico { width: 32px; height: 32px; border-radius: 10px; display: grid; place-items: center; font-size: .9rem; flex-shrink: 0; }
  .ok .ico { background: #ecfdf5; color: #059669; }
  .bad .ico { background: #fff1f2; color: #e11d48; }
  .check b { display: block; font-size: .78rem; font-weight: 700; }
  .check small { display: block; font-size: .68rem; color: #94a3b8; }
  .check .state { margin-left: auto; font-size: .64rem; font-weight: 800; padding: 3px 9px; border-radius: 99px; }
  .ok .state { background: #d1fae5; color: #047857; }
  .bad .state { background: #ffe4e6; color: #9f1239; }
  .field { margin-bottom: 13px; }
  .field label { display: block; font-size: .7rem; font-weight: 700; color: #475569; margin-bottom: 5px; }
  .input { width: 100%; padding: 10px 12px; border: 1px solid #e2e8f0; border-radius: 10px; background: #f8fafc; font-family: inherit; font-size: .8rem; color: #334155; }
  .btn { position: relative; overflow: hidden; width: 100%; display: inline-flex; align-items: center; justify-content: center; gap: 8px; padding: 13px 18px; border: none; border-radius: 13px; background: linear-gradient(135deg, #4f46e5, #7c3aed); color: #fff; font-family: inherit; font-size: .9rem; font-weight: 800; cursor: pointer; box-shadow: 0 12px 26px rgba(79, 70, 229, .3); transition: transform .2s ease, box-shadow .2s ease; text-decoration: none; }
  .btn:hover { transform: translateY(-2px); box-shadow: 0 16px 34px rgba(79, 70, 229, .36); }
  .btn::after { content: ''; position: absolute; top: -40%; left: 0; width: 40%; height: 180%; background: linear-gradient(90deg, transparent, rgba(255,255,255,.35), transparent); animation: shine 3.4s ease-in-out infinite; }
  .btn.ghost { background: #fff; color: #4f46e5; border: 1px solid #dfe4f5; box-shadow: none; }
  .btn.ghost::after { display: none; }
  .btn.danger { background: linear-gradient(135deg, #e11d48, #be123c); box-shadow: 0 12px 26px rgba(225, 29, 72, .25); }
  .btn-row { display: grid; grid-template-columns: 1fr 1fr; gap: 9px; margin-top: 14px; }
  .alert { padding: 12px 14px; border-radius: 12px; font-size: .78rem; line-height: 1.6; margin-bottom: 16px; border: 1px solid; }
  .alert.error { background: #fff1f2; border-color: #fecdd3; color: #9f1239; }
  .alert.success { background: #ecfdf5; border-color: #a7f3d0; color: #047857; }
  .alert.info { background: #eff6ff; border-color: #bfdbfe; color: #1e40af; }
  .warn { display: flex; gap: 9px; padding: 11px 13px; border-radius: 12px; background: #fffbeb; border: 1px solid #fde68a; color: #92400e; font-size: .74rem; line-height: 1.55; margin-bottom: 14px; }
  .checkbox { display: flex; gap: 9px; align-items: flex-start; font-size: .74rem; color: #9f1239; line-height: 1.5; margin-bottom: 14px; }
  .checkbox input { margin-top: 3px; accent-color: #e11d48; }
  .demo { margin-top: 16px; padding: 13px 14px; border-radius: 13px; background: #f8fafc; border: 1px dashed #cbd5e1; font-size: .72rem; color: #475569; line-height: 1.7; }
  .demo b { color: #1e1b4b; }
  .demo code { background: #eef2ff; color: #4338ca; padding: 1px 6px; border-radius: 5px; font-family: ui-monospace, monospace; }
  .links { display: flex; gap: 10px; margin-top: 14px; }
  .links .btn { font-size: .8rem; padding: 11px 14px; }
  @media (max-width: 820px) { .shell { grid-template-columns: 1fr; } .brand { padding: 28px; } .brand .features { display: none; } .panel { padding: 26px; } }
</style>
</head>
<body>
<span class="orb o1"></span><span class="orb o2"></span><span class="orb o3"></span>

<div class="shell">
  <aside class="brand">
    <div class="logo">
      <svg width="38" height="38" viewBox="0 0 100 100" fill="none" aria-hidden="true">
        <path d="M50 14L18 35V79C18 81.2 19.8 83 22 83H78C80.2 83 82 81.2 82 79V35L50 14Z" fill="#FDE68A"/>
        <path d="M50 14L82 35H18L50 14Z" fill="#F59E0B"/>
        <circle cx="50" cy="41" r="10" fill="#fff"/><circle cx="50" cy="41" r="7.6" fill="#F8FAFC"/>
        <rect x="28" y="57" width="13" height="13" rx="3.5" fill="#38BDF8"/>
        <rect x="59" y="57" width="13" height="13" rx="3.5" fill="#38BDF8"/>
        <path d="M43 83V66C43 64.3 44.3 63 46 63H54C55.7 63 57 64.3 57 66V83H43Z" fill="#EC4899"/>
      </svg>
    </div>
    <span class="kicker">Smart School Management</span>
    <h1>ติดตั้ง <span>SMS School</span><br>ในคลิกเดียว</h1>
    <p>สร้างฐานข้อมูล MySQL นำเข้าโครงสร้างและข้อมูลตัวอย่าง พร้อมใช้งานทันที ทั้งระบบเช็คชื่อ ผลการเรียน เอกสาร ปพ. และพอร์ทัลนักเรียน</p>

    <div class="features">
      <div class="feature"><i>✓</i><span>ฐานข้อมูล 17 ตาราง พร้อมความสัมพันธ์ครบถ้วน</span></div>
      <div class="feature"><i>👥</i><span>นักเรียนตัวอย่าง 48 คน · 6 ชั้นเรียน · 15 รายวิชา</span></div>
      <div class="feature"><i>📊</i><span>ข้อมูลเช็คชื่อ ผลการเรียน พฤติกรรม และกิจกรรมย้อนหลัง</span></div>
      <div class="feature"><i>🎓</i><span>พอร์ทัลนักเรียนครบ: โปรไฟล์ ตารางเรียน ชุมนุม วิชาเพิ่มเติม</span></div>
      <div class="feature"><i>🔐</i><span>บัญชีผู้ใช้ 8 บทบาท พร้อมระบบสิทธิ์</span></div>
    </div>

    <div class="brand-foot"><span class="dot"></span> ทำงานบน PHP <?= e(PHP_VERSION) ?> · MySQL / MariaDB</div>
  </aside>

  <main class="panel">
    <h2><?= $done ? 'ติดตั้งสำเร็จแล้ว' : 'เตรียมความพร้อมระบบ' ?></h2>
    <p class="sub"><?= $done ? 'ฐานข้อมูลพร้อมใช้งาน เริ่มเข้าสู่ระบบได้ทันที' : 'ตรวจสอบข้อกำหนดและตั้งค่าฐานข้อมูลก่อนติดตั้ง' ?></p>

    <?php if ($error !== ''): ?>
      <div class="alert error"><?= e($error) ?></div>
    <?php endif; ?>

    <?php if ($done): ?>
      <div class="alert success">นำเข้าฐานข้อมูล <b><?= e(DB_NAME) ?></b> สำเร็จ <?= number_format($imported) ?> คำสั่ง พร้อมข้อมูลตัวอย่างครบถ้วน</div>
      <div class="demo">
        <b>บัญชีทดลองใช้งาน</b><br>
        ผู้ดูแลระบบ <code>admin</code> · รหัสผ่าน <code>1234</code><br>
        ครูผู้สอน <code>teacher.sunee</code> · รหัสผ่าน <code>1234</code><br>
        นักเรียน <code>1001</code> · PIN <code>1001</code>
      </div>
      <div class="links">
        <a class="btn" href="<?= url('login.php') ?>">เข้าสู่ระบบ →</a>
        <a class="btn ghost" href="<?= url('install.php') ?>">ตรวจสอบอีกครั้ง</a>
      </div>
    <?php else: ?>
      <div class="checks">
        <?php foreach ($checks as $key => $check): ?>
          <div class="check <?= $check['ok'] ? 'ok' : 'bad' ?>">
            <span class="ico"><?= $check['ok'] ? '✓' : '!' ?></span>
            <span><b><?= e($check['label']) ?></b><small><?= e($check['value']) ?></small></span>
            <span class="state"><?= $check['ok'] ? 'พร้อม' : 'ต้องแก้ไข' ?></span>
          </div>
        <?php endforeach; ?>
      </div>

      <?php if ($connectError !== ''): ?>
        <div class="warn">⚠ <?= e($connectError) ?><br>ตรวจสอบว่า MySQL ใน XAMPP เปิดอยู่ และค่าเชื่อมต่อใน config/config.php ถูกต้อง</div>
      <?php endif; ?>

      <?php if (!$checks['sql']['ok']): ?>
        <div class="warn">⚠ ไม่พบไฟล์ database/database.sql กรุณาวางไฟล์ SQL ไว้ในโฟลเดอร์ database ของแอป</div>
      <?php elseif ($installed): ?>
        <div class="alert info">พบฐานข้อมูล <b><?= e(DB_NAME) ?></b> ที่ติดตั้งแล้ว หากต้องการใช้งานต่อสามารถเข้าสู่ระบบได้ทันที</div>
        <div class="links">
          <a class="btn" href="<?= url('login.php') ?>">เข้าสู่ระบบ →</a>
        </div>

        <form method="post" style="margin-top:18px" onsubmit="return confirm('ยืนยันการติดตั้งใหม่? ข้อมูลเดิมทั้งหมดจะถูกลบและแทนที่ด้วยข้อมูลตัวอย่าง');">
          <div class="checkbox">
            <input type="checkbox" id="force" name="force" value="1" required>
            <label for="force">ฉันเข้าใจว่าการติดตั้งใหม่จะ<b>ลบข้อมูลเดิมทั้งหมด</b>ในฐานข้อมูล <?= e(DB_NAME) ?> และแทนที่ด้วยข้อมูลตัวอย่าง</label>
          </div>
          <button class="btn danger" type="submit" name="install" value="1">ติดตั้งใหม่ทั้งหมด (ลบข้อมูลเดิม)</button>
        </form>
      <?php else: ?>
        <div class="field">
          <label>ฐานข้อมูลเป้าหมาย</label>
          <input class="input" value="<?= e(DB_NAME) ?> · <?= e(DB_HOST) ?>:<?= e(DB_PORT) ?> · ผู้ใช้ <?= e(DB_USER) ?>" readonly>
        </div>
        <div class="alert info" style="margin-top:4px">ระบบจะสร้างฐานข้อมูล (หากยังไม่มี) และนำเข้าโครงสร้างพร้อมข้อมูลตัวอย่างโดยอัตโนมัติ</div>
        <form method="post">
          <button class="btn" type="submit" name="install" value="1" <?= $allReady ? '' : 'disabled style="opacity:.55;cursor:not-allowed"' ?>>ติดตั้งระบบเลย →</button>
        </form>
      <?php endif; ?>

      <div class="demo">
        <b>ข้อมูลตัวอย่างหลังติดตั้ง</b><br>
        ผู้ดูแลระบบ <code>admin</code> / <code>1234</code> · ครู <code>teacher.sunee</code> / <code>1234</code><br>
        นักเรียน <code>1001</code> / PIN <code>1001</code>
      </div>
    <?php endif; ?>
  </main>
</div>
</body>
</html>
