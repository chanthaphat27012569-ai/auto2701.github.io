<?php

require_once __DIR__ . '/includes/bootstrap.php';

$user = require_staff();
$pdo = db();
$statusMeta = attendance_meta();

$classes = $pdo->query("SELECT id, name FROM classes WHERE status = 'active' ORDER BY name")->fetchAll();
$classId = get_int('class_id');
if ($classId <= 0 && $classes) {
    $classId = (int) $classes[0]['id'];
}

$date = get_str('date');
if ($date === '' || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
    $date = date('Y-m-d');
}
try {
    $dateObj = new DateTime($date);
} catch (Exception $e) {
    $date = date('Y-m-d');
    $dateObj = new DateTime($date);
}

if (is_post()) {
    verify_csrf();
    $action = post_str('action');

    if ($action === 'save') {
        $postClass = (int) ($_POST['class_id'] ?? 0);
        $postDate = post_str('att_date');
        $entries = is_array($_POST['entries'] ?? null) ? $_POST['entries'] : [];
        $validDate = preg_match('/^\d{4}-\d{2}-\d{2}$/', $postDate) === 1;

        if ($postClass <= 0 || !$validDate) {
            flash('danger', 'ข้อมูลชั้นเรียนหรือวันที่ไม่ถูกต้อง');
            redirect('attendance.php?class_id=' . $postClass . '&date=' . urlencode($postDate));
        }

        $stmt = $pdo->prepare("SELECT id FROM students WHERE class_id = ? AND status = 'studying'");
        $stmt->execute([$postClass]);
        $validIds = array_map('intval', array_column($stmt->fetchAll(), 'id'));

        $allowed = array_keys($statusMeta);
        $saved = 0;
        $pdo->beginTransaction();
        try {
            $upsert = $pdo->prepare("INSERT INTO attendance (student_id, class_id, att_date, status, note, recorded_by)
                VALUES (?, ?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE status = VALUES(status), class_id = VALUES(class_id), recorded_by = VALUES(recorded_by)");
            foreach ($validIds as $studentId) {
                $status = (string) ($entries[$studentId] ?? '');
                if (!in_array($status, $allowed, true)) {
                    continue;
                }
                $upsert->execute([$studentId, $postClass, $postDate, $status, '', (int) $user['id']]);
                $saved++;
            }
            $pdo->commit();
            flash('success', 'บันทึกการเช็คชื่อ ' . $saved . ' คน วันที่ ' . thai_date($postDate, 'short') . ' เรียบร้อยแล้ว');
        } catch (Throwable $e) {
            $pdo->rollBack();
            flash('danger', 'ไม่สามารถบันทึกการเช็คชื่อได้ กรุณาลองใหม่อีกครั้ง');
        }
        redirect('attendance.php?class_id=' . $postClass . '&date=' . urlencode($postDate));
    }

    if ($action === 'clear') {
        require_manage();
        $postClass = (int) ($_POST['class_id'] ?? 0);
        $postDate = post_str('att_date');
        if ($postClass > 0 && preg_match('/^\d{4}-\d{2}-\d{2}$/', $postDate)) {
            $stmt = $pdo->prepare('DELETE FROM attendance WHERE class_id = ? AND att_date = ?');
            $stmt->execute([$postClass, $postDate]);
            flash('warning', 'ล้างข้อมูลเช็คชื่อวันที่ ' . thai_date($postDate, 'short') . ' แล้ว');
        }
        redirect('attendance.php?class_id=' . $postClass . '&date=' . urlencode($postDate));
    }
}

$students = [];
$existing = [];
if ($classId > 0) {
    $stmt = $pdo->prepare("SELECT id, student_code, prefix, firstname, lastname, student_number, gender
        FROM students WHERE class_id = ? AND status = 'studying'
        ORDER BY student_number, student_code");
    $stmt->execute([$classId]);
    $students = $stmt->fetchAll();

    $stmt = $pdo->prepare('SELECT student_id, status FROM attendance WHERE class_id = ? AND att_date = ?');
    $stmt->execute([$classId, $date]);
    foreach ($stmt->fetchAll() as $row) {
        $existing[(int) $row['student_id']] = $row['status'];
    }
}

$counts = ['present' => 0, 'late' => 0, 'sick' => 0, 'business' => 0, 'absent' => 0, 'truant' => 0];
foreach ($students as $student) {
    $status = $existing[(int) $student['id']] ?? 'present';
    $counts[$status] = ($counts[$status] ?? 0) + 1;
}
$total = count($students);
$rate = attendance_rate($counts);
$classNames = array_column($classes, 'name', 'id');
$currentClass = $classNames[$classId] ?? 'ไม่ระบุชั้นเรียน';

$pageTitle = 'เช็คชื่อประจำวัน';
$pageSubtitle = 'บันทึกเวลาเรียนรายวัน พร้อมสรุปอัตรามาเรียนแบบทันที';
$activeNav = 'attendance';
$pageActions = '<a class="btn btn-ghost btn-sm" href="' . url('attendance-report.php?class_id=' . $classId . '&month=' . substr($date, 0, 7)) . '">' . icon('chart', 16) . '<span>รายงานเดือน</span></a>';

require_once __DIR__ . '/includes/header.php';
?>

<form class="att-toolbar" method="get" action="<?= url('attendance.php') ?>">
  <div class="field">
    <label><?= icon('building', 14) ?> ชั้นเรียน</label>
    <select class="select" name="class_id">
      <?php foreach ($classes as $class): ?>
        <option value="<?= (int) $class['id'] ?>" <?= $classId === (int) $class['id'] ? 'selected' : '' ?>><?= e($class['name']) ?></option>
      <?php endforeach; ?>
    </select>
  </div>
  <div class="field">
    <label><?= icon('calendar', 14) ?> วันที่เช็คชื่อ</label>
    <input class="input" type="date" name="date" value="<?= e($date) ?>" max="<?= date('Y-m-d', strtotime('+7 days')) ?>">
  </div>
  <div class="row">
    <a class="icon-btn" href="<?= url('attendance.php?class_id=' . $classId . '&date=' . prev_school_day($date)) ?>" title="วันทำการก่อนหน้า"><?= icon('arrow-left', 17) ?></a>
    <a class="icon-btn" href="<?= url('attendance.php?class_id=' . $classId . '&date=' . next_school_day($date)) ?>" title="วันทำการถัดไป"><?= icon('arrow-right', 17) ?></a>
  </div>
  <button class="btn btn-primary" type="submit"><?= icon('refresh', 16) ?> เปิดรายชื่อ</button>
</form>

<div class="row-between mb-2 wrap">
  <div>
    <h2 style="font-size:1.1rem;font-weight:800;display:flex;align-items:center;gap:8px"><?= icon('check', 20) ?> <?= e($currentClass) ?></h2>
    <p class="text-sm text-muted"><?= e(thai_date($date, 'day')) ?> · <?= number_format($total) ?> คน · บันทึกโดย <?= e($user['fullname']) ?></p>
  </div>
  <div class="row">
    <span class="chip chip-soft"><span class="dot"></span><?= $existing ? 'บันทึกแล้วบางส่วน' : 'ยังไม่ได้บันทึก' ?></span>
    <?php if ($dateObj->format('N') >= 6): ?><span class="badge badge-warning"><?= icon('alert', 13) ?> วันหยุดสุดสัปดาห์</span><?php endif; ?>
  </div>
</div>

<?php if (!$classes): ?>
  <div class="card"><div class="empty-state"><div class="empty-ico"><?= icon('building', 30) ?></div><h3>ยังไม่มีชั้นเรียน</h3><p>เพิ่มชั้นเรียนก่อนเริ่มเช็คชื่อ</p><a class="btn btn-primary btn-sm" href="<?= url('classes.php?new=1') ?>">เพิ่มชั้นเรียน</a></div></div>
<?php elseif (!$students): ?>
  <div class="card"><div class="empty-state"><div class="empty-ico"><?= icon('users', 30) ?></div><h3>ยังไม่มีนักเรียนในชั้นนี้</h3><p>เพิ่มข้อมูลนักเรียนหรือเลือกชั้นเรียนอื่น</p><a class="btn btn-primary btn-sm" href="<?= url('student-form.php') ?>">เพิ่มนักเรียน</a></div></div>
<?php else: ?>
<div class="grid grid-1-2">
  <div class="stack">
    <article class="card">
      <div class="card-head">
        <div><h3 class="card-title"><?= icon('chart', 19) ?> สรุปวันนี้</h3><p class="card-sub"><?= e(thai_date($date, 'short')) ?></p></div>
        <div class="card-actions"><span class="badge badge-brand"><?= e($currentClass) ?></span></div>
      </div>
      <div class="card-body">
        <div style="display:flex;justify-content:center;margin-bottom:16px">
          <div class="donut-wrap">
            <svg class="donut-svg" viewBox="0 0 120 120" aria-hidden="true">
              <defs><linearGradient id="attDonut" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#34d399"/><stop offset="0.55" stop-color="#10b981"/><stop offset="1" stop-color="#0d9488"/></linearGradient></defs>
              <circle class="donut-track" cx="60" cy="60" r="48"/>
              <circle class="donut-value" cx="60" cy="60" r="48" data-att-donut style="stroke:url(#attDonut)"/>
            </svg>
            <div class="donut-center"><b data-att-rate><?= number_format($rate, 1) ?>%</b><span>มาเรียน</span></div>
          </div>
        </div>
        <div class="legend">
          <?php $colors = ['present' => '#10b981', 'late' => '#f59e0b', 'sick' => '#3b82f6', 'business' => '#8b5cf6', 'absent' => '#ef4444', 'truant' => '#be123c']; ?>
          <?php foreach ($statusMeta as $key => $meta): ?>
            <div class="legend-item"><span class="swatch" style="background:<?= $colors[$key] ?>"></span><?= e($meta['label']) ?><b data-att-count="<?= e($key) ?>"><?= (int) $counts[$key] ?></b></div>
          <?php endforeach; ?>
          <div class="legend-item" style="border-top:1px dashed var(--line);padding-top:9px;margin-top:3px"><span class="swatch" style="background:#94a3b8"></span>รวมทั้งหมด<b data-att-total><?= $total ?></b></div>
        </div>
      </div>
    </article>
    <div class="notice notice-info">
      <?= icon('info', 18) ?>
      <div><strong>เคล็ดลับ</strong> กดปุ่ม “มาเรียนทั้งหมด” แล้วแก้เฉพาะนักเรียนที่มาสายหรือขาดเรียน จะบันทึกได้เร็วขึ้น</div>
    </div>
  </div>

  <form method="post" action="<?= url('attendance.php?class_id=' . $classId . '&date=' . urlencode($date)) ?>" class="card">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="save">
    <input type="hidden" name="class_id" value="<?= $classId ?>">
    <input type="hidden" name="att_date" value="<?= e($date) ?>">

    <div class="card-head bordered">
      <div>
        <h3 class="card-title"><?= icon('users', 19) ?> รายชื่อนักเรียน</h3>
        <p class="card-sub">เลือกสถานะเวลาเรียนของนักเรียนแต่ละคน</p>
      </div>
      <div class="card-actions">
        <button class="btn btn-ghost btn-sm" type="button" data-mark-all="present" data-label="มาเรียน"><?= icon('check', 14) ?> มาเรียนทั้งหมด</button>
        <button class="btn btn-primary btn-sm" type="submit"><?= icon('save', 15) ?> บันทึก</button>
      </div>
    </div>

    <div class="card-body" style="padding-bottom:0">
      <div class="att-summary">
        <div class="searchbox" style="position:relative;flex:1;min-width:180px">
          <?= icon('search', 16) ?>
          <input class="input input-sm" id="attSearch" type="search" placeholder="ค้นหาชื่อหรือรหัสนักเรียน…" style="padding-left:34px">
        </div>
        <?php foreach ($statusMeta as $key => $meta): ?>
          <span class="att-pill"><span class="dot" style="background:<?= $colors[$key] ?>"></span><?= e($meta['label']) ?> <b data-att-count="<?= e($key) ?>"><?= (int) $counts[$key] ?></b></span>
        <?php endforeach; ?>
      </div>
    </div>

    <div class="att-roster" id="attRoster">
      <?php foreach ($students as $student): ?>
        <?php $current = $existing[(int) $student['id']] ?? 'present'; ?>
        <div class="att-row">
          <span class="att-no"><?= (int) $student['student_number'] ?></span>
          <span class="avatar <?= avatar_class($student['firstname']) ?>"><?= e(name_initials($student['firstname'], $student['lastname'])) ?></span>
          <span class="att-student">
            <span>
              <b><?= e(student_name($student)) ?></b>
              <small><?= e($student['student_code']) ?> · <?= $student['gender'] === 'male' ? 'ชาย' : 'หญิง' ?></small>
            </span>
          </span>
          <div class="att-seg" role="group" aria-label="สถานะของ <?= e(student_name($student)) ?>">
            <?php foreach ($statusMeta as $key => $meta): ?>
              <label class="att-opt <?= e($meta['class']) ?>">
                <input type="radio" name="entries[<?= (int) $student['id'] ?>]" value="<?= e($key) ?>" <?= $current === $key ? 'checked' : '' ?>>
                <span title="<?= e($meta['label']) ?>"><span class="short"><?= e($meta['short']) ?></span><span class="full"><?= e($meta['label']) ?></span></span>
              </label>
            <?php endforeach; ?>
          </div>
        </div>
      <?php endforeach; ?>
    </div>

    <div class="card-footer">
      <div class="row-between wrap">
        <span class="text-xs text-muted"><?= icon('info', 14) ?> ระบบจะบันทึกทับข้อมูลเดิมของวันเดียวกัน</span>
        <div class="row">
          <?php if (can_manage()): ?>
            <button class="btn btn-ghost btn-sm" type="submit" form="clearAttForm"><?= icon('trash', 14) ?> ล้างข้อมูลวันนี้</button>
          <?php endif; ?>
          <button class="btn btn-primary" type="submit"><?= icon('save', 16) ?> บันทึกการเช็คชื่อ</button>
        </div>
      </div>
    </div>
  </form>
</div>

<?php if (can_manage()): ?>
<form id="clearAttForm" method="post" action="<?= url('attendance.php?class_id=' . $classId . '&date=' . urlencode($date)) ?>" style="display:none" data-confirm="ต้องการล้างข้อมูลเช็คชื่อของ <?= e($currentClass) ?> วันที่ <?= e(thai_date($date, 'short')) ?> ใช่หรือไม่?">
  <?= csrf_field() ?>
  <input type="hidden" name="action" value="clear">
  <input type="hidden" name="class_id" value="<?= $classId ?>">
  <input type="hidden" name="att_date" value="<?= e($date) ?>">
</form>
<?php endif; ?>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
