<article class="doc-sheet">
  <span class="doc-watermark"><?= school_logo_svg(360) ?></span>

  <header class="doc-head">
    <div class="doc-head-side">
      <?= school_logo_svg(74, 'doc-logo') ?>
    </div>
    <div class="doc-head-main">
      <h1><?= e($schoolName) ?></h1>
      <p><?= e(school('name_en')) ?></p>
      <p><?= e(school('affiliation')) ?></p>
      <p><?= e(school('address')) ?><?= school('phone') ? ' · โทร. ' . e(school('phone')) : '' ?></p>
    </div>
    <div class="doc-head-side doc-head-meta">
      <span>เลขที่</span>
      <b><?= e($doc['doc_no']) ?></b>
      <span>วันที่ออก</span>
      <b><?= e(thai_date($doc['issued_at'])) ?></b>
    </div>
  </header>

  <div class="doc-title">
    <h2><?= e($type['name']) ?></h2>
    <span><?= e($type['label']) ?></span>
  </div>

  <?php if ($isLetter): ?>
    <div class="doc-letter">
      <p class="doc-lead">หนังสือฉบับนี้ให้ไว้เพื่อรับรองว่า</p>
      <div class="doc-person">
        <p><span>ชื่อ-สกุล</span><b><?= e($fullname) ?></b></p>
        <p><span>รหัสนักเรียน</span><b><?= e($doc['student_code']) ?></b></p>
        <p><span>ระดับชั้น</span><b><?= e($classText) ?></b></p>
        <p><span>สถานะ</span><b><?= e($studentStatus['label']) ?></b></p>
      </div>
      <?php if ($doc['doc_type'] === 'pp9'): ?>
        <p>เป็นผู้สำเร็จการศึกษาตามหลักสูตรสถานศึกษา ปีการศึกษา <?= e($doc['academic_year']) ?>
          และมีผลการเรียนเฉลี่ยสะสม (GPA) <b><?= number_format($gpa, 2) ?></b>
          รวม <?= number_format($creditSum, 1) ?> หน่วยกิต</p>
      <?php elseif ($doc['doc_type'] === 'pp7'): ?>
        <p>เป็นนักเรียนที่กำลังศึกษาอยู่ในสถานศึกษาแห่งนี้ ในปีการศึกษา <?= e($doc['academic_year']) ?> ภาคเรียนที่ <?= (int) $doc['semester'] ?>
          มีผลการเรียนเฉลี่ย <?= number_format($gpa, 2) ?> และมีอัตรามาเรียนร้อยละ <?= number_format($attRate, 1) ?></p>
      <?php else: ?>
        <p>เป็นนักเรียนที่กำลังศึกษาอยู่ในสถานศึกษาแห่งนี้ ชั้น <?= e($classText) ?> ปีการศึกษา <?= e($doc['academic_year']) ?>
          และเป็นผู้มีความประพฤติเรียบร้อยดี</p>
      <?php endif; ?>
      <p>จึงออกหนังสือรับรองฉบับนี้ไว้ให้เพื่อเป็นหลักฐาน</p>
      <p class="doc-note"><?= e($doc['note'] ?: '') ?></p>
    </div>

    <div class="doc-signs">
      <div class="doc-sign">
        <span class="doc-sign-line"></span>
        <b>(<?= e($doc['issued_by']) ?>)</b>
        <small>ผู้รับรอง / ผู้ออกเอกสาร</small>
      </div>
      <div class="doc-sign">
        <span class="doc-sign-line"></span>
        <b>(<?= e(school('director') ?: '—') ?>)</b>
        <small>ผู้อำนวยการสถานศึกษา</small>
      </div>
    </div>
    <p class="doc-date-right">ออกให้ ณ วันที่ <?= e(thai_date($doc['issued_at'], 'day')) ?></p>
  <?php else: ?>
    <section class="doc-block">
      <h3>ข้อมูลนักเรียน</h3>
      <table class="doc-table doc-info-table">
        <tbody>
          <tr><th>ชื่อ-สกุล</th><td><?= e($fullname) ?></td><th>รหัสนักเรียน</th><td><?= e($doc['student_code']) ?></td></tr>
          <tr><th>ระดับชั้น</th><td><?= e($classText) ?></td><th>เลขประจำตัวประชาชน</th><td><?= e($doc['citizen_id'] ?: '—') ?></td></tr>
          <tr><th>วันเกิด</th><td><?= e($doc['birth_date'] ? thai_date($doc['birth_date']) : '—') ?></td><th>ศาสนา</th><td><?= e($doc['religion'] ?: '—') ?></td></tr>
          <tr><th>ที่อยู่</th><td colspan="3"><?= e($doc['address'] ?: '—') ?></td></tr>
          <tr><th>ผู้ปกครอง</th><td><?= e($doc['parent_name'] ?: '—') ?><?= $doc['parent_relation'] ? ' (' . e($doc['parent_relation']) . ')' : '' ?></td><th>โทรศัพท์</th><td><?= e($doc['parent_phone'] ?: '—') ?></td></tr>
          <tr><th>สถานะ</th><td><?= e($studentStatus['label']) ?></td><th>ปีการศึกษา / ภาคเรียน</th><td><?= e($doc['academic_year']) ?> / <?= (int) $doc['semester'] ?></td></tr>
        </tbody>
      </table>
    </section>

    <section class="doc-block">
      <h3>ผลการเรียน <?= e($doc['doc_type'] === 'pp3' || $doc['doc_type'] === 'pp7' || $doc['doc_type'] === 'pp8' ? 'ประจำภาคเรียน' : '') ?> ปีการศึกษา <?= e($doc['academic_year']) ?> ภาคเรียนที่ <?= (int) $doc['semester'] ?></h3>
      <?php if ($grades): ?>
        <table class="doc-table doc-grade-table">
          <thead>
            <tr><th style="width:14%">รหัสวิชา</th><th>รายวิชา</th><th style="width:12%">หน่วยกิต</th><th style="width:14%">คะแนน</th><th style="width:12%">เกรด</th></tr>
          </thead>
          <tbody>
            <?php foreach ($grades as $grade): ?>
              <tr>
                <td class="text-center"><?= e($grade['code']) ?></td>
                <td><?= e($grade['name']) ?></td>
                <td class="text-center"><?= number_format((float) $grade['credits'], 1) ?></td>
                <td class="text-center"><?= $grade['score'] !== null ? number_format((float) $grade['score'], 1) : '—' ?></td>
                <td class="text-center"><b><?= e($grade['grade'] ?: '—') ?></b></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
          <tfoot>
            <tr><td colspan="2" class="text-right">รวม <?= count($grades) ?> รายวิชา</td><td class="text-center"><?= number_format($creditSum, 1) ?></td><td colspan="2" class="text-center">GPA <?= number_format($gpa, 2) ?></td></tr>
          </tfoot>
        </table>
      <?php else: ?>
        <p class="doc-empty">ยังไม่มีผลการเรียนที่บันทึกไว้สำหรับภาคเรียนนี้</p>
      <?php endif; ?>
    </section>

    <section class="doc-block doc-summary-block">
      <h3>สรุปเวลาเรียน</h3>
      <table class="doc-table doc-letter-table">
        <tbody>
          <tr>
            <th>มาเรียน</th><td><?= number_format((int) ($att['present'] ?? 0)) ?></td>
            <th>มาสาย</th><td><?= number_format((int) ($att['late'] ?? 0)) ?></td>
            <th>ลาป่วย</th><td><?= number_format((int) ($att['sick'] ?? 0)) ?></td>
            <th>ลากิจ</th><td><?= number_format((int) ($att['business'] ?? 0)) ?></td>
            <th>ขาด/หนี</th><td><?= number_format((int) ($att['absent'] ?? 0) + (int) ($att['truant'] ?? 0)) ?></td>
          </tr>
          <tr>
            <th>รวมบันทึก</th><td><?= number_format($attTotal) ?> ครั้ง</td>
            <th>อัตรามาเรียน</th><td colspan="7"><b><?= number_format($attRate, 1) ?>%</b></td>
          </tr>
        </tbody>
      </table>
    </section>

    <div class="doc-signs">
      <div class="doc-sign">
        <span class="doc-sign-line"></span>
        <b>(<?= e($doc['issued_by']) ?>)</b>
        <small>ผู้จัดทำ / นายทะเบียน</small>
      </div>
      <div class="doc-sign">
        <span class="doc-sign-line"></span>
        <b>(<?= e(school('director') ?: '—') ?>)</b>
        <small>ผู้อำนวยการสถานศึกษา</small>
      </div>
    </div>
  <?php endif; ?>

  <footer class="doc-foot">
    <span>เอกสารฉบับนี้พิมพ์จากระบบ <?= e(APP_TITLE) ?></span>
    <span><?= e($doc['doc_no']) ?></span>
    <span>พิมพ์เมื่อ <?= e(thai_date(date('Y-m-d'), 'short')) ?></span>
  </footer>
</article>
