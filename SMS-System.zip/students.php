<?php

require_once __DIR__ . '/includes/bootstrap.php';

$user = require_staff();
$pdo = db();

if (is_post() && post_str('action') === 'delete') {
    verify_csrf();
    require_manage();
    $deleteId = (int) ($_POST['student_id'] ?? 0);
    $stmt = $pdo->prepare('SELECT student_code, firstname, lastname FROM students WHERE id = ?');
    $stmt->execute([$deleteId]);
    $existing = $stmt->fetch();
    if ($existing) {
        $delete = $pdo->prepare('DELETE FROM students WHERE id = ?');
        $delete->execute([$deleteId]);
        flash('success', 'ลบข้อมูลนักเรียน ' . $existing['firstname'] . ' ' . $existing['lastname'] . ' เรียบร้อยแล้ว');
    } else {
        flash('danger', 'ไม่พบข้อมูลนักเรียนที่ต้องการลบ');
    }
    $returnQuery = http_build_query(array_filter([
        'q' => post_str('return_q'),
        'class_id' => post_str('return_class'),
        'status' => post_str('return_status'),
        'page' => post_str('return_page'),
    ]));
    redirect('students.php' . ($returnQuery ? '?' . $returnQuery : ''));
}

$q = get_str('q');
$classId = get_int('class_id');
$status = get_str('status');
$page = max(1, get_int('page', 1));
$perPage = 15;

$classes = $pdo->query("SELECT id, name FROM classes WHERE status = 'active' ORDER BY name")->fetchAll();

$where = [];
$params = [];
if ($q !== '') {
    $where[] = '(s.student_code LIKE ? OR CONCAT(s.firstname, " ", s.lastname) LIKE ? OR s.citizen_id LIKE ? OR s.parent_name LIKE ?)';
    $like = '%' . $q . '%';
    array_push($params, $like, $like, $like, $like);
}
if ($classId > 0) {
    $where[] = 's.class_id = ?';
    $params[] = $classId;
}
if (in_array($status, ['studying', 'graduated', 'transferred', 'inactive'], true)) {
    $where[] = 's.status = ?';
    $params[] = $status;
}
$whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

$countStmt = $pdo->prepare("SELECT COUNT(*) FROM students s $whereSql");
$countStmt->execute($params);
$totalRows = (int) $countStmt->fetchColumn();
$totalPages = max(1, (int) ceil($totalRows / $perPage));
$page = min($page, $totalPages);
$offset = ($page - 1) * $perPage;

$stmt = $pdo->prepare("SELECT s.*, c.name AS class_name, c.level_short
    FROM students s LEFT JOIN classes c ON c.id = s.class_id
    $whereSql
    ORDER BY c.name, s.student_number, s.student_code
    LIMIT $perPage OFFSET $offset");
$stmt->execute($params);
$students = $stmt->fetchAll();

$statuses = student_status_meta();
$queryBase = array_filter([
    'q' => $q,
    'class_id' => $classId > 0 ? (string) $classId : '',
    'status' => $status,
], fn($value) => $value !== '' && $value !== null);

$pageTitle = 'ข้อมูลนักเรียน';
$pageSubtitle = 'ทะเบียนนักเรียน ค้นหา และจัดการข้อมูลส่วนตัว';
$activeNav = 'students';
$pageActions = can_manage() ? '<a class="btn btn-primary btn-sm" href="' . url('student-form.php') . '">' . icon('plus', 16) . '<span>เพิ่มนักเรียน</span></a>' : '';

require_once __DIR__ . '/includes/header.php';
?>

<div class="row-between mb-2 wrap">
  <div>
    <h2 style="font-size:1.1rem;font-weight:800;display:flex;align-items:center;gap:8px"><?= icon('users', 20) ?> ทะเบียนนักเรียน</h2>
    <p class="text-sm text-muted">พบ <?= number_format($totalRows) ?> รายการ <?= $where ? 'ตามเงื่อนไขที่เลือก' : 'ทั้งหมด' ?></p>
  </div>
  <div class="row">
    <span class="chip chip-soft"><?= icon('check-circle', 14) ?> ปีการศึกษา <?= e(academic_year()) ?></span>
    <span class="chip"><?= icon('graduation', 14) ?> <?= number_format($totalRows) ?> คน</span>
  </div>
</div>

<form class="toolbar" method="get" action="<?= url('students.php') ?>">
  <div class="toolbar-left">
    <div class="searchbox">
      <?= icon('search', 17) ?>
      <input class="input" type="search" name="q" value="<?= e($q) ?>" placeholder="ค้นหารหัส ชื่อ-สกุล เลขบัตร หรือผู้ปกครอง…">
    </div>
    <select class="select" name="class_id">
      <option value="">ทุกชั้นเรียน</option>
      <?php foreach ($classes as $class): ?>
        <option value="<?= (int) $class['id'] ?>" <?= $classId === (int) $class['id'] ? 'selected' : '' ?>><?= e($class['name']) ?></option>
      <?php endforeach; ?>
    </select>
    <select class="select" name="status">
      <option value="">ทุกสถานะ</option>
      <?php foreach ($statuses as $key => $meta): ?>
        <option value="<?= e($key) ?>" <?= $status === $key ? 'selected' : '' ?>><?= e($meta['label']) ?></option>
      <?php endforeach; ?>
    </select>
    <button class="btn btn-primary btn-sm" type="submit"><?= icon('filter', 15) ?> กรองข้อมูล</button>
    <?php if ($where): ?><a class="btn btn-ghost btn-sm" href="<?= url('students.php') ?>"><?= icon('refresh', 15) ?> ล้าง</a><?php endif; ?>
  </div>
</form>

<div class="table-wrap">
  <table class="table">
    <thead>
      <tr>
        <th>นักเรียน</th>
        <th>รหัสนักเรียน</th>
        <th>ชั้นเรียน</th>
        <th>ผู้ปกครอง</th>
        <th>โทรศัพท์</th>
        <th>สถานะ</th>
        <th class="text-right">จัดการ</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach ($students as $student): ?>
      <?php $meta = $statuses[$student['status']] ?? $statuses['studying']; ?>
      <tr>
        <td>
          <div class="cell-user">
            <span class="avatar <?= avatar_class($student['firstname']) ?>"><?= e(name_initials($student['firstname'], $student['lastname'])) ?></span>
            <div>
              <b><?= e(student_name($student)) ?></b>
              <small><?= $student['gender'] === 'male' ? 'ชาย' : 'หญิง' ?> · เลขที่ <?= (int) $student['student_number'] ?></small>
            </div>
          </div>
        </td>
        <td><span class="doc-no"><?= e($student['student_code']) ?></span></td>
        <td><span class="badge badge-brand"><?= e($student['class_name'] ?: '—') ?></span></td>
        <td class="text-sm"><?= e($student['parent_name'] ?: '—') ?><br><small class="text-muted"><?= e($student['parent_relation'] ?: '') ?></small></td>
        <td class="text-sm num"><?= e($student['parent_phone'] ?: '—') ?></td>
        <td><span class="badge badge-<?= e($meta['class']) ?>"><span class="dot"></span><?= e($meta['label']) ?></span></td>
        <td>
          <div class="cell-actions">
            <a class="icon-btn" href="<?= url('student-view.php?id=' . (int) $student['id']) ?>" title="ดูข้อมูล"><?= icon('eye', 16) ?></a>
            <?php if (can_manage()): ?>
              <a class="icon-btn" href="<?= url('student-form.php?id=' . (int) $student['id']) ?>" title="แก้ไข"><?= icon('edit', 16) ?></a>
              <form method="post" action="<?= url('students.php') ?>" data-confirm="ต้องการลบข้อมูลนักเรียน <?= e(student_name($student)) ?> ใช่หรือไม่? ข้อมูลเวลาเรียนและผลการเรียนจะถูกลบด้วย">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="student_id" value="<?= (int) $student['id'] ?>">
                <input type="hidden" name="return_q" value="<?= e($q) ?>">
                <input type="hidden" name="return_class" value="<?= $classId ?>">
                <input type="hidden" name="return_status" value="<?= e($status) ?>">
                <input type="hidden" name="return_page" value="<?= $page ?>">
                <button class="icon-btn danger" type="submit" title="ลบ"><?= icon('trash', 16) ?></button>
              </form>
            <?php endif; ?>
          </div>
        </td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$students): ?>
      <tr><td colspan="7">
        <div class="empty-state">
          <div class="empty-ico"><?= icon('search', 30) ?></div>
          <h3>ไม่พบข้อมูลนักเรียน</h3>
          <p>ลองปรับเงื่อนไขการค้นหา หรือเพิ่มข้อมูลนักเรียนใหม่</p>
          <?php if (can_manage()): ?><a class="btn btn-primary btn-sm" href="<?= url('student-form.php') ?>"><?= icon('plus', 15) ?> เพิ่มนักเรียน</a><?php endif; ?>
        </div>
      </td></tr>
    <?php endif; ?>
    </tbody>
  </table>

  <?php if ($totalRows > 0): ?>
    <div class="pagination">
      <span>แสดง <?= number_format($offset + 1) ?>–<?= number_format(min($offset + $perPage, $totalRows)) ?> จาก <?= number_format($totalRows) ?> รายการ</span>
      <div class="pager">
        <?php
          $prevUrl = url('students.php?' . http_build_query(array_merge($queryBase, ['page' => max(1, $page - 1)])));
          $nextUrl = url('students.php?' . http_build_query(array_merge($queryBase, ['page' => min($totalPages, $page + 1)])));
        ?>
        <a class="<?= $page <= 1 ? 'disabled' : '' ?>" href="<?= e($prevUrl) ?>"><?= icon('arrow-left', 15) ?></a>
        <?php for ($p = max(1, $page - 2); $p <= min($totalPages, $page + 2); $p++): ?>
          <a class="<?= $p === $page ? 'is-active' : '' ?>" href="<?= e(url('students.php?' . http_build_query(array_merge($queryBase, ['page' => $p])))) ?>"><?= $p ?></a>
        <?php endfor; ?>
        <a class="<?= $page >= $totalPages ? 'disabled' : '' ?>" href="<?= e($nextUrl) ?>"><?= icon('chevron-right', 15) ?></a>
      </div>
    </div>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
