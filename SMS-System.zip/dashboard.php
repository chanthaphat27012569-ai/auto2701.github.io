<?php

require_once __DIR__ . '/includes/bootstrap.php';

$pageTitle = 'แดชบอร์ด';
$pageSubtitle = 'ภาพรวมระบบบริหารสถานศึกษา';
$activeNav = 'dashboard';

require_once __DIR__ . '/includes/header.php';

$pdo = db();
$month = date('Y-m');

$studentsTotal = (int) $pdo->query("SELECT COUNT(*) FROM students WHERE status = 'studying'")->fetchColumn();
$classesTotal = (int) $pdo->query("SELECT COUNT(*) FROM classes WHERE status = 'active'")->fetchColumn();
$teachersTotal = (int) $pdo->query("SELECT COUNT(*) FROM users WHERE role IN ('teacher','deputy') AND status = 'active'")->fetchColumn();
$documentsTotal = (int) $pdo->query('SELECT COUNT(*) FROM documents')->fetchColumn();
$documentsMonth = (int) $pdo->query("SELECT COUNT(*) FROM documents WHERE DATE_FORMAT(issued_at, '%Y-%m') = " . $pdo->quote($month))->fetchColumn();

$counts = ['present' => 0, 'late' => 0, 'sick' => 0, 'business' => 0, 'absent' => 0, 'truant' => 0];
$stmt = $pdo->prepare("SELECT status, COUNT(*) AS total FROM attendance WHERE DATE_FORMAT(att_date, '%Y-%m') = ? GROUP BY status");
$stmt->execute([$month]);
foreach ($stmt->fetchAll() as $row) {
    $counts[$row['status']] = (int) $row['total'];
}
if (array_sum($counts) === 0) {
    $latestMonth = $pdo->query("SELECT DATE_FORMAT(MAX(att_date), '%Y-%m') FROM attendance")->fetchColumn();
    if ($latestMonth) {
        $month = $latestMonth;
        $stmt->execute([$month]);
        foreach ($stmt->fetchAll() as $row) {
            $counts[$row['status']] = (int) $row['total'];
        }
    }
}
$attendanceTotal = array_sum($counts);
$attendanceRate = attendance_rate($counts);

$latestDate = $pdo->query('SELECT MAX(att_date) FROM attendance')->fetchColumn();
$latestCounts = ['present' => 0, 'late' => 0, 'sick' => 0, 'business' => 0, 'absent' => 0, 'truant' => 0];
if ($latestDate) {
    $stmt = $pdo->prepare('SELECT status, COUNT(*) AS total FROM attendance WHERE att_date = ? GROUP BY status');
    $stmt->execute([$latestDate]);
    foreach ($stmt->fetchAll() as $row) {
        $latestCounts[$row['status']] = (int) $row['total'];
    }
}
$latestTotal = array_sum($latestCounts);
$latestPresent = $latestCounts['present'] + $latestCounts['late'];
$latestAbsent = $latestCounts['absent'] + $latestCounts['truant'];

$trendRows = $pdo->query("SELECT att_date, COUNT(*) AS total, SUM(status IN ('present','late')) AS attended
    FROM attendance GROUP BY att_date ORDER BY att_date DESC LIMIT 7")->fetchAll();
$trendRows = array_reverse($trendRows);
$trend = [];
foreach ($trendRows as $row) {
    $trend[] = [
        'date' => $row['att_date'],
        'rate' => $row['total'] > 0 ? (int) $row['attended'] / (int) $row['total'] * 100 : 0,
        'total' => (int) $row['total'],
    ];
}

$classStmt = $pdo->prepare("SELECT c.id, c.name, c.level_short, c.homeroom,
        (SELECT COUNT(*) FROM students s WHERE s.class_id = c.id AND s.status = 'studying') AS students,
        (SELECT COUNT(*) FROM attendance a WHERE a.class_id = c.id AND DATE_FORMAT(a.att_date, '%Y-%m') = ? AND a.status IN ('present','late')) AS attended,
        (SELECT COUNT(*) FROM attendance a WHERE a.class_id = c.id AND DATE_FORMAT(a.att_date, '%Y-%m') = ?) AS total_days
    FROM classes c WHERE c.status = 'active' ORDER BY c.name");
$classStmt->execute([$month, $month]);
$classRows = $classStmt->fetchAll();

$recentDocs = $pdo->query("SELECT d.*, s.prefix, s.firstname, s.lastname, c.name AS class_name
    FROM documents d
    JOIN students s ON s.id = d.student_id
    LEFT JOIN classes c ON c.id = s.class_id
    ORDER BY d.issued_at DESC LIMIT 5")->fetchAll();

$attentionStmt = $pdo->prepare("SELECT s.id, s.student_code, s.prefix, s.firstname, s.lastname, c.name AS class_name,
        SUM(a.status IN ('absent','truant')) AS miss_days
    FROM attendance a
    JOIN students s ON s.id = a.student_id
    LEFT JOIN classes c ON c.id = s.class_id
    WHERE DATE_FORMAT(a.att_date, '%Y-%m') = ?
    GROUP BY s.id, s.student_code, s.prefix, s.firstname, s.lastname, c.name
    HAVING miss_days > 0
    ORDER BY miss_days DESC LIMIT 5");
$attentionStmt->execute([$month]);
$attention = $attentionStmt->fetchAll();

$hour = (int) date('H');
$greeting = $hour < 12 ? 'สวัสดีตอนเช้า' : ($hour < 17 ? 'สวัสดีตอนบ่าย' : 'สวัสดีตอนเย็น');
$statusMeta = attendance_meta();
$monthLabel = month_label($month);
?>

<section class="hero">
  <span class="hero-orb o1"></span><span class="hero-orb o2"></span><span class="hero-orb o3"></span>
  <div class="hero-inner">
    <div class="hero-copy">
      <span class="hero-eyebrow"><?= icon('sparkles', 15) ?> ภาพรวมวันนี้ · <?= e(thai_date(date('Y-m-d'), 'day')) ?></span>
      <h2 class="hero-title"><?= e($greeting) ?>, <span><?= e($user['fullname']) ?></span></h2>
      <p class="hero-desc">ระบบบริหารจัดการสถานศึกษาครบวงจร ตรวจสอบเวลาเรียน บันทึกผลการเรียน และออกเอกสารทางการศึกษา ปพ.1–ปพ.9 ได้ในที่เดียว</p>
      <div class="hero-actions">
        <a class="btn btn-white" href="<?= url('attendance.php') ?>"><?= icon('check', 18) ?><span>เช็คชื่อวันนี้</span></a>
        <a class="btn btn-white" href="<?= url('documents.php') ?>"><?= icon('file', 18) ?><span>ออกเอกสาร ปพ.</span></a>
      </div>
      <div class="hero-meta">
        <div class="hero-meta-item"><b><?= number_format($latestPresent) ?>/<?= number_format($latestTotal) ?></b><span>มาเรียนล่าสุด <?= e(thai_date($latestDate, 'short')) ?></span></div>
        <div class="hero-meta-item"><b><?= number_format($latestAbsent) ?></b><span>ขาด / หนีเรียน</span></div>
        <div class="hero-meta-item"><b><?= number_format($documentsMonth) ?></b><span>เอกสารเดือนนี้</span></div>
      </div>
    </div>
    <div class="hero-visual" aria-hidden="true">
      <span class="hero-spark s1"><?= icon('sparkles', 26) ?></span>
      <span class="hero-spark s2"><?= icon('star', 18) ?></span>
      <span class="hero-spark s3"><?= icon('sparkles', 16) ?></span>
      <div class="hero-ring"><div class="hero-logo-card"><?= school_logo_svg(88) ?></div></div>
    </div>
  </div>
</section>

<section class="stat-grid">
  <article class="stat-card" style="--accent:#4f46e5;--accent-soft:#eef2ff;--i:0">
    <div class="stat-icon"><?= icon('users', 22) ?></div>
    <div class="stat-value num" data-count="<?= $studentsTotal ?>">0</div>
    <div class="stat-label">นักเรียนที่กำลังศึกษา</div>
    <div class="stat-foot"><span class="stat-trend up"><?= icon('trending', 12) ?> ทุกชั้นเรียน</span><span class="text-muted">ปี <?= e(academic_year()) ?></span></div>
  </article>
  <article class="stat-card" style="--accent:#7c3aed;--accent-soft:#f5f3ff;--i:1">
    <div class="stat-icon"><?= icon('building', 22) ?></div>
    <div class="stat-value num" data-count="<?= $classesTotal ?>">0</div>
    <div class="stat-label">ชั้นเรียนที่เปิดสอน</div>
    <div class="stat-foot"><span class="stat-trend neutral"><?= icon('book', 12) ?> ภาคเรียนที่ <?= academic_semester() ?></span></div>
  </article>
  <article class="stat-card" style="--accent:#0ea5e9;--accent-soft:#e0f2fe;--i:2">
    <div class="stat-icon"><?= icon('graduation', 22) ?></div>
    <div class="stat-value num" data-count="<?= $teachersTotal ?>">0</div>
    <div class="stat-label">ครูและผู้บริหาร</div>
    <div class="stat-foot"><span class="stat-trend up"><?= icon('check-circle', 12) ?> เปิดใช้งาน</span></div>
  </article>
  <article class="stat-card" style="--accent:#10b981;--accent-soft:#ecfdf5;--i:3">
    <div class="stat-icon"><?= icon('check', 22) ?></div>
    <div class="stat-value num" data-count="<?= round($attendanceRate, 1) ?>" data-decimals="1" data-suffix="%">0%</div>
    <div class="stat-label">อัตรามาเรียน · <?= e($monthLabel) ?></div>
    <div class="stat-foot"><span class="stat-trend <?= $attendanceRate >= 85 ? 'up' : ($attendanceRate >= 70 ? 'neutral' : 'down') ?>"><?= icon($attendanceRate >= 85 ? 'trending' : 'alert', 12) ?><?= number_format($attendanceTotal) ?> ระเบียน</span></div>
  </article>
</section>

<section class="grid grid-2">
  <article class="card">
    <div class="card-head">
      <div>
        <h3 class="card-title"><?= icon('chart', 19) ?> ภาพรวมเวลาเรียน</h3>
        <p class="card-sub"><?= e($monthLabel) ?> · จากระเบียนเช็คชื่อทั้งหมด <?= number_format($attendanceTotal) ?> รายการ</p>
      </div>
      <div class="card-actions"><a class="btn btn-ghost btn-sm" href="<?= url('attendance-report.php') ?>">รายละเอียด <?= icon('arrow-right', 15) ?></a></div>
    </div>
    <div class="card-body">
      <div class="attendance-overview">
        <div class="donut-wrap">
          <svg class="donut-svg" viewBox="0 0 120 120" aria-hidden="true">
            <defs><linearGradient id="donutGrad" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#34d399"/><stop offset="0.55" stop-color="#10b981"/><stop offset="1" stop-color="#0d9488"/></linearGradient></defs>
            <circle class="donut-track" cx="60" cy="60" r="48"/>
            <circle class="donut-value" cx="60" cy="60" r="48" data-donut="<?= round($attendanceRate, 1) ?>"/>
          </svg>
          <div class="donut-center"><b><?= round($attendanceRate, 1) ?><span style="font-size:1rem">%</span></b><span>อัตรามาเรียน</span></div>
        </div>
        <div class="legend">
          <?php foreach ($statusMeta as $key => $meta): ?>
            <?php $color = ['present' => '#10b981', 'late' => '#f59e0b', 'sick' => '#3b82f6', 'business' => '#8b5cf6', 'absent' => '#ef4444', 'truant' => '#be123c'][$key]; ?>
            <div class="legend-item"><span class="swatch" style="background:<?= $color ?>"></span><?= e($meta['label']) ?><b><?= number_format($counts[$key]) ?></b></div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </article>

  <article class="card">
    <div class="card-head">
      <div>
        <h3 class="card-title"><?= icon('trending', 19) ?> แนวโน้ม 7 วันล่าสุด</h3>
        <p class="card-sub">อัตรามาเรียนรายวัน เทียบกับจำนวนระเบียน</p>
      </div>
      <div class="card-actions"><span class="badge badge-success"><span class="dot"></span>มาเรียน</span></div>
    </div>
    <div class="card-body">
      <?php if ($trend): ?>
        <div class="bars">
          <?php foreach ($trend as $i => $day): ?>
            <div class="bar-col">
              <span class="bar-value"><?= number_format($day['rate'], 0) ?>%</span>
              <div class="bar-track"><div class="bar-fill" style="height:<?= max(4, round($day['rate'])) ?>%;--i:<?= $i ?>"></div></div>
              <span class="bar-label"><?= (int) date('j', strtotime($day['date'])) ?> <?= THAI_MONTHS_SHORT[(int) date('n', strtotime($day['date']))] ?></span>
            </div>
          <?php endforeach; ?>
        </div>
      <?php else: ?>
        <div class="empty-state"><div class="empty-ico"><?= icon('chart', 30) ?></div><h3>ยังไม่มีข้อมูลการเช็คชื่อ</h3><p>เริ่มเช็คชื่อเพื่อดูแนวโน้มเวลาเรียน</p><a class="btn btn-primary btn-sm" href="<?= url('attendance.php') ?>">เริ่มเช็คชื่อ</a></div>
      <?php endif; ?>
    </div>
  </article>
</section>

<section class="grid grid-2-1">
  <article class="card">
    <div class="card-head bordered">
      <div>
        <h3 class="card-title"><?= icon('building', 19) ?> ภาพรวมรายชั้นเรียน</h3>
        <p class="card-sub">จำนวนนักเรียนและอัตรามาเรียนประจำเดือน</p>
      </div>
      <div class="card-actions"><a class="btn btn-ghost btn-sm" href="<?= url('classes.php') ?>">จัดการชั้นเรียน</a></div>
    </div>
    <div class="table-wrap" style="border:0;border-radius:0;box-shadow:none">
      <table class="table">
        <thead><tr><th>ชั้นเรียน</th><th>ครูประจำชั้น</th><th class="text-right">นักเรียน</th><th style="min-width:160px">อัตรามาเรียน</th><th class="text-right">ดูรายงาน</th></tr></thead>
        <tbody>
        <?php foreach ($classRows as $class): ?>
          <?php $rate = (int) $class['total_days'] > 0 ? (int) $class['attended'] / (int) $class['total_days'] * 100 : 0; ?>
          <tr>
            <td><b style="font-weight:800"><?= e($class['name']) ?></b><br><small class="text-muted"><?= e($class['level_short']) ?></small></td>
            <td class="text-sm text-muted"><?= e($class['homeroom'] ?: '—') ?></td>
            <td class="text-right num"><b><?= (int) $class['students'] ?></b> <span class="text-muted text-xs">คน</span></td>
            <td>
              <div class="row" style="gap:8px">
                <div class="meter <?= $rate >= 90 ? 'green' : ($rate >= 75 ? '' : 'amber') ?>" style="flex:1"><span data-meter="<?= round($rate, 1) ?>"></span></div>
                <b class="num" style="font-size:.78rem;min-width:44px;text-align:right"><?= number_format($rate, 1) ?>%</b>
              </div>
            </td>
            <td class="text-right"><a class="icon-btn" href="<?= url('attendance-report.php?class_id=' . (int) $class['id']) ?>" title="รายงานชั้นเรียน"><?= icon('chevron-right', 17) ?></a></td>
          </tr>
        <?php endforeach; ?>
        <?php if (!$classRows): ?>
          <tr><td colspan="5"><div class="empty-state"><p>ยังไม่มีชั้นเรียน</p></div></td></tr>
        <?php endif; ?>
        </tbody>
      </table>
    </div>
  </article>

  <div class="stack">
    <article class="card">
      <div class="card-head">
        <div><h3 class="card-title"><?= icon('file', 19) ?> เอกสารล่าสุด</h3><p class="card-sub">รายการ ปพ. ที่ออกล่าสุด</p></div>
        <div class="card-actions"><a class="btn btn-ghost btn-sm" href="<?= url('documents.php') ?>">ทั้งหมด</a></div>
      </div>
      <div class="card-body" style="padding-top:8px">
        <div class="stack" style="gap:10px">
          <?php foreach ($recentDocs as $doc): ?>
            <?php $type = doc_type($doc['doc_type']); ?>
            <a class="row" href="<?= url('document-print.php?id=' . (int) $doc['id']) ?>" style="padding:8px;border-radius:11px;background:#fafbff;border:1px solid #f0f2fa;color:inherit">
              <span class="avatar sm <?= avatar_class($doc['firstname']) ?>"><?= e(name_initials($doc['firstname'], $doc['lastname'])) ?></span>
              <span style="min-width:0;flex:1">
                <b style="display:block;font-size:.8rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= e(student_name($doc)) ?></b>
                <small class="text-muted" style="font-size:.7rem"><?= e($type['label']) ?> · <?= e(thai_date($doc['issued_at'], 'short')) ?></small>
              </span>
              <span class="badge badge-brand"><?= e($type['label']) ?></span>
            </a>
          <?php endforeach; ?>
          <?php if (!$recentDocs): ?><div class="empty-state" style="padding:24px"><p>ยังไม่มีเอกสาร</p></div><?php endif; ?>
        </div>
      </div>
    </article>

    <article class="card">
      <div class="card-head">
        <div><h3 class="card-title"><?= icon('alert', 19) ?> ควรติดตาม</h3><p class="card-sub">นักเรียนที่มีวันขาดเรียนสูงสุด</p></div>
      </div>
      <div class="card-body" style="padding-top:8px">
        <div class="stack" style="gap:10px">
          <?php foreach ($attention as $item): ?>
            <div class="row" style="padding:8px;border-radius:11px;background:#fff8f8;border:1px solid #ffe4e6">
              <span class="avatar sm <?= avatar_class($item['firstname']) ?>"><?= e(name_initials($item['firstname'], $item['lastname'])) ?></span>
              <span style="flex:1;min-width:0">
                <b style="display:block;font-size:.8rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= e(student_name($item)) ?></b>
                <small class="text-muted" style="font-size:.7rem"><?= e($item['class_name'] ?: '—') ?> · <?= e($item['student_code']) ?></small>
              </span>
              <span class="badge badge-danger"><?= (int) $item['miss_days'] ?> วัน</span>
            </div>
          <?php endforeach; ?>
          <?php if (!$attention): ?><div class="empty-state" style="padding:24px"><p>ไม่มีนักเรียนที่ต้องติดตามเป็นพิเศษ</p></div><?php endif; ?>
        </div>
      </div>
    </article>
  </div>
</section>

<section class="quick-grid">
  <a class="quick-card" href="<?= url('attendance.php') ?>">
    <span class="q-ico"><?= icon('check', 20) ?></span>
    <b>เช็คชื่อประจำวัน</b><small>บันทึกเวลาเรียนรายคาบ/รายวัน</small>
  </a>
  <a class="quick-card" href="<?= url('gradebook.php') ?>">
    <span class="q-ico" style="background:#f5f3ff;color:#7c3aed"><?= icon('edit', 20) ?></span>
    <b>บันทึกผลการเรียน</b><small>ปพ.5 คะแนนและเกรดอัตโนมัติ</small>
  </a>
  <a class="quick-card" href="<?= url('documents.php') ?>">
    <span class="q-ico" style="background:#fff1f2;color:#e11d48"><?= icon('file', 20) ?></span>
    <b>ศูนย์เอกสาร ปพ.</b><small>ออกและพิมพ์เอกสารทางการศึกษา</small>
  </a>
  <a class="quick-card" href="<?= url('students.php') ?>">
    <span class="q-ico" style="background:#ecfdf5;color:#059669"><?= icon('users', 20) ?></span>
    <b>ทะเบียนนักเรียน</b><small>ค้นหาและจัดการข้อมูลนักเรียน</small>
  </a>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
