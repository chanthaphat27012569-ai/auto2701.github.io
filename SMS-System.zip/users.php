<?php

require_once __DIR__ . '/includes/bootstrap.php';

require_admin();
$user = require_staff();
$pdo = db();

$roles = role_options();
$errors = [];
$form = [
    'id' => 0,
    'username' => '',
    'fullname' => '',
    'role' => 'teacher',
    'position' => '',
    'department' => '',
    'phone' => '',
    'email' => '',
    'status' => 'active',
];
$showForm = get_str('new') === '1' || get_int('edit') > 0;

if (get_int('edit') > 0) {
    $stmt = $pdo->prepare('SELECT * FROM users WHERE id = ?');
    $stmt->execute([get_int('edit')]);
    $row = $stmt->fetch();
    if ($row) {
        $form = array_merge($form, $row);
        $form['id'] = (int) $row['id'];
    }
}

if (is_post()) {
    verify_csrf();
    $action = post_str('action');

    if ($action === 'delete') {
        $deleteId = (int) ($_POST['user_id'] ?? 0);
        if ($deleteId === (int) $user['id']) {
            flash('danger', 'ไม่สามารถลบบัญชีที่กำลังใช้งานอยู่ได้');
            redirect('users.php');
        }
        $stmt = $pdo->prepare('SELECT username, fullname, role FROM users WHERE id = ?');
        $stmt->execute([$deleteId]);
        $existing = $stmt->fetch();
        if (!$existing) {
            flash('danger', 'ไม่พบผู้ใช้งานที่ต้องการลบ');
            redirect('users.php');
        }
        if (in_array($existing['role'], ['admin', 'director'], true)) {
            $adminCount = (int) $pdo->query("SELECT COUNT(*) FROM users WHERE role IN ('admin','director') AND status = 'active'")->fetchColumn();
            if ($adminCount <= 1) {
                flash('danger', 'ต้องมีผู้ดูแลระบบอย่างน้อย 1 บัญชี');
                redirect('users.php');
            }
        }
        $del = $pdo->prepare('DELETE FROM users WHERE id = ?');
        $del->execute([$deleteId]);
        flash('success', 'ลบผู้ใช้งาน ' . $existing['fullname'] . ' เรียบร้อยแล้ว');
        redirect('users.php');
    }

    if ($action === 'reset_password') {
        $resetId = (int) ($_POST['user_id'] ?? 0);
        $newPassword = post_str('new_password');
        if (mb_strlen($newPassword) < 4) {
            flash('danger', 'รหัสผ่านใหม่ต้องมีอย่างน้อย 4 ตัวอักษร');
            redirect('users.php');
        }
        $stmt = $pdo->prepare('SELECT fullname FROM users WHERE id = ?');
        $stmt->execute([$resetId]);
        $existing = $stmt->fetch();
        if (!$existing) {
            flash('danger', 'ไม่พบผู้ใช้งานที่ต้องการรีเซ็ตรหัสผ่าน');
            redirect('users.php');
        }
        $update = $pdo->prepare('UPDATE users SET password_hash = ? WHERE id = ?');
        $update->execute([password_hash($newPassword, PASSWORD_DEFAULT), $resetId]);
        flash('success', 'รีเซ็ตรหัสผ่านของ ' . $existing['fullname'] . ' เรียบร้อยแล้ว');
        redirect('users.php');
    }

    if ($action === 'save') {
        foreach (['username', 'fullname', 'role', 'position', 'department', 'phone', 'email'] as $key) {
            $form[$key] = post_str($key);
        }
        $form['status'] = post_str('status') === 'inactive' ? 'inactive' : 'active';
        $password = post_str('password');

        if ($form['username'] === '' || !preg_match('/^[a-zA-Z0-9._-]{3,60}$/', $form['username'])) {
            $errors['username'] = 'ชื่อผู้ใช้ 3–60 ตัว ใช้ตัวอักษรอังกฤษ ตัวเลข . _ - เท่านั้น';
        }
        if ($form['fullname'] === '') {
            $errors['fullname'] = 'กรุณากรอกชื่อ-สกุล';
        }
        if (!isset($roles[$form['role']])) {
            $errors['role'] = 'กรุณาเลือกบทบาท';
        }
        if ($form['id'] <= 0 && mb_strlen($password) < 4) {
            $errors['password'] = 'กำหนดรหัสผ่านอย่างน้อย 4 ตัวอักษร';
        }
        if ($form['id'] > 0 && $password !== '' && mb_strlen($password) < 4) {
            $errors['password'] = 'รหัสผ่านใหม่ต้องมีอย่างน้อย 4 ตัวอักษร';
        }
        if (!$errors) {
            $stmt = $pdo->prepare('SELECT id FROM users WHERE username = ? AND id <> ? LIMIT 1');
            $stmt->execute([$form['username'], $form['id']]);
            if ($stmt->fetch()) {
                $errors['username'] = 'มีชื่อผู้ใช้นี้อยู่แล้ว';
            }
        }
        if (!$errors) {
            if ($form['id'] > 0) {
                $sql = 'UPDATE users SET username=?, fullname=?, role=?, position=?, department=?, phone=?, email=?, status=?';
                $params = [$form['username'], $form['fullname'], $form['role'], $form['position'], $form['department'], $form['phone'], $form['email'], $form['status']];
                if ($password !== '') {
                    $sql .= ', password_hash=?';
                    $params[] = password_hash($password, PASSWORD_DEFAULT);
                }
                $sql .= ' WHERE id=?';
                $params[] = $form['id'];
                $stmt = $pdo->prepare($sql);
                $stmt->execute($params);
                if ($form['id'] === (int) $user['id']) {
                    $_SESSION['staff']['fullname'] = $form['fullname'];
                    $_SESSION['staff']['role'] = $form['role'];
                    $_SESSION['staff']['position'] = $form['position'];
                    $_SESSION['staff']['department'] = $form['department'];
                }
                flash('success', 'บันทึกข้อมูลผู้ใช้งาน ' . $form['fullname'] . ' เรียบร้อยแล้ว');
            } else {
                $stmt = $pdo->prepare('INSERT INTO users (username, password_hash, fullname, role, position, department, phone, email, status) VALUES (?,?,?,?,?,?,?,?,?)');
                $stmt->execute([$form['username'], password_hash($password, PASSWORD_DEFAULT), $form['fullname'], $form['role'], $form['position'], $form['department'], $form['phone'], $form['email'], $form['status']]);
                flash('success', 'เพิ่มผู้ใช้งาน ' . $form['fullname'] . ' เรียบร้อยแล้ว');
            }
            redirect('users.php');
        }
        $showForm = true;
    }
}

$users = $pdo->query("SELECT * FROM users ORDER BY FIELD(role, 'admin','director','deputy','registrar','teacher','staff'), fullname")->fetchAll();
$resetUserId = get_int('reset');
$resetUser = null;
foreach ($users as $row) {
    if ((int) $row['id'] === $resetUserId) {
        $resetUser = $row;
    }
}
$activeCount = count(array_filter($users, fn($u) => $u['status'] === 'active'));
$teacherCount = count(array_filter($users, fn($u) => in_array($u['role'], ['teacher', 'deputy'], true)));
$adminCount = count(array_filter($users, fn($u) => in_array($u['role'], ['admin', 'director'], true)));

$roleBadges = ['admin' => 'badge-brand', 'director' => 'badge-violet', 'deputy' => 'badge-info', 'registrar' => 'badge-warning', 'teacher' => 'badge-success', 'staff' => 'badge-muted'];

$pageTitle = 'ผู้ใช้งาน';
$pageSubtitle = 'จัดการบัญชีเจ้าหน้าที่ ครู และผู้บริหาร';
$activeNav = 'users';
$pageActions = '<a class="btn btn-primary btn-sm" href="' . url('users.php?new=1') . '">' . icon('plus', 16) . '<span>เพิ่มผู้ใช้งาน</span></a>';

require_once __DIR__ . '/includes/header.php';
?>

<section class="stat-grid mb-3">
  <article class="stat-card" style="--accent:#4f46e5;--accent-soft:#eef2ff;--i:0">
    <div class="stat-icon"><?= icon('users', 22) ?></div>
    <div class="stat-value num" data-count="<?= count($users) ?>">0</div>
    <div class="stat-label">บัญชีทั้งหมด</div>
    <div class="stat-foot"><span class="stat-trend up"><?= icon('check-circle', 12) ?><?= $activeCount ?> เปิดใช้งาน</span></div>
  </article>
  <article class="stat-card" style="--accent:#10b981;--accent-soft:#ecfdf5;--i:1">
    <div class="stat-icon"><?= icon('graduation', 22) ?></div>
    <div class="stat-value num" data-count="<?= $teacherCount ?>">0</div>
    <div class="stat-label">ครูและผู้บริหาร</div>
    <div class="stat-foot"><span class="stat-trend neutral"><?= icon('book', 12) ?> สอนและดูแล</span></div>
  </article>
  <article class="stat-card" style="--accent:#7c3aed;--accent-soft:#f5f3ff;--i:2">
    <div class="stat-icon"><?= icon('shield', 22) ?></div>
    <div class="stat-value num" data-count="<?= $adminCount ?>">0</div>
    <div class="stat-label">ผู้ดูแลระบบ</div>
    <div class="stat-foot"><span class="stat-trend neutral"><?= icon('key', 12) ?> สิทธิ์สูงสุด</span></div>
  </article>
  <article class="stat-card" style="--accent:#f59e0b;--accent-soft:#fffbeb;--i:3">
    <div class="stat-icon"><?= icon('clock', 22) ?></div>
    <div class="stat-value num" data-count="<?= count($users) - $activeCount ?>">0</div>
    <div class="stat-label">ปิดใช้งาน</div>
    <div class="stat-foot"><span class="stat-trend neutral"><?= icon('lock', 12) ?> ระงับการเข้าถึง</span></div>
  </article>
</section>

<?php if ($showForm): ?>
<section class="card mb-3 animate-pop">
  <div class="card-head bordered">
    <div>
      <h3 class="card-title"><?= icon($form['id'] > 0 ? 'edit' : 'plus', 19) ?> <?= $form['id'] > 0 ? 'แก้ไขผู้ใช้งาน' : 'เพิ่มผู้ใช้งานใหม่' ?></h3>
      <p class="card-sub">ข้อมูลบัญชี บทบาท และช่องทางติดต่อ</p>
    </div>
    <div class="card-actions"><a class="btn btn-ghost btn-sm" href="<?= url('users.php') ?>"><?= icon('x', 15) ?> ปิด</a></div>
  </div>
  <div class="card-body">
    <form method="post" action="<?= url('users.php') ?>">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="save">
      <input type="hidden" name="id" value="<?= (int) $form['id'] ?>">
      <div class="form-grid">
        <div class="field">
          <label>ชื่อผู้ใช้ <span class="req">*</span></label>
          <input class="input <?= isset($errors['username']) ? 'is-invalid' : '' ?>" type="text" name="username" value="<?= e($form['username']) ?>" placeholder="เช่น teacher.somchai" required>
          <?php if (isset($errors['username'])): ?><span class="field-error"><?= e($errors['username']) ?></span><?php endif; ?>
        </div>
        <div class="field">
          <label>ชื่อ-สกุล <span class="req">*</span></label>
          <input class="input <?= isset($errors['fullname']) ? 'is-invalid' : '' ?>" type="text" name="fullname" value="<?= e($form['fullname']) ?>" placeholder="เช่น นายสมชาย ใจดี" required>
          <?php if (isset($errors['fullname'])): ?><span class="field-error"><?= e($errors['fullname']) ?></span><?php endif; ?>
        </div>
        <div class="field">
          <label>บทบาท <span class="req">*</span></label>
          <select class="select" name="role">
            <?php foreach ($roles as $key => $label): ?>
              <option value="<?= e($key) ?>" <?= $form['role'] === $key ? 'selected' : '' ?>><?= e($label) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="field">
          <label>ตำแหน่ง</label>
          <input class="input" type="text" name="position" value="<?= e($form['position']) ?>" placeholder="เช่น ครูชำนาญการ">
        </div>
        <div class="field">
          <label>ฝ่าย / กลุ่มสาระ</label>
          <input class="input" type="text" name="department" value="<?= e($form['department']) ?>" placeholder="เช่น วิทยาศาสตร์และเทคโนโลยี">
        </div>
        <div class="field">
          <label>โทรศัพท์</label>
          <input class="input" type="tel" name="phone" value="<?= e($form['phone']) ?>" placeholder="08x-xxx-xxxx" data-phone>
        </div>
        <div class="field">
          <label>อีเมล</label>
          <input class="input" type="email" name="email" value="<?= e($form['email']) ?>" placeholder="name@school.ac.th">
        </div>
        <div class="field">
          <label>สถานะ</label>
          <select class="select" name="status">
            <option value="active" <?= $form['status'] === 'active' ? 'selected' : '' ?>>เปิดใช้งาน</option>
            <option value="inactive" <?= $form['status'] === 'inactive' ? 'selected' : '' ?>>ปิดใช้งาน</option>
          </select>
        </div>
        <div class="field span-2">
          <label>รหัสผ่าน <?= $form['id'] > 0 ? '<span class="text-muted" style="font-weight:400">(เว้นว่างหากไม่ต้องการเปลี่ยน)</span>' : '<span class="req">*</span>' ?></label>
          <input class="input <?= isset($errors['password']) ? 'is-invalid' : '' ?>" type="password" name="password" placeholder="อย่างน้อย 4 ตัวอักษร" autocomplete="new-password">
          <?php if (isset($errors['password'])): ?><span class="field-error"><?= e($errors['password']) ?></span><?php endif; ?>
        </div>
      </div>
      <div class="form-actions">
        <button class="btn btn-primary" type="submit"><?= icon('save', 17) ?> บันทึกผู้ใช้งาน</button>
        <a class="btn btn-ghost" href="<?= url('users.php') ?>">ยกเลิก</a>
      </div>
    </form>
  </div>
</section>
<?php endif; ?>

<?php if ($resetUser): ?>
<section class="card mb-3 animate-pop">
  <div class="card-head bordered">
    <div>
      <h3 class="card-title"><?= icon('key', 19) ?> รีเซ็ตรหัสผ่าน</h3>
      <p class="card-sub"><?= e($resetUser['fullname']) ?> · <?= e($resetUser['username']) ?></p>
    </div>
    <div class="card-actions"><a class="btn btn-ghost btn-sm" href="<?= url('users.php') ?>"><?= icon('x', 15) ?> ปิด</a></div>
  </div>
  <div class="card-body">
    <form method="post" action="<?= url('users.php') ?>" class="row wrap" style="align-items:flex-end">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="reset_password">
      <input type="hidden" name="user_id" value="<?= (int) $resetUser['id'] ?>">
      <div class="field" style="flex:1;min-width:220px">
        <label>รหัสผ่านใหม่</label>
        <input class="input" type="text" name="new_password" placeholder="อย่างน้อย 4 ตัวอักษร" required>
      </div>
      <button class="btn btn-primary" type="submit"><?= icon('refresh', 16) ?> ตั้งรหัสผ่านใหม่</button>
    </form>
  </div>
</section>
<?php endif; ?>

<div class="table-wrap">
  <table class="table">
    <thead>
      <tr>
        <th>ผู้ใช้งาน</th>
        <th>ชื่อผู้ใช้</th>
        <th>บทบาท</th>
        <th>ตำแหน่ง / ฝ่าย</th>
        <th>ติดต่อ</th>
        <th>เข้าใช้ล่าสุด</th>
        <th>สถานะ</th>
        <th class="text-right">จัดการ</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach ($users as $row): ?>
      <tr>
        <td>
          <div class="cell-user">
            <span class="avatar <?= avatar_class($row['fullname']) ?>"><?= e(fullname_initials($row['fullname'])) ?></span>
            <div><b><?= e($row['fullname']) ?></b><small><?= e($row['email'] ?: '—') ?></small></div>
          </div>
        </td>
        <td><span class="doc-no"><?= e($row['username']) ?></span></td>
        <td><span class="badge <?= $roleBadges[$row['role']] ?? 'badge-muted' ?>"><?= e(role_label($row['role'])) ?></span></td>
        <td class="text-sm"><?= e($row['position'] ?: '—') ?><br><small class="text-muted"><?= e($row['department'] ?: '') ?></small></td>
        <td class="text-sm"><?= e($row['phone'] ?: '—') ?><br><small class="text-muted"><?= e($row['email'] ?: '') ?></small></td>
        <td class="text-sm text-muted"><?= $row['last_login'] ? e(thai_datetime($row['last_login'], true)) : 'ยังไม่เคยเข้าใช้' ?></td>
        <td><span class="badge badge-<?= $row['status'] === 'active' ? 'success' : 'muted' ?>"><span class="dot"></span><?= $row['status'] === 'active' ? 'ใช้งาน' : 'ปิด' ?></span></td>
        <td>
          <div class="cell-actions">
            <a class="icon-btn" href="<?= url('users.php?edit=' . (int) $row['id']) ?>" title="แก้ไข"><?= icon('edit', 16) ?></a>
            <a class="icon-btn" href="<?= url('users.php?reset=' . (int) $row['id']) ?>" title="รีเซ็ตรหัสผ่าน"><?= icon('key', 16) ?></a>
            <?php if ((int) $row['id'] !== (int) $user['id']): ?>
              <form method="post" action="<?= url('users.php') ?>" data-confirm="ต้องการลบผู้ใช้งาน <?= e($row['fullname']) ?> ใช่หรือไม่?">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="user_id" value="<?= (int) $row['id'] ?>">
                <button class="icon-btn danger" type="submit" title="ลบ"><?= icon('trash', 16) ?></button>
              </form>
            <?php endif; ?>
          </div>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>

<div class="notice notice-info mt-2">
  <?= icon('shield', 18) ?>
  <div><strong>ความปลอดภัย</strong> รหัสผ่านถูกเข้ารหัสด้วย bcrypt · แนะนำให้ตั้งรหัสผ่านที่คาดเดายาก และเปลี่ยนเมื่อมีผู้ใช้งานใหม่</div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
