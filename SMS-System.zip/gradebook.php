<?php

require_once __DIR__ . '/includes/bootstrap.php';

$user = require_staff();
$pdo = db();

$classes = $pdo->query("SELECT id, name FROM classes WHERE status = 'active' ORDER BY name")->fetchAll();
$subjects = $pdo->query("SELECT id, code, name, credits FROM subjects WHERE status = 'active' ORDER BY code")->fetchAll();

$classId = get_int('class_id');
if ($classId <= 0 && $classes) {
    $classId = (int) $classes[0]['id'];
}
$subjectId = get_int('subject_id');
if ($subjectId <= 0 && $subjects) {
    $subjectId = (int) $subjects[0]['id'];
}
$year = get_str('year');
if ($year === '' || !preg_match('/^\d{4}$/', $year)) {
    $year = academic_year();
}
$semester = get_int('semester');
if (!in_array($semester, [1, 2], true)) {
    $semester = academic_semester();
}

$subject = null;
foreach ($subjects as $row) {
    if ((int) $row['id'] === $subjectId) {
        $subject = $row;
    }
}
$classNames = array_column($classes, 'name', 'id');
$className = $classNames[$classId] ?? '';

if (is_post()) {
    verify_csrf();
    $postClass = (int) ($_POST['class_id'] ?? 0);
    $postSubject = (int) ($_POST['subject_id'] ?? 0);
    $postYear = post_str('year');
    $postSemester = (int) ($_POST['semester'] ?? 0);
    $scores = is_array($_POST['scores'] ?? null) ? $_POST['scores'] : [];

    $redirectUrl = 'gradebook.php?' . http_build_query([
        'class_id' => $postClass, 'subject_id' => $postSubject, 'year' => $postYear, 'semester' => $postSemester,
    ]);

    if ($postClass <= 0 || $postSubject <= 0 || !preg_match('/^\d{4}$/', $postYear) || !in_array($postSemester, [1, 2], true)) {
        flash('danger', 'ข้อมูลชั้นเรียน รายวิชา หรือภาคเรียนไม่ถูกต้อง');
        redirect($redirectUrl);
    }

    $stmt = $pdo->prepare("SELECT id FROM students WHERE class_id = ? AND status = 'studying'");
    $stmt->execute([$postClass]);
    $validIds = array_map('intval', array_column($stmt->fetchAll(), 'id'));

    $saved = 0;
    $pdo->beginTransaction();
    try {
        $upsert = $pdo->prepare("INSERT INTO grades (student_id, subject_id, academic_year, semester, score, grade, updated_by)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE score = VALUES(score), grade = VALUES(grade), updated_by = VALUES(updated_by)");
        foreach ($validIds as $studentId) {
            $raw = trim((string) ($scores[$studentId] ?? ''));
            if ($raw === '') {
                $score = null;
                $grade = '';
            } elseif (is_numeric($raw)) {
                $score = max(0, min(100, (float) $raw));
                $grade = grade_from_score($score);
            } else {
                continue;
            }
            $upsert->execute([$studentId, $postSubject, $postYear, $postSemester, $score, $grade, (int) $user['id']]);
            $saved++;
        }
        $pdo->commit();
        flash('success', 'บันทึกคะแนน ' . $saved . ' รายการ · ' . ($subject['name'] ?? 'รายวิชา') . ' ภาคเรียนที่ ' . $postSemester . ' เรียบร้อยแล้ว');
    } catch (Throwable $e) {
        $pdo->rollBack();
        flash('danger', 'ไม่สามารถบันทึกผลการเรียนได้ กรุณาลองใหม่อีกครั้ง');
    }
    redirect($redirectUrl);
}

$students = [];
$grades = [];
if ($classId > 0 && $subjectId > 0) {
    $stmt = $pdo->prepare("SELECT id, student_code, prefix, firstname, lastname, student_number
        FROM students WHERE class_id = ? AND status = 'studying'
        ORDER BY student_number, student_code");
    $stmt->execute([$classId]);
    $students = $stmt->fetchAll();

    $stmt = $pdo->prepare('SELECT student_id, score, grade FROM grades WHERE subject_id = ? AND academic_year = ? AND semester = ?');
    $stmt->execute([$subjectId, $year, $semester]);
    foreach ($stmt->fetchAll() as $row) {
        $grades[(int) $row['student_id']] = $row;
    }
}

$distribution = ['4.0' => 0, '3.5' => 0, '3.0' => 0, '2.5' => 0, '2.0' => 0, '1.5' => 0, '1.0' => 0, '0.0' => 0];
$scoreTotal = 0.0;
$scoreCount = 0;
$pointTotal = 0.0;
$gradeCount = 0;
$passCount = 0;
foreach ($students as $student) {
    $grade = $grades[(int) $student['id']]['grade'] ?? '';
    $score = $grades[(int) $student['id']]['score'] ?? null;
    if ($score !== null && $score !== '') {
        $scoreTotal += (float) $score;
        $scoreCount++;
    }
    if (is_numeric($grade)) {
        $pointTotal += (float) $grade;
        $gradeCount++;
        if ((float) $grade >= 1.0) {
            $passCount++;
        }
        if (isset($distribution[$grade])) {
            $distribution[$grade]++;
        }
    }
}
$averageScore = $scoreCount > 0 ? $scoreTotal / $scoreCount : 0;
$gpa = $gradeCount > 0 ? $pointTotal / $gradeCount : 0;

$pageTitle = 'บันทึกผลการเรียน';
$pageSubtitle = 'ปพ.5 · กรอกคะแนนและคำนวณเกรดอัตโนมัติ';
$activeNav = 'gradebook';
$pageActions = '<button class="btn btn-ghost btn-sm" type="button" data-print>' . icon('printer', 16) . '<span>พิมพ์</span></button>';

require_once __DIR__ . '/includes/header.php';
?>

<form class="att-toolbar no-print" method="get" action="<?= url('gradebook.php') ?>">
  <div class="field">
    <label><?= icon('building', 14) ?> ชั้นเรียน</label>
    <select class="select" name="class_id">
      <?php foreach ($classes as $class): ?>
        <option value="<?= (int) $class['id'] ?>" <?= $classId === (int) $class['id'] ? 'selected' : '' ?>><?= e($class['name']) ?></option>
      <?php endforeach; ?>
    </select>
  </div>
  <div class="field" style="min-width:220px">
    <label><?= icon('book', 14) ?> รายวิชา</label>
    <select class="select" name="subject_id">
      <?php foreach ($subjects as $row): ?>
        <option value="<?= (int) $row['id'] ?>" <?= $subjectId === (int) $row['id'] ? 'selected' : '' ?>><?= e($row['code'] . ' · ' . $row['name']) ?></option>
      <?php endforeach; ?>
    </select>
  </div>
  <div class="field" style="min-width:110px">
    <label><?= icon('calendar', 14) ?> ปีการศึกษา</label>
    <input class="input" type="text" name="year" value="<?= e($year) ?>" maxlength="4">
  </div>
  <div class="field" style="min-width:120px">
    <label>ภาคเรียน</label>
    <select class="select" name="semester">
      <option value="1" <?= $semester === 1 ? 'selected' : '' ?>>ภาคเรียนที่ 1</option>
      <option value="2" <?= $semester === 2 ? 'selected' : '' ?>>ภาคเรียนที่ 2</option>
    </select>
  </div>
  <button class="btn btn-primary" type="submit"><?= icon('refresh', 16) ?> เปิดสมุดคะแนน</button>
</form>

<div class="row-between mb-2 wrap">
  <div>
    <h2 style="font-size:1.15rem;font-weight:800;display:flex;align-items:center;gap:8px"><?= icon('edit', 20) ?> <?= e($subject['code'] ?? '—') ?> · <?= e($subject['name'] ?? 'ไม่พบรายวิชา') ?></h2>
    <p class="text-sm text-muted"><?= e($className ?: 'ไม่ระบุชั้นเรียน') ?> · ปีการศึกษา <?= e($year) ?> ภาคเรียนที่ <?= $semester ?> · <?= (float) ($subject['credits'] ?? 0) ?> หน่วยกิต</p>
  </div>
  <div class="row">
    <span class="chip chip-soft"><?= icon('users', 14) ?> <?= count($students) ?> คน</span>
    <span class="chip"><?= icon('award', 14) ?> ผ่าน <?= $passCount ?>/<?= $gradeCount ?></span>
  </div>
</div>

<?php if (!$classes || !$subjects): ?>
  <div class="card"><div class="empty-state"><div class="empty-ico"><?= icon('book', 30) ?></div><h3>ยังไม่มีข้อมูลชั้นเรียนหรือรายวิชา</h3><p>เพิ่มชั้นเรียนและรายวิชาก่อนบันทึกผลการเรียน</p><a class="btn btn-primary btn-sm" href="<?= url('subjects.php?new=1') ?>">เพิ่มรายวิชา</a></div></div>
<?php elseif (!$students): ?>
  <div class="card"><div class="empty-state"><div class="empty-ico"><?= icon('users', 30) ?></div><h3>ยังไม่มีนักเรียนในชั้นนี้</h3><p>เลือกชั้นเรียนอื่นหรือเพิ่มนักเรียนก่อนบันทึกคะแนน</p></div></div>
<?php else: ?>
<div class="grid grid-2-1">
  <form method="post" action="<?= url('gradebook.php') ?>" class="card" id="gradebookForm">
    <?= csrf_field() ?>
    <input type="hidden" name="class_id" value="<?= $classId ?>">
    <input type="hidden" name="subject_id" value="<?= $subjectId ?>">
    <input type="hidden" name="year" value="<?= e($year) ?>">
    <input type="hidden" name="semester" value="<?= $semester ?>">

    <div class="card-head bordered">
      <div>
        <h3 class="card-title"><?= icon('clipboard', 19) ?> สมุดบันทึกคะแนน</h3>
        <p class="card-sub">กรอกคะแนนเต็ม 100 ระบบจะคำนวณเกรดให้ทันที</p>
      </div>
      <div class="card-actions">
        <button class="btn btn-ghost btn-sm no-print" type="button" data-fill-score><?= icon('sparkles', 14) ?> เติมคะแนนทั้งห้อง</button>
        <button class="btn btn-primary btn-sm" type="submit"><?= icon('save', 15) ?> บันทึกคะแนน</button>
      </div>
    </div>

    <div class="table-wrap" style="border:0;border-radius:0;box-shadow:none">
      <table class="table" id="gradeTable">
        <thead>
          <tr>
            <th style="width:52px">เลขที่</th>
            <th>นักเรียน</th>
            <th style="width:110px">คะแนน (100)</th>
            <th style="width:90px" class="text-center">เกรด</th>
          </tr>
        </thead>
        <tbody>
        <?php foreach ($students as $student): ?>
          <?php
            $row = $grades[(int) $student['id']] ?? ['score' => null, 'grade' => ''];
            $scoreValue = $row['score'] !== null && $row['score'] !== '' ? number_format((float) $row['score'], 1, '.', '') : '';
            $gradeValue = is_numeric($row['grade']) ? $row['grade'] : '—';
          ?>
          <tr>
            <td class="text-muted num"><?= (int) $student['student_number'] ?></td>
            <td>
              <div class="cell-user">
                <span class="avatar sm <?= avatar_class($student['firstname']) ?>"><?= e(name_initials($student['firstname'], $student['lastname'])) ?></span>
                <div><b><?= e(student_name($student)) ?></b><small><?= e($student['student_code']) ?></small></div>
              </div>
            </td>
            <td>
              <input class="input grade-input" type="number" name="scores[<?= (int) $student['id'] ?>]" value="<?= e($scoreValue) ?>" min="0" max="100" step="0.5" placeholder="—" data-grade-input>
            </td>
            <td class="text-center"><span class="grade-chip <?= $gradeValue !== '—' ? grade_class($gradeValue) : 'g0' ?> grade-live" data-grade-chip style="<?= $gradeValue === '—' ? 'background:#f1f5f9;color:#94a3b8' : '' ?>"><?= e($gradeValue) ?></span></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <div class="card-footer">
      <div class="row-between wrap">
        <span class="text-xs text-muted"><?= icon('info', 14) ?> เกณฑ์: 80+=4.0 · 75+=3.5 · 70+=3.0 · 65+=2.5 · 60+=2.0 · 55+=1.5 · 50+=1.0</span>
        <button class="btn btn-primary" type="submit"><?= icon('save', 16) ?> บันทึกผลการเรียน</button>
      </div>
    </div>
  </form>

  <div class="stack">
    <article class="card">
      <div class="card-head">
        <div><h3 class="card-title"><?= icon('chart', 19) ?> สรุปผลสัมฤทธิ์</h3><p class="card-sub"><?= e($className) ?> · <?= e($subject['name'] ?? '') ?></p></div>
      </div>
      <div class="card-body">
        <div class="gb-summary" style="flex-direction:column">
          <div class="gb-stat" style="display:flex;align-items:center;justify-content:space-between">
            <div><b id="gbAverage"><?= number_format($averageScore, 1) ?></b><span>คะแนนเฉลี่ย</span></div>
            <?= icon('chart', 24, 'text-muted') ?>
          </div>
          <div class="gb-stat" style="display:flex;align-items:center;justify-content:space-between">
            <div><b><?= number_format($gpa, 2) ?></b><span>เกรดเฉลี่ย (GPA)</span></div>
            <?= icon('award', 24, 'text-muted') ?>
          </div>
          <div class="gb-stat" style="display:flex;align-items:center;justify-content:space-between">
            <div><b><?= $passCount ?>/<?= $gradeCount ?></b><span>ผ่านรายวิชา</span></div>
            <?= icon('check-circle', 24, 'text-muted') ?>
          </div>
        </div>

        <div class="form-section-title mt-2" style="margin-bottom:10px"><?= icon('filter', 16) ?> การกระจายของเกรด</div>
        <div class="stack" style="gap:9px">
          <?php foreach ($distribution as $grade => $count): ?>
            <?php $pct = $gradeCount > 0 ? $count / $gradeCount * 100 : 0; ?>
            <div class="row" style="gap:9px">
              <span class="grade-chip <?= grade_class($grade) ?>" style="width:44px"><?= e($grade) ?></span>
              <div class="meter <?= (float) $grade >= 3 ? 'green' : ((float) $grade >= 1 ? '' : 'rose') ?>" style="flex:1"><span data-meter="<?= round($pct, 1) ?>"></span></div>
              <b class="num" data-dist="<?= e($grade) ?>" style="font-size:.78rem;min-width:22px;text-align:right"><?= $count ?></b>
            </div>
          <?php endforeach; ?>
        </div>
        <div class="notice notice-info mt-2">
          <?= icon('info', 17) ?>
          <div>คะแนนและเกรดจะถูกบันทึกแยกตามปีการศึกษาและภาคเรียน สามารถย้อนกลับมาแก้ไขได้ตลอดเวลา</div>
        </div>
      </div>
    </article>

    <article class="card no-print">
      <div class="card-head">
        <div><h3 class="card-title"><?= icon('file', 19) ?> เอกสารที่เกี่ยวข้อง</h3><p class="card-sub">พิมพ์รายงานผลการเรียนรายวิชา</p></div>
      </div>
      <div class="card-body">
        <a class="btn btn-ghost" style="width:100%;justify-content:flex-start" href="<?= url('attendance-report.php?class_id=' . $classId . '&month=' . date('Y-m')) ?>"><?= icon('chart', 16) ?> รายงานเวลาเรียนของชั้นนี้</a>
      </div>
    </article>
  </div>
</div>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
