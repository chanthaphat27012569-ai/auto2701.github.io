<?php

require_once __DIR__ . '/includes/bootstrap.php';

require_staff();
require_manage();
$pdo = db();

$id = get_int('id', (int) ($_POST['id'] ?? 0));
$isEdit = $id > 0;
$errors = [];

$student = [
    'student_code' => '',
    'prefix' => 'เด็กชาย',
    'firstname' => '',
    'lastname' => '',
    'gender' => 'male',
    'class_id' => '',
    'student_number' => '',
    'citizen_id' => '',
    'portal_pin' => '',
    'birth_date' => '',
    'birth_place' => '',
    'nationality' => 'ไทย',
    'religion' => 'พุทธ',
    'blood_type' => '',
    'address' => '',
    'parent_name' => '',
    'parent_relation' => 'บิดา',
    'parent_phone' => '',
    'guardian_phone' => '',
    'status' => 'studying',
    'admission_date' => '',
];

if ($isEdit) {
    $stmt = $pdo->prepare('SELECT * FROM students WHERE id = ?');
    $stmt->execute([$id]);
    $existing = $stmt->fetch();
    if (!$existing) {
        flash('danger', 'ไม่พบข้อมูลนักเรียนที่ต้องการแก้ไข');
        redirect('students.php');
    }
    $student = array_merge($student, $existing);
}

if (!$isEdit && $student['student_code'] === '') {
    $maxCode = (int) $pdo->query("SELECT MAX(CAST(student_code AS UNSIGNED)) FROM students WHERE student_code REGEXP '^[0-9]+$'")->fetchColumn();
    $student['student_code'] = (string) max(1001, $maxCode + 1);
}

if (is_post()) {
    verify_csrf();

    $fields = ['student_code', 'prefix', 'firstname', 'lastname', 'gender', 'class_id', 'student_number',
        'citizen_id', 'portal_pin', 'birth_date', 'birth_place', 'nationality', 'religion', 'blood_type',
        'address', 'parent_name', 'parent_relation', 'parent_phone', 'guardian_phone', 'status', 'admission_date'];
    foreach ($fields as $field) {
        $student[$field] = post_str($field);
    }

    if ($student['student_code'] === '') {
        $errors[] = 'กรุณากรอกรหัสนักเรียน';
    }
    if ($student['firstname'] === '') {
        $errors[] = 'กรุณากรอกชื่อ';
    }
    if ($student['lastname'] === '') {
        $errors[] = 'กรุณากรอกนามสกุล';
    }
    if (!in_array($student['gender'], ['male', 'female'], true)) {
        $errors[] = 'เพศไม่ถูกต้อง';
    }
    if (!in_array($student['status'], ['studying', 'graduated', 'transferred', 'inactive'], true)) {
        $errors[] = 'สถานะไม่ถูกต้อง';
    }
    if ((int) $student['class_id'] > 0) {
        $checkClass = $pdo->prepare('SELECT COUNT(*) FROM classes WHERE id = ?');
        $checkClass->execute([(int) $student['class_id']]);
        if (!(int) $checkClass->fetchColumn()) {
            $errors[] = 'ไม่พบชั้นเรียนที่เลือก';
        }
    }
    if ($student['student_code'] !== '') {
        $dupStmt = $pdo->prepare('SELECT COUNT(*) FROM students WHERE student_code = ? AND id <> ?');
        $dupStmt->execute([$student['student_code'], $id]);
        if ((int) $dupStmt->fetchColumn() > 0) {
            $errors[] = 'รหัสนักเรียน "' . $student['student_code'] . '" ถูกใช้งานแล้ว';
        }
    }
    foreach (['birth_date', 'admission_date'] as $dateField) {
        if ($student[$dateField] !== '') {
            $d = DateTime::createFromFormat('Y-m-d', $student[$dateField]);
            if (!$d || $d->format('Y-m-d') !== $student[$dateField]) {
                $errors[] = 'รูปแบบวันที่ไม่ถูกต้อง';
            }
        }
    }
    if ($student['portal_pin'] === '') {
        $student['portal_pin'] = substr(preg_replace('/\D/', '', $student['student_code']), -4);
    }
    $student['portal_pin'] = preg_replace('/\D/', '', $student['portal_pin']);
    $student['student_number'] = (string) max(0, (int) $student['student_number']);

    if (!$errors) {
        $payload = [
            'student_code' => $student['student_code'],
            'prefix' => $student['prefix'],
            'firstname' => $student['firstname'],
            'lastname' => $student['lastname'],
            'gender' => $student['gender'],
            'class_id' => (int) $student['class_id'] ?: null,
            'student_number' => (int) $student['student_number'],
            'citizen_id' => $student['citizen_id'],
            'portal_pin' => $student['portal_pin'],
            'birth_date' => $student['birth_date'] ?: null,
            'birth_place' => $student['birth_place'],
            'nationality' => $student['nationality'],
            'religion' => $student['religion'],
            'blood_type' => $student['blood_type'],
            'address' => $student['address'],
            'parent_name' => $student['parent_name'],
            'parent_relation' => $student['parent_relation'],
            'parent_phone' => $student['parent_phone'],
            'guardian_phone' => $student['guardian_phone'],
            'status' => $student['status'],
            'admission_date' => $student['admission_date'] ?: null,
        ];

        if ($isEdit) {
            $sets = implode(', ', array_map(fn($key) => "$key = :$key", array_keys($payload)));
            $stmt = $pdo->prepare("UPDATE students SET $sets WHERE id = :id");
            $stmt->execute($payload + ['id' => $id]);
            flash('success', 'บันทึกข้อมูลนักเรียนเรียบร้อยแล้ว');
            redirect('student-view.php?id=' . $id);
        }

        $columns = implode(', ', array_keys($payload));
        $values = implode(', ', array_map(fn($key) => ":$key", array_keys($payload)));
        $stmt = $pdo->prepare("INSERT INTO students ($columns) VALUES ($values)");
        $stmt->execute($payload);
        $newId = (int) $pdo->lastInsertId();
        flash('success', 'เพิ่มนักเรียนใหม่เรียบร้อยแล้ว');
        redirect('student-view.php?id=' . $newId);
    }
}

$classes = $pdo->query("SELECT id, name, level_short FROM classes ORDER BY name")->fetchAll();
$classNames = array_column($classes, 'name', 'id');
$previewClass = (int) $student['class_id'] > 0 ? ($classNames[(int) $student['class_id']] ?? '') : '';

$pageTitle = $isEdit ? 'แก้ไขข้อมูลนักเรียน' : 'เพิ่มนักเรียนใหม่';
$pageSubtitle = $isEdit ? 'ปรับปรุงข้อมูลทะเบียนของนักเรียน' : 'บันทึกข้อมูลนักเรียนเข้าสู่ทะเบียน';
$activeNav = 'students';
$pageActions = '<a class="btn btn-ghost btn-sm" href="' . url('students.php') . '">' . icon('arrow-left', 16) . '<span>กลับทะเบียน</span></a>';

require_once __DIR__ . '/includes/header.php';
?>

<?php if ($errors): ?>
  <div class="notice notice-danger mb-2" style="animation:shake .45s ease">
    <?= icon('alert', 20) ?>
    <div>
      <strong>ไม่สามารถบันทึกได้</strong>
      <ul style="margin:4px 0 0 16px;padding:0">
        <?php foreach ($errors as $error): ?><li><?= e($error) ?></li><?php endforeach; ?>
      </ul>
    </div>
  </div>
<?php endif; ?>

<form method="post" action="<?= url('student-form.php' . ($isEdit ? '?id=' . $id : '')) ?>" class="grid grid-1-2" id="studentForm">
  <?= csrf_field() ?>
  <input type="hidden" name="id" value="<?= $id ?>">

  <div class="stack">
    <aside class="card" style="position:sticky;top:96px">
      <div class="card-body text-center">
        <div style="display:flex;justify-content:center;margin-bottom:12px">
          <span class="avatar xl <?= avatar_class($student['firstname'] ?: '?') ?>" id="avatarPreview"><?= e(name_initials($student['firstname'] ?: '?', $student['lastname'])) ?></span>
        </div>
        <h3 id="previewName" style="font-size:1.08rem;font-weight:800"><?= e(trim(($student['prefix'] ?? '') . ' ' . $student['firstname'] . ' ' . $student['lastname'])) ?: 'นักเรียนใหม่' ?></h3>
        <p class="text-sm text-muted" id="previewMeta"><?= e(($previewClass ? $previewClass . ' · ' : '') . ($student['student_code'] ? 'รหัส ' . $student['student_code'] : 'ยังไม่ระบุชั้นเรียน')) ?></p>

        <div class="stack mt-3" style="gap:9px;text-align:left">
          <div class="notice notice-info" style="padding:10px 12px"><?= icon('info', 17) ?><span>รหัส PIN ใช้สำหรับนักเรียน/ผู้ปกครองเข้าพอร์ทัล หากเว้นว่าง ระบบจะใช้ 4 หลักท้ายของรหัสนักเรียน</span></div>
          <div class="notice notice-success" style="padding:10px 12px"><?= icon('shield', 17) ?><span>ข้อมูลถูกบันทึกในฐานข้อมูล MySQL ผ่าน prepared statements อย่างปลอดภัย</span></div>
        </div>
      </div>
      <?php if ($isEdit): ?>
        <div class="card-footer">
          <a class="btn btn-ghost btn-sm btn-block" href="<?= url('student-view.php?id=' . $id) ?>"><?= icon('eye', 16) ?> ดูโปรไฟล์นักเรียน</a>
        </div>
      <?php endif; ?>
    </aside>
  </div>

  <div class="stack">
    <section class="card">
      <div class="card-head bordered">
        <div><h3 class="card-title"><?= icon('user', 19) ?> ข้อมูลพื้นฐาน</h3><p class="card-sub">ข้อมูลชื่อ-สกุลและชั้นเรียน</p></div>
      </div>
      <div class="card-body">
        <div class="form-grid">
          <div class="field">
            <label for="student_code">รหัสนักเรียน <span class="req">*</span></label>
            <input class="input" id="student_code" name="student_code" value="<?= e($student['student_code']) ?>" required>
          </div>
          <div class="field">
            <label for="prefix">คำนำหน้า</label>
            <select class="select" id="prefix" name="prefix">
              <?php foreach (['เด็กชาย', 'เด็กหญิง', 'นาย', 'นางสาว'] as $prefix): ?>
                <option value="<?= e($prefix) ?>" <?= $student['prefix'] === $prefix ? 'selected' : '' ?>><?= e($prefix) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="field">
            <label for="firstname">ชื่อ <span class="req">*</span></label>
            <input class="input" id="firstname" name="firstname" value="<?= e($student['firstname']) ?>" required>
          </div>
          <div class="field">
            <label for="lastname">นามสกุล <span class="req">*</span></label>
            <input class="input" id="lastname" name="lastname" value="<?= e($student['lastname']) ?>" required>
          </div>
          <div class="field">
            <label for="gender">เพศ</label>
            <select class="select" id="gender" name="gender">
              <option value="male" <?= $student['gender'] === 'male' ? 'selected' : '' ?>>ชาย</option>
              <option value="female" <?= $student['gender'] === 'female' ? 'selected' : '' ?>>หญิง</option>
            </select>
          </div>
          <div class="field">
            <label for="class_id">ชั้นเรียน</label>
            <select class="select" id="class_id" name="class_id">
              <option value="">— ยังไม่ระบุชั้นเรียน —</option>
              <?php foreach ($classes as $class): ?>
                <option value="<?= (int) $class['id'] ?>" <?= (int) $student['class_id'] === (int) $class['id'] ? 'selected' : '' ?>><?= e($class['name']) ?> (<?= e($class['level_short']) ?>)</option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="field">
            <label for="student_number">เลขที่ในห้อง</label>
            <input class="input" id="student_number" name="student_number" type="number" min="0" max="99" value="<?= e($student['student_number']) ?>">
          </div>
          <div class="field">
            <label for="status">สถานะ</label>
            <select class="select" id="status" name="status">
              <?php foreach (student_status_meta() as $key => $meta): ?>
                <option value="<?= e($key) ?>" <?= $student['status'] === $key ? 'selected' : '' ?>><?= e($meta['label']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="field">
            <label for="citizen_id">เลขบัตรประชาชน</label>
            <input class="input" id="citizen_id" name="citizen_id" value="<?= e($student['citizen_id']) ?>" inputmode="numeric">
          </div>
          <div class="field">
            <label for="portal_pin">PIN พอร์ทัล</label>
            <input class="input" id="portal_pin" name="portal_pin" value="<?= e($student['portal_pin']) ?>" maxlength="8" inputmode="numeric" placeholder="4 หลักท้ายรหัส">
          </div>
        </div>
      </div>
    </section>

    <section class="card">
      <div class="card-head bordered">
        <div><h3 class="card-title"><?= icon('calendar', 19) ?> ข้อมูลส่วนตัว</h3><p class="card-sub">วันเกิด สัญชาติ และที่อยู่</p></div>
      </div>
      <div class="card-body">
        <div class="form-grid">
          <div class="field">
            <label for="birth_date">วันเกิด</label>
            <input class="input" id="birth_date" name="birth_date" type="date" value="<?= e($student['birth_date']) ?>">
          </div>
          <div class="field">
            <label for="birth_place">สถานที่เกิด</label>
            <input class="input" id="birth_place" name="birth_place" value="<?= e($student['birth_place']) ?>">
          </div>
          <div class="field">
            <label for="nationality">สัญชาติ</label>
            <input class="input" id="nationality" name="nationality" value="<?= e($student['nationality']) ?>">
          </div>
          <div class="field">
            <label for="religion">ศาสนา</label>
            <select class="select" id="religion" name="religion">
              <?php foreach (['พุทธ', 'อิสลาม', 'คริสต์', 'ฮินดู', 'อื่น ๆ'] as $religion): ?>
                <option value="<?= e($religion) ?>" <?= $student['religion'] === $religion ? 'selected' : '' ?>><?= e($religion) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="field">
            <label for="blood_type">กรุ๊ปเลือด</label>
            <select class="select" id="blood_type" name="blood_type">
              <option value="">— ไม่ระบุ —</option>
              <?php foreach (['A', 'B', 'O', 'AB'] as $blood): ?>
                <option value="<?= $blood ?>" <?= $student['blood_type'] === $blood ? 'selected' : '' ?>><?= $blood ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="field">
            <label for="admission_date">วันที่เข้าศึกษา</label>
            <input class="input" id="admission_date" name="admission_date" type="date" value="<?= e($student['admission_date']) ?>">
          </div>
          <div class="field span-2">
            <label for="address">ที่อยู่ปัจจุบัน</label>
            <textarea class="textarea" id="address" name="address" rows="2"><?= e($student['address']) ?></textarea>
          </div>
        </div>
      </div>
    </section>

    <section class="card">
      <div class="card-head bordered">
        <div><h3 class="card-title"><?= icon('users', 19) ?> ผู้ปกครอง</h3><p class="card-sub">ข้อมูลผู้ปกครองและช่องทางติดต่อ</p></div>
      </div>
      <div class="card-body">
        <div class="form-grid">
          <div class="field">
            <label for="parent_name">ชื่อผู้ปกครอง</label>
            <input class="input" id="parent_name" name="parent_name" value="<?= e($student['parent_name']) ?>">
          </div>
          <div class="field">
            <label for="parent_relation">ความสัมพันธ์</label>
            <select class="select" id="parent_relation" name="parent_relation">
              <?php foreach (['บิดา', 'มารดา', 'ผู้ปกครอง', 'ญาติ'] as $relation): ?>
                <option value="<?= e($relation) ?>" <?= $student['parent_relation'] === $relation ? 'selected' : '' ?>><?= e($relation) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="field">
            <label for="parent_phone">โทรศัพท์ผู้ปกครอง</label>
            <input class="input" id="parent_phone" name="parent_phone" value="<?= e($student['parent_phone']) ?>" data-phone inputmode="tel" placeholder="08X-XXX-XXXX">
          </div>
          <div class="field">
            <label for="guardian_phone">โทรศัพท์ฉุกเฉิน</label>
            <input class="input" id="guardian_phone" name="guardian_phone" value="<?= e($student['guardian_phone']) ?>" data-phone inputmode="tel" placeholder="09X-XXX-XXXX">
          </div>
        </div>
        <div class="form-actions">
          <button class="btn btn-primary btn-lg" type="submit"><?= icon('save', 18) ?> <?= $isEdit ? 'บันทึกการแก้ไข' : 'เพิ่มนักเรียน' ?></button>
          <a class="btn btn-ghost" href="<?= url('students.php') ?>">ยกเลิก</a>
        </div>
      </div>
    </section>
  </div>
</form>

<script>
(function () {
  var first = document.getElementById('firstname');
  var last = document.getElementById('lastname');
  var prefix = document.getElementById('prefix');
  var code = document.getElementById('student_code');
  var cls = document.getElementById('class_id');
  var avatar = document.getElementById('avatarPreview');
  var nameEl = document.getElementById('previewName');
  var metaEl = document.getElementById('previewMeta');
  function update() {
    var f = (first && first.value.trim()) || '?';
    var l = (last && last.value.trim()) || '';
    if (avatar) avatar.textContent = f.charAt(0) + (l.charAt(0) || '');
    if (nameEl) nameEl.textContent = ((prefix ? prefix.value : '') + ' ' + (first ? first.value : '') + ' ' + (last ? last.value : '')).trim() || 'นักเรียนใหม่';
    if (metaEl) {
      var className = cls && cls.selectedIndex >= 0 && cls.value ? cls.options[cls.selectedIndex].text.split(' (')[0] : '';
      metaEl.textContent = (className ? className + ' · ' : '') + (code && code.value ? 'รหัส ' + code.value : 'ยังไม่ระบุชั้นเรียน');
    }
  }
  [first, last, prefix, code, cls].forEach(function (el) { if (el) el.addEventListener('input', update); });
})();
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
