<?php

require_once __DIR__ . '/includes/bootstrap.php';

if (current_staff()) {
    redirect('dashboard.php');
}

if (current_student()) {
    redirect('portal.php');
}

redirect('login.php');
