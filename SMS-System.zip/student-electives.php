<?php

require_once __DIR__ . '/includes/bootstrap.php';

$portalActive = 'electives';
$pageTitle = 'ลงทะเบียนวิชาเพิ่มเติม';
$pageSubtitle = 'นักเรียน ม.1–ม.3 เลือกได้ 1 วิชา';
require __DIR__ . '/includes/student-context.php';

$studentId = (int) $student['id'];
$portalTablesReady = portal_tables_ready();
$eligibleLevels = ['ม.1', 'ม.2', 'ม.3'];
$studentLevel = (string) ($student['level_short'] ?? '');
$isEligible = in_array($studentLevel, $eligibleLevels, true);

if (is_post() && post_str('action') === 'register_elective') {
    verify_csrf();
    if ($isPreview) {
        flash('warning', 'โหมดตัวอย่างไม่สามารถลงทะเบียนวิชาเพิ่มเติมได้');
        redirect('student-electives.php');
    }
    if (!$portalTablesReady) {
        flash('danger', 'ระบบวิชาเพิ่มเติมยังไม่พร้อมใช้งาน กรุณานำเข้า student-portal.sql');
        redirect('student-electives.php');
    }
    if (!$isEligible) {
        flash('danger', 'เฉพาะนักเรียนระดับ ม.1–ม.3 เท่านั้นที่ลงทะเบียนวิชาเพิ่มเติมได้');
        redirect('student-electives.php');
    }

    $subjectId = (int) post_str('subject_id');
    $error = $subjectId > 0 ? '' : 'กรุณาเลือกวิชาเพิ่มเติมที่ต้องการลงทะเบียน';

    if ($error === '') {
        try {
            $pdo->beginTransaction();

            $subjectStmt = $pdo->prepare("SELECT * FROM subjects
                WHERE id = ? AND status = 'active' AND category = 'วิชาเพิ่มเติม' FOR UPDATE");
            $subjectStmt->execute([$subjectId]);
            $subject = $subjectStmt->fetch();

            if (!$subject) {
                $pdo->rollBack();
                $error = 'ไม่พบวิชาเพิ่มเติมที่เลือก หรือวิชาปิดรับสมัครแล้ว';
            } else {
                $existingStmt = $pdo->prepare('SELECT sub.name FROM elective_registrations er
                    JOIN subjects sub ON sub.id = er.subject_id
                    WHERE er.student_id = ? AND er.academic_year = ? AND er.semester = ? LIMIT 1');
                $existingStmt->execute([$studentId, $year, $semester]);
                $existingName = $existingStmt->fetchColumn();

                if ($existingName !== false && $existingName !== null) {
                    $pdo->rollBack();
                    $error = 'ลงทะเบียนวิชา "' . $existingName . '" ไปแล้ว และไม่สามารถเปลี่ยนเองได้';
                } else {
                    $insertStmt = $pdo->prepare('INSERT INTO elective_registrations (subject_id, student_id, academic_year, semester) VALUES (?, ?, ?, ?)');
                    $insertStmt->execute([$subjectId, $studentId, $year, $semester]);
                    $pdo->commit();
                    flash('success', 'ลงทะเบียนวิชาเพิ่มเติม "' . $subject['name'] . '" สำเร็จ');
                    redirect('student-electives.php');
                }
            }
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $error = 'ไม่สามารถลงทะเบียนได้ กรุณาลองใหม่อีกครั้ง';
        }
    }

    if ($error !== '') {
        flash('danger', $error);
        redirect('student-electives.php');
    }
}

$subjects = [];
$myRegistration = null;

if ($portalTablesReady) {
    $subjectListStmt = $pdo->prepare("SELECT * FROM subjects
        WHERE status = 'active' AND category = 'วิชาเพิ่มเติม'
        ORDER BY department, code");
    $subjectListStmt->execute();
    $subjects = $subjectListStmt->fetchAll();

    $myStmt = $pdo->prepare('SELECT er.*, sub.code, sub.name, sub.department, sub.hours
        FROM elective_registrations er JOIN subjects sub ON sub.id = er.subject_id
        WHERE er.student_id = ? AND er.academic_year = ? AND er.semester = ?
        ORDER BY er.id DESC LIMIT 1');
    $myStmt->execute([$studentId, $year, $semester]);
    $myRegistration = $myStmt->fetch() ?: null;
}

$registrationLocked = (bool) $myRegistration;

require __DIR__ . '/includes/student-portal-top.php';
?>

<div class="page-heading">
  <div>
    <span class="hero-kicker dark"><?= icon('book', 15) ?> วิชาเพิ่มเติม</span>
    <h1>ลงทะเบียนวิชาเพิ่มเติม</h1>
    <p>ปีการศึกษา <?= e($year) ?> ภาคเรียนที่ <?= $semester ?> · <?= e($classText ?: 'ไม่ระบุชั้นเรียน') ?> · เลือกได้ 1 วิชา (ไม่คิดหน่วยกิต)</p>
  </div>
  <?php if ($myRegistration): ?>
    <span class="badge badge-success"><span class="dot"></span>ลงทะเบียนแล้ว</span>
  <?php elseif ($isEligible): ?>
    <span class="badge badge-warning"><span class="dot"></span>ยังไม่ลงทะเบียน</span>
  <?php else: ?>
    <span class="badge badge-muted"><?= icon('lock', 13) ?> ไม่เปิดให้ลงทะเบียน</span>
  <?php endif; ?>
</div>

<?php if (!$portalTablesReady): ?>
  <div class="notice notice-warning mb-2"><?= icon('alert', 18) ?><div><strong>ยังไม่มีข้อมูลวิชาเพิ่มเติม</strong><br>กรุณาให้เจ้าหน้าที่นำเข้าไฟล์ <code>database/student-portal.sql</code> เพื่อเปิดใช้งานระบบลงทะเบียนวิชาเพิ่มเติม</div></div>
<?php endif; ?>

<?php if ($isPreview): ?>
  <div class="notice notice-info mb-2"><?= icon('eye', 18) ?><div>โหมดตัวอย่างสำหรับเจ้าหน้าที่ — ไม่สามารถลงทะเบียนวิชาเพิ่มเติมแทนนักเรียนได้</div></div>
<?php endif; ?>

<?php if (!$isEligible): ?>
  <div class="notice notice-info mb-2">
    <?= icon('info', 18) ?>
    <div><strong>ไม่เปิดให้ลงทะเบียนสำหรับระดับชั้นนี้</strong><br>การลงทะเบียนวิชาเพิ่มเติมเปิดเฉพาะนักเรียนระดับ ม.1–ม.3 เท่านั้น</div>
  </div>
<?php elseif ($myRegistration): ?>
  <article class="card registration-hero mb-2">
    <div class="card-body">
      <div class="registration-hero-main">
        <span class="reg-ico"><?= icon('book', 24) ?></span>
        <div>
          <span class="hero-kicker dark">วิชาเพิ่มเติมที่ลงทะเบียนแล้ว</span>
          <h2><?= e($myRegistration['name']) ?></h2>
          <p class="text-sm text-muted"><?= e($myRegistration['code']) ?> · <?= e($myRegistration['department'] ?: '—') ?> · <?= number_format((int) $myRegistration['hours']) ?> ชั่วโมง · ไม่คิดหน่วยกิต</p>
        </div>
      </div>
      <div class="registration-hero-side">
        <span class="badge badge-success"><span class="dot"></span>ยืนยันการลงทะเบียนแล้ว</span>
        <small class="text-muted">ไม่สามารถยกเลิกหรือเปลี่ยนวิชาเองได้ กรุณาติดต่อฝ่ายวิชาการ</small>
      </div>
    </div>
  </article>
<?php endif; ?>

<div class="club-grid">
  <?php foreach ($subjects as $subject): ?>
    <?php $isMine = $myRegistration && (int) $myRegistration['subject_id'] === (int) $subject['id']; ?>
    <article class="club-card <?= $isMine ? 'is-mine' : '' ?>">
      <div class="club-card-head">
        <span class="club-code"><?= e($subject['code']) ?></span>
        <?php if ($isMine): ?><span class="badge badge-success"><span class="dot"></span>วิชาของฉัน</span><?php else: ?><span class="badge badge-info">ไม่คิดหน่วยกิต</span><?php endif; ?>
      </div>
      <h3><?= e($subject['name']) ?></h3>
      <p><?= e($subject['department'] ?: 'วิชาเพิ่มเติม') ?> · <?= number_format((int) $subject['hours']) ?> ชั่วโมง</p>
      <div class="club-meta">
        <span><?= icon('book', 13) ?> วิชาเพิ่มเติม</span>
        <span><?= icon('award', 13) ?> ไม่คิดหน่วยกิต</span>
      </div>
      <form method="post" action="<?= e(portal_url('student-electives.php')) ?>" class="club-action"
        <?php if (!$isMine && !$myRegistration && $isEligible && !$isPreview): ?>data-confirm="ยืนยันลงทะเบียนวิชา &quot;<?= e($subject['name']) ?>&quot;? หลังลงทะเบียนแล้วจะไม่สามารถเปลี่ยนวิชาเองได้"<?php endif; ?>>
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="register_elective">
        <input type="hidden" name="subject_id" value="<?= (int) $subject['id'] ?>">
        <?php if ($isMine): ?>
          <button type="button" class="btn btn-ghost" style="width:100%" disabled><?= icon('check', 16) ?> ลงทะเบียนแล้ว</button>
        <?php elseif ($myRegistration): ?>
          <button type="button" class="btn btn-ghost" style="width:100%" disabled><?= icon('lock', 16) ?> ล็อกแล้ว</button>
        <?php elseif (!$isEligible): ?>
          <button type="button" class="btn btn-ghost" style="width:100%" disabled><?= icon('lock', 16) ?> ไม่เปิดให้ลงทะเบียน</button>
        <?php elseif ($isPreview): ?>
          <button type="button" class="btn btn-ghost" style="width:100%" disabled><?= icon('eye', 16) ?> โหมดตัวอย่าง</button>
        <?php else: ?>
          <button type="submit" class="btn btn-primary" style="width:100%"><?= icon('check', 16) ?> ลงทะเบียนวิชานี้</button>
        <?php endif; ?>
      </form>
    </article>
  <?php endforeach; ?>
  <?php if (!$subjects): ?>
    <div class="card"><div class="empty-state"><div class="empty-ico"><?= icon('book', 28) ?></div><h3>ยังไม่มีวิชาเพิ่มเติมเปิดลงทะเบียน</h3><p>รายวิชาสำหรับภาคเรียนนี้จะแสดงที่นี่</p></div></div>
  <?php endif; ?>
</div>

<div class="notice notice-info mt-2">
  <?= icon('lock', 18) ?>
  <div><strong>เงื่อนไขการลงทะเบียนวิชาเพิ่มเติม</strong><br>นักเรียน ม.1–ม.3 เลือกได้ 1 วิชาต่อภาคเรียน โดยไม่คิดหน่วยกิต เมื่อลงทะเบียนแล้วระบบจะล็อกและไม่สามารถยกเลิกหรือเปลี่ยนวิชาเองได้ หากมีความจำเป็นกรุณาติดต่อฝ่ายวิชาการ</div>
</div>

<?php require __DIR__ . '/includes/student-portal-bottom.php'; ?>
