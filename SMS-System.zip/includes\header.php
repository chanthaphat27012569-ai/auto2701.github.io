<?php

$user = require_staff();
$flashes = pull_flashes();
$pageTitle = $pageTitle ?? 'แดชบอร์ด';
$pageSubtitle = $pageSubtitle ?? 'ภาพรวมระบบบริหารสถานศึกษา';
$activeNav = $activeNav ?? 'dashboard';
$pageActions = $pageActions ?? '';
$pageClass = $pageClass ?? '';

$docCount = 0;
try {
    $docCount = (int) db()->query('SELECT COUNT(*) FROM documents')->fetchColumn();
} catch (Throwable $e) {
}

$docBadge = $docCount > 99 ? '99+' : (string) $docCount;
$isAdmin = is_admin();

$navItems = [
    'ภาพรวม' => [
        ['dashboard', 'dashboard.php', 'แดชบอร์ด', 'dashboard'],
    ],
    'การเรียนการสอน' => [
        ['attendance', 'attendance.php', 'เช็คชื่อประจำวัน', 'check'],
        ['attendance-report', 'attendance-report.php', 'รายงานเวลาเรียน', 'chart'],
        ['gradebook', 'gradebook.php', 'บันทึกผลการเรียน (ปพ.5)', 'edit'],
        ['documents', 'documents.php', 'ศูนย์เอกสาร ปพ.1–9', 'file', $docBadge],
    ],
    'ทะเบียนและวิชาการ' => [
        ['students', 'students.php', 'ข้อมูลนักเรียน', 'users'],
        ['classes', 'classes.php', 'ชั้นเรียน', 'building'],
        ['subjects', 'subjects.php', 'รายวิชา', 'book'],
    ],
    'ระบบ' => array_values(array_filter([
        $isAdmin ? ['users', 'users.php', 'ผู้ใช้งาน', 'shield'] : null,
        $isAdmin ? ['settings', 'settings.php', 'ตั้งค่าระบบ', 'settings'] : null,
    ])),
];
?>
<!DOCTYPE html>
<html lang="th">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="theme-color" content="#4f46e5">
<title><?= e($pageTitle) ?> · <?= e(APP_TITLE) ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Itim&family=Sarabun:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,400;1,700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= url('assets/css/app.css') ?>?v=<?= APP_VERSION ?>">
</head>
<body class="app-body <?= e($pageClass) ?>">
<div class="page-progress" id="pageProgress"></div>
<div class="bg-aurora" aria-hidden="true"><span class="aurora a1"></span><span class="aurora a2"></span><span class="aurora a3"></span></div>

<div class="app-shell">
  <aside class="sidebar" id="sidebar">
    <a class="brand" href="<?= url('dashboard.php') ?>">
      <span class="brand-logo"><?= school_logo_svg(46) ?></span>
      <span class="brand-text">
        <strong>SMS School</strong>
        <small><?= e($school['name']) ?></small>
      </span>
      <button type="button" class="sidebar-close icon-btn" id="sidebarClose" aria-label="ปิดเมนู"><?= icon('x', 18) ?></button>
    </a>

    <div class="school-chip">
      <span class="live-dot"></span>
      <div>
        <small>ปีการศึกษาปัจจุบัน</small>
        <strong>ปี <?= e(academic_year()) ?> · ภาคเรียนที่ <?= academic_semester() ?></strong>
      </div>
    </div>

    <nav class="nav" aria-label="เมนูหลัก">
      <?php foreach ($navItems as $group => $items): ?>
        <?php if (!$items) continue; ?>
        <div class="nav-label"><?= e($group) ?></div>
        <?php foreach ($items as $item): ?>
          <?php [$key, $href, $label, $ico] = $item; $badge = $item[4] ?? ''; ?>
          <a class="nav-link <?= $activeNav === $key ? 'is-active' : '' ?>" href="<?= url($href) ?>">
            <span class="nav-ico"><?= icon($ico, 19) ?></span>
            <span class="nav-text"><?= e($label) ?></span>
            <?php if ($badge !== ''): ?><span class="nav-badge"><?= e($badge) ?></span><?php endif; ?>
          </a>
        <?php endforeach; ?>
      <?php endforeach; ?>
    </nav>

    <div class="sidebar-footer">
      <div class="sidebar-user">
        <span class="avatar <?= avatar_class($user['fullname']) ?>"><?= e(fullname_initials($user['fullname'])) ?></span>
        <div>
          <strong><?= e($user['fullname']) ?></strong>
          <small><?= e(role_label($user['role'])) ?></small>
        </div>
      </div>
      <a class="sidebar-logout" href="<?= url('logout.php') ?>"><?= icon('logout', 18) ?><span>ออกจากระบบ</span></a>
    </div>
  </aside>

  <div class="sidebar-overlay" id="sidebarOverlay"></div>

  <div class="app-main">
    <header class="topbar">
      <button type="button" class="icon-btn topbar-toggle" id="sidebarToggle" aria-label="เปิดเมนู"><?= icon('menu', 21) ?></button>

      <div class="topbar-title">
        <h1><?= e($pageTitle) ?></h1>
        <p><?= e($pageSubtitle) ?></p>
      </div>

      <div class="topbar-actions">
        <span class="academic-chip"><span class="dot"></span>ปี <?= e(academic_year()) ?> · ภาค <?= academic_semester() ?></span>
        <?= $pageActions ?>
        <a class="btn btn-ghost btn-sm hide-md" href="<?= url('portal.php') ?>" target="_blank" rel="noopener">
          <?= icon('graduation', 17) ?><span>พอร์ทัลนักเรียน</span>
        </a>
        <a class="btn btn-primary btn-sm" href="<?= url('attendance.php') ?>">
          <?= icon('check', 17) ?><span>เช็คชื่อ</span>
        </a>

        <div class="user-menu" id="userMenu">
          <button type="button" class="user-trigger" id="userMenuToggle" aria-haspopup="true" aria-expanded="false">
            <span class="avatar sm <?= avatar_class($user['fullname']) ?>"><?= e(fullname_initials($user['fullname'])) ?></span>
            <span class="user-trigger-text">
              <strong><?= e($user['fullname']) ?></strong>
              <small><?= e(role_label($user['role'])) ?></small>
            </span>
            <?= icon('chevron-down', 15) ?>
          </button>
          <div class="user-dropdown" id="userDropdown">
            <div class="user-dropdown-head">
              <span class="avatar <?= avatar_class($user['fullname']) ?>"><?= e(fullname_initials($user['fullname'])) ?></span>
              <div><strong><?= e($user['fullname']) ?></strong><small><?= e($user['position'] ?: role_label($user['role'])) ?></small></div>
            </div>
            <a href="<?= url('portal.php') ?>" target="_blank" rel="noopener"><?= icon('graduation', 17) ?><span>เปิดพอร์ทัลนักเรียน</span></a>
            <?php if ($isAdmin): ?><a href="<?= url('settings.php') ?>"><?= icon('settings', 17) ?><span>ตั้งค่าระบบ</span></a><?php endif; ?>
            <a class="danger" href="<?= url('logout.php') ?>"><?= icon('logout', 17) ?><span>ออกจากระบบ</span></a>
          </div>
        </div>
      </div>
    </header>

    <main class="page <?= e($pageClass) ?>" id="page">
