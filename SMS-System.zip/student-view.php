<?php

require_once __DIR__ . '/includes/bootstrap.php';

require_staff();
$pdo = db();

$id = get_int('id');
$stmt = $pdo->prepare("SELECT s.*, c.name AS class_name, c.level, c.level_short, c.homeroom
    FROM students s LEFT JOIN classes c ON c.id = s.class_id WHERE s.id = ?");
$stmt->execute([$id]);
$student = $stmt->fetch();

if (!$student) {
    flash('danger', 'ไม่พบข้อมูลนักเรียน');
    redirect('students.php');
}

$statuses = student_status_meta();
$statusMeta = $statuses[$student['status']] ?? $statuses['studying'];

$counts = ['present' => 0, 'late' => 0, 'sick' => 0, 'business' => 0, 'absent' => 0, 'truant' => 0];
$stmt = $pdo->prepare('SELECT status, COUNT(*) AS total FROM attendance WHERE student_id = ? GROUP BY status');
$stmt->execute([$id]);
foreach ($stmt->fetchAll() as $row) {
    $counts[$row['status']] = (int) $row['total'];
}
$attendanceTotal = array_sum($counts);
$attendanceRate = attendance_rate($counts);
$missDays = $counts['absent'] + $counts['truant'];

$year = academic_year();
$semester = academic_semester();
$stmt = $pdo->prepare('SELECT g.*, sub.code, sub.name, sub.category, sub.hours, sub.credits
    FROM grades g JOIN subjects sub ON sub.id = g.subject_id
    WHERE g.student_id = ? AND g.academic_year = ? AND g.semester = ?
    ORDER BY sub.code');
$stmt->execute([$id, $year, $semester]);
$grades = $stmt->fetchAll();
$gpa = gpa_from_grades(array_column($grades, 'grade'));
$scoreValues = array_values(array_filter(array_column($grades, 'score'), fn($v) => $v !== null && $v !== ''));
$averageScore = $scoreValues ? array_sum($scoreValues) / count($scoreValues) : 0;
$totalCredits = array_sum(array_map(fn($g) => (float) $g['credits'], $grades));
$passedSubjects = count(array_filter($grades, fn($g) => is_numeric($g['grade']) && (float) $g['grade'] >= 1));

$stmt = $pdo->prepare('SELECT * FROM attendance WHERE student_id = ? ORDER BY att_date DESC LIMIT 45');
$stmt->execute([$id]);
$attendanceRows = $stmt->fetchAll();

$stmt = $pdo->prepare("SELECT d.* FROM documents d WHERE d.student_id = ? ORDER BY d.issued_at DESC");
$stmt->execute([$id]);
$documents = $stmt->fetchAll();

$attMeta = attendance_meta();
$pageTitle = 'โปรไฟล์นักเรียน';
$pageSubtitle = 'ข้อมูลส่วนตัว เวลาเรียน ผลการเรียน และเอกสาร';
$activeNav = 'students';
$pageActions = '<a class="btn btn-ghost btn-sm" href="' . url('students.php') . '">' . icon('arrow-left', 16) . '<span>กลับทะเบียน</span></a>';
if (can_manage()) {
    $pageActions .= '<a class="btn btn-primary btn-sm" href="' . url('student-form.php?id=' . $id) . '">' . icon('edit', 16) . '<span>แก้ไขข้อมูล</span></a>';
}

require_once __DIR__ . '/includes/header.php';
?>

<section class="card" style="overflow:hidden">
  <div style="height:88px;background:radial-gradient(400px 160px at 85% 0,rgba(255,255,255,.35),transparent 60%),linear-gradient(120deg,#312e81,#4f46e5 50%,#9333ea);position:relative">
    <span class="hero-orb o1" style="right:8%;top:-90px"></span>
    <span class="hero-orb o2" style="right:26%;top:20px"></span>
  </div>
  <div class="card-body" style="margin-top:-46px">
    <div class="profile-hero">
      <span class="avatar xl <?= avatar_class($student['firstname']) ?>" style="border:4px solid #fff;box-shadow:0 14px 30px rgba(30,27,75,.18)"><?= e(name_initials($student['firstname'], $student['lastname'])) ?></span>
      <div>
        <div class="row wrap" style="gap:8px">
          <h2><?= e(student_name($student)) ?></h2>
          <span class="badge badge-<?= e($statusMeta['class']) ?>"><span class="dot"></span><?= e($statusMeta['label']) ?></span>
        </div>
        <p><?= icon('building', 14) ?> <?= e($student['class_name'] ?: 'ยังไม่ระบุชั้นเรียน') ?> · <?= icon('graduation', 14) ?> รหัส <?= e($student['student_code']) ?> · เลขที่ <?= (int) $student['student_number'] ?></p>
      </div>
      <div class="profile-stats">
        <div class="profile-stat"><b class="num" style="color:#059669"><?= number_format($attendanceRate, 1) ?>%</b><span>อัตรามาเรียน</span></div>
        <div class="profile-stat"><b class="num" style="color:#4f46e5"><?= number_format($gpa, 2) ?></b><span>GPA ภาคนี้</span></div>
        <div class="profile-stat"><b class="num" style="color:#e11d48"><?= number_format($missDays) ?></b><span>วันขาด</span></div>
        <div class="profile-stat"><b class="num" style="color:#7c3aed"><?= number_format(count($documents)) ?></b><span>เอกสาร</span></div>
      </div>
    </div>
  </div>
</section>

<div class="tabs mt-2" data-tab-group role="tablist">
  <button class="tab is-active" data-tab="overview" role="tab" aria-selected="true"><?= icon('user', 15) ?> ภาพรวม</button>
  <button class="tab" data-tab="attendance" role="tab" aria-selected="false"><?= icon('check', 15) ?> เวลาเรียน</button>
  <button class="tab" data-tab="grades" role="tab" aria-selected="false"><?= icon('chart', 15) ?> ผลการเรียน</button>
  <button class="tab" data-tab="documents" role="tab" aria-selected="false"><?= icon('file', 15) ?> เอกสาร</button>
</div>

<div class="tab-panel is-active" data-tab-panel="overview">
  <div class="grid grid-2">
    <section class="card">
      <div class="card-head bordered"><div><h3 class="card-title"><?= icon('clipboard', 19) ?> ข้อมูลส่วนตัว</h3><p class="card-sub">ทะเบียนราษฎรและข้อมูลพื้นฐาน</p></div></div>
      <div class="card-body">
        <div class="info-grid">
          <div class="info-item"><span>รหัสนักเรียน</span><b><?= e($student['student_code']) ?></b></div>
          <div class="info-item"><span>ชั้นเรียน</span><b><?= e($student['class_name'] ?: '—') ?></b></div>
          <div class="info-item"><span>เลขบัตรประชาชน</span><b><?= e($student['citizen_id'] ?: '—') ?></b></div>
          <div class="info-item"><span>วันเกิด</span><b><?= e(thai_date($student['birth_date'])) ?></b></div>
          <div class="info-item"><span>สถานที่เกิด</span><b><?= e($student['birth_place'] ?: '—') ?></b></div>
          <div class="info-item"><span>สัญชาติ / ศาสนา</span><b><?= e($student['nationality'] ?: '—') ?> / <?= e($student['religion'] ?: '—') ?></b></div>
          <div class="info-item"><span>กรุ๊ปเลือด</span><b><?= e($student['blood_type'] ?: '—') ?></b></div>
          <div class="info-item"><span>วันที่เข้าศึกษา</span><b><?= e(thai_date($student['admission_date'])) ?></b></div>
          <div class="info-item" style="grid-column:span 2"><span>ที่อยู่</span><b><?= e($student['address'] ?: '—') ?></b></div>
        </div>
      </div>
    </section>

    <div class="stack">
      <section class="card">
        <div class="card-head bordered"><div><h3 class="card-title"><?= icon('users', 19) ?> ผู้ปกครอง</h3><p class="card-sub">ข้อมูลการติดต่อ</p></div></div>
        <div class="card-body">
          <div class="info-grid">
            <div class="info-item"><span>ชื่อผู้ปกครอง</span><b><?= e($student['parent_name'] ?: '—') ?></b></div>
            <div class="info-item"><span>ความสัมพันธ์</span><b><?= e($student['parent_relation'] ?: '—') ?></b></div>
            <div class="info-item"><span>โทรศัพท์</span><b><?= e($student['parent_phone'] ?: '—') ?></b></div>
            <div class="info-item"><span>โทรศัพท์ฉุกเฉิน</span><b><?= e($student['guardian_phone'] ?: '—') ?></b></div>
          </div>
          <?php if ($student['homeroom']): ?>
            <div class="notice notice-info mt-2"><?= icon('info', 17) ?><span><b>ครูประจำชั้น:</b> <?= e($student['homeroom']) ?></span></div>
          <?php endif; ?>
        </div>
      </section>

      <section class="card">
        <div class="card-head"><div><h3 class="card-title"><?= icon('check', 19) ?> สรุปเวลาเรียน</h3><p class="card-sub">จากระเบียนทั้งหมด <?= number_format($attendanceTotal) ?> ครั้ง</p></div></div>
        <div class="card-body">
          <div class="legend">
            <?php foreach ($attMeta as $key => $meta): ?>
              <?php $color = ['present' => '#10b981', 'late' => '#f59e0b', 'sick' => '#3b82f6', 'business' => '#8b5cf6', 'absent' => '#ef4444', 'truant' => '#be123c'][$key]; ?>
              <div class="legend-item"><span class="swatch" style="background:<?= $color ?>"></span><?= e($meta['label']) ?><b><?= number_format($counts[$key]) ?></b></div>
            <?php endforeach; ?>
          </div>
        </div>
      </section>
    </div>
  </div>
</div>

<div class="tab-panel" data-tab-panel="attendance">
  <div class="grid grid-2-1">
    <section class="card">
      <div class="card-head bordered"><div><h3 class="card-title"><?= icon('calendar', 19) ?> ประวัติการเช็คชื่อ</h3><p class="card-sub"><?= number_format(count($attendanceRows)) ?> รายการล่าสุด</p></div></div>
      <div class="table-wrap" style="border:0;box-shadow:none;border-radius:0">
        <table class="table">
          <thead><tr><th>วันที่</th><th>วัน</th><th>สถานะ</th><th>หมายเหตุ</th></tr></thead>
          <tbody>
          <?php foreach ($attendanceRows as $row): ?>
            <?php $meta = $attMeta[$row['status']] ?? $attMeta['present']; ?>
            <tr>
              <td class="num"><?= e(thai_date($row['att_date'])) ?></td>
              <td class="text-sm text-muted"><?= e(THAI_DAYS[(int) date('w', strtotime($row['att_date']))]) ?></td>
              <td><span class="status-pill st-<?= e($meta['class']) ?>"><span class="dot"></span><?= e($meta['label']) ?></span></td>
              <td class="text-sm text-muted"><?= e($row['note'] ?: '—') ?></td>
            </tr>
          <?php endforeach; ?>
          <?php if (!$attendanceRows): ?><tr><td colspan="4"><div class="empty-state"><p>ยังไม่มีข้อมูลการเช็คชื่อ</p></div></td></tr><?php endif; ?>
          </tbody>
        </table>
      </div>
    </section>

    <section class="card">
      <div class="card-head"><div><h3 class="card-title"><?= icon('chart', 19) ?> สรุปภาพรวม</h3><p class="card-sub">อัตรามาเรียนสะสม</p></div></div>
      <div class="card-body">
        <div class="donut-wrap" style="margin:0 auto 18px">
          <svg class="donut-svg" viewBox="0 0 120 120" aria-hidden="true">
            <defs><linearGradient id="studentDonut" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#34d399"/><stop offset="1" stop-color="#0d9488"/></linearGradient></defs>
            <circle class="donut-track" cx="60" cy="60" r="48"/>
            <circle class="donut-value" cx="60" cy="60" r="48" stroke="url(#studentDonut)" data-donut="<?= round($attendanceRate, 1) ?>"/>
          </svg>
          <div class="donut-center"><b><?= number_format($attendanceRate, 1) ?><span style="font-size:1rem">%</span></b><span>มาเรียน</span></div>
        </div>
        <div class="legend">
          <div class="legend-item"><span class="swatch" style="background:#10b981"></span>มา + สาย<b><?= number_format($counts['present'] + $counts['late']) ?></b></div>
          <div class="legend-item"><span class="swatch" style="background:#3b82f6"></span>ลา<b><?= number_format($counts['sick'] + $counts['business']) ?></b></div>
          <div class="legend-item"><span class="swatch" style="background:#ef4444"></span>ขาด / หนี<b><?= number_format($missDays) ?></b></div>
        </div>
        <?php if ($missDays > 0): ?>
          <div class="notice notice-warning mt-2"><?= icon('alert', 17) ?><span>นักเรียนขาดเรียน <?= number_format($missDays) ?> ครั้ง ควรติดตามและประสานผู้ปกครอง</span></div>
        <?php endif; ?>
      </div>
    </section>
  </div>
</div>

<div class="tab-panel" data-tab-panel="grades">
  <div class="gb-summary">
    <div class="gb-stat"><b style="color:#4f46e5"><?= number_format($gpa, 2) ?></b><span>เกรดเฉลี่ย (GPA)</span></div>
    <div class="gb-stat"><b><?= number_format($averageScore, 1) ?></b><span>คะแนนเฉลี่ย</span></div>
    <div class="gb-stat"><b><?= number_format($totalCredits, 1) ?></b><span>หน่วยกิตรวม</span></div>
    <div class="gb-stat"><b style="color:#059669"><?= $passedSubjects ?>/<?= count($grades) ?></b><span>รายวิชาที่ผ่าน</span></div>
  </div>

  <section class="card">
    <div class="card-head bordered">
      <div><h3 class="card-title"><?= icon('book', 19) ?> ผลการเรียน ปี <?= e($year) ?> ภาคเรียนที่ <?= e($semester) ?></h3><p class="card-sub">คะแนนและเกรดรายวิชา</p></div>
    </div>
    <div class="table-wrap" style="border:0;box-shadow:none;border-radius:0">
      <table class="table">
        <thead><tr><th>รหัส</th><th>รายวิชา</th><th>ประเภท</th><th class="text-right">ชั่วโมง</th><th class="text-right">หน่วยกิต</th><th class="text-right">คะแนน</th><th class="text-center">เกรด</th></tr></thead>
        <tbody>
        <?php foreach ($grades as $grade): ?>
          <tr>
            <td><span class="doc-no"><?= e($grade['code']) ?></span></td>
            <td><b style="font-weight:600"><?= e($grade['name']) ?></b></td>
            <td><span class="badge badge-muted"><?= e($grade['category']) ?></span></td>
            <td class="text-right num"><?= (int) $grade['hours'] ?></td>
            <td class="text-right num"><?= number_format((float) $grade['credits'], 1) ?></td>
            <td class="text-right num"><b><?= $grade['score'] !== null ? number_format((float) $grade['score'], 1) : '—' ?></b></td>
            <td class="text-center"><span class="grade-chip <?= grade_class($grade['grade']) ?>"><?= e($grade['grade'] ?: '—') ?></span></td>
          </tr>
        <?php endforeach; ?>
        <?php if (!$grades): ?><tr><td colspan="7"><div class="empty-state"><p>ยังไม่มีผลการเรียนในภาคเรียนนี้</p></div></td></tr><?php endif; ?>
        </tbody>
      </table>
    </div>
    <?php if (can_manage()): ?>
      <div class="card-footer"><a class="btn btn-soft btn-sm" href="<?= url('gradebook.php?class_id=' . (int) $student['class_id']) ?>"><?= icon('edit', 15) ?> ไปหน้าบันทึกผลการเรียน</a></div>
    <?php endif; ?>
  </section>
</div>

<div class="tab-panel" data-tab-panel="documents">
  <section class="card">
    <div class="card-head bordered"><div><h3 class="card-title"><?= icon('file', 19) ?> เอกสารทางการศึกษา</h3><p class="card-sub">เอกสาร ปพ. ที่ออกให้กับนักเรียนคนนี้</p></div></div>
    <div class="card-body">
      <div class="stack" style="gap:10px">
        <?php foreach ($documents as $doc): ?>
          <?php $type = doc_type($doc['doc_type']); ?>
          <div class="row wrap" style="padding:12px 14px;border:1px solid var(--line);border-radius:13px;background:#fcfdff">
            <span class="avatar sm <?= avatar_class($type['label']) ?>" style="border-radius:10px;background:var(--brand-soft);color:var(--brand)"><?= icon($type['icon'], 17) ?></span>
            <div style="flex:1;min-width:160px">
              <b style="display:block;font-size:.86rem"><?= e($doc['title']) ?></b>
              <small class="text-muted text-xs"><?= e($doc['doc_no']) ?> · ออกเมื่อ <?= e(thai_date($doc['issued_at'])) ?> · โดย <?= e($doc['issued_by']) ?></small>
            </div>
            <a class="btn btn-soft btn-sm" href="<?= url('document-print.php?id=' . (int) $doc['id']) ?>" target="_blank" rel="noopener"><?= icon('printer', 15) ?> พิมพ์</a>
          </div>
        <?php endforeach; ?>
        <?php if (!$documents): ?><div class="empty-state"><div class="empty-ico"><?= icon('file', 28) ?></div><h3>ยังไม่มีเอกสาร</h3><p>สามารถออกเอกสาร ปพ. ได้จากศูนย์เอกสาร</p><a class="btn btn-primary btn-sm" href="<?= url('documents.php') ?>">ไปศูนย์เอกสาร</a></div><?php endif; ?>
      </div>
    </div>
  </section>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
