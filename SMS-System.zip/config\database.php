<?php

function db(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }

    $dsn = sprintf('mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4', DB_HOST, DB_PORT, DB_NAME);
    try {
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
        $pdo->exec("SET time_zone = '+07:00'");
    } catch (PDOException $e) {
        if (basename($_SERVER['SCRIPT_NAME'] ?? '') !== 'install.php') {
            http_response_code(500);
            $message = 'ยังไม่ได้ติดตั้งระบบ';
            $databaseName = e_local(DB_NAME);
            $detail = e_local($e->getMessage());
            echo <<<HTML
<!DOCTYPE html>
<html lang="th"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>ยังไม่ได้ติดตั้งระบบ</title>
<link href="https://fonts.googleapis.com/css2?family=Sarabun:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<style>
*{box-sizing:border-box}body{margin:0;min-height:100vh;display:grid;place-items:center;background:#eef1fb;font-family:'Sarabun',sans-serif;color:#1e1b4b;padding:24px}
.card{max-width:560px;background:#fff;border-radius:24px;padding:36px;box-shadow:0 30px 80px rgba(49,46,129,.18);animation:pop .5s ease both}
@keyframes pop{from{opacity:0;transform:translateY(18px) scale(.97)}to{opacity:1;transform:none}}
.logo{width:64px;height:64px;border-radius:18px;background:linear-gradient(135deg,#6366f1,#8b5cf6,#ec4899);display:grid;place-items:center;color:#fff;font-size:28px;font-weight:800;margin-bottom:18px}
h1{margin:0 0 8px;font-size:1.5rem}p{line-height:1.7;color:#475569}
code{background:#f1f5f9;padding:2px 7px;border-radius:6px;color:#4338ca}
a.btn{display:inline-flex;margin-top:18px;background:linear-gradient(135deg,#4f46e5,#7c3aed);color:#fff;padding:12px 22px;border-radius:12px;text-decoration:none;font-weight:700;box-shadow:0 10px 22px rgba(79,70,229,.28)}
.detail{margin-top:16px;font-size:.8rem;color:#94a3b8;word-break:break-word}
</style></head><body>
<div class="card"><div class="logo">S</div><h1>{$message}</h1>
<p>ยังไม่ได้สร้างฐานข้อมูล <code>{$databaseName}</code> หรือยังไม่ได้นำเข้าไฟล์ SQL<br>เปิดหน้า <b>install.php</b> เพื่อติดตั้งระบบและข้อมูลตัวอย่างได้ในคลิกเดียว</p>
<a class="btn" href="install.php">ติดตั้งระบบ</a>
<div class="detail">ตรวจสอบว่า MySQL ใน XAMPP เปิดอยู่ และค่าเชื่อมต่อใน config/config.php ถูกต้อง</div></div>
</body></html>
HTML;
            exit;
        }
        throw $e;
    }

    return $pdo;
}

function e_local(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}
