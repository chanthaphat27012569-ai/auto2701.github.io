<?php

require_once __DIR__ . '/../config/config.php';

$hash = '$2y$10$d6UVEzofUj.JgTWX66s/oeCzTYykHuYQ7UrMJVrZUykdi9LfS9bjC'; // 1234

function q($value): string
{
    if ($value === null) {
        return 'NULL';
    }
    return "'" . str_replace(["\\", "'"], ["\\\\", "\\'"], (string) $value) . "'";
}

function insert_rows(string $table, array $columns, array $rows): string
{
    if (!$rows) {
        return '';
    }
    $chunks = array_chunk($rows, 100);
    $out = '';
    foreach ($chunks as $chunk) {
        $out .= 'INSERT INTO `' . $table . '` (`' . implode('`,`', $columns) . '`) VALUES' . "\n";
        $lines = [];
        foreach ($chunk as $row) {
            $lines[] = '(' . implode(', ', array_map('q', $row)) . ')';
        }
        $out .= implode(",\n", $lines) . ";\n\n";
    }
    return $out;
}

$sql = "-- ============================================================\n";
$sql .= "-- SMS School · ระบบบริหารจัดการสถานศึกษา (PHP + MySQL)\n";
$sql .= "-- Database schema + demo data · generated " . date('Y-m-d H:i') . "\n";
$sql .= "-- Demo accounts: admin / 1234 · teacher.sunee / 1234\n";
$sql .= "-- Student portal: 1001 / 1001\n";
$sql .= "-- ============================================================\n\n";
$sql .= "SET NAMES utf8mb4;\nSET time_zone = '+07:00';\n";
$sql .= "CREATE DATABASE IF NOT EXISTS `" . DB_NAME . "` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;\n";
$sql .= "USE `" . DB_NAME . "`;\n\n";
$sql .= "SET FOREIGN_KEY_CHECKS = 0;\n";
foreach (['documents', 'grades', 'attendance', 'students', 'subjects', 'classes', 'users', 'school_info'] as $table) {
    $sql .= "DROP TABLE IF EXISTS `$table`;\n";
}
$sql .= "SET FOREIGN_KEY_CHECKS = 1;\n\n";

$sql .= <<<'SCHEMA'
CREATE TABLE `school_info` (
  `id` TINYINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(190) NOT NULL,
  `name_en` VARCHAR(190) NOT NULL DEFAULT '',
  `affiliation` VARCHAR(190) NOT NULL DEFAULT '',
  `area_office` VARCHAR(190) NOT NULL DEFAULT '',
  `address` VARCHAR(255) NOT NULL DEFAULT '',
  `phone` VARCHAR(50) NOT NULL DEFAULT '',
  `email` VARCHAR(120) NOT NULL DEFAULT '',
  `website` VARCHAR(120) NOT NULL DEFAULT '',
  `director` VARCHAR(120) NOT NULL DEFAULT '',
  `academic_year` VARCHAR(4) NOT NULL DEFAULT '2569',
  `semester` TINYINT NOT NULL DEFAULT 1,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `users` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(60) NOT NULL,
  `password_hash` VARCHAR(255) NOT NULL,
  `fullname` VARCHAR(150) NOT NULL,
  `role` ENUM('admin','director','deputy','registrar','teacher','staff') NOT NULL DEFAULT 'teacher',
  `position` VARCHAR(120) NOT NULL DEFAULT '',
  `department` VARCHAR(120) NOT NULL DEFAULT '',
  `phone` VARCHAR(30) NOT NULL DEFAULT '',
  `email` VARCHAR(120) NOT NULL DEFAULT '',
  `status` ENUM('active','inactive') NOT NULL DEFAULT 'active',
  `last_login` DATETIME NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_users_username` (`username`),
  KEY `idx_users_role` (`role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `classes` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(30) NOT NULL,
  `level` VARCHAR(80) NOT NULL DEFAULT '',
  `level_short` VARCHAR(10) NOT NULL DEFAULT '',
  `room` VARCHAR(10) NOT NULL DEFAULT '',
  `homeroom` VARCHAR(190) NOT NULL DEFAULT '',
  `academic_year` VARCHAR(4) NOT NULL DEFAULT '2569',
  `status` ENUM('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_classes_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `subjects` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `code` VARCHAR(20) NOT NULL,
  `name` VARCHAR(120) NOT NULL,
  `category` VARCHAR(60) NOT NULL DEFAULT '',
  `department` VARCHAR(80) NOT NULL DEFAULT '',
  `hours` SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  `credits` DECIMAL(3,1) NOT NULL DEFAULT 0.0,
  `status` ENUM('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_subjects_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `students` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `student_code` VARCHAR(20) NOT NULL,
  `prefix` VARCHAR(20) NOT NULL DEFAULT '',
  `firstname` VARCHAR(80) NOT NULL,
  `lastname` VARCHAR(80) NOT NULL,
  `gender` ENUM('male','female') NOT NULL DEFAULT 'male',
  `class_id` INT UNSIGNED NULL,
  `student_number` SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  `citizen_id` VARCHAR(20) NOT NULL DEFAULT '',
  `portal_pin` VARCHAR(10) NOT NULL DEFAULT '',
  `birth_date` DATE NULL,
  `birth_place` VARCHAR(100) NOT NULL DEFAULT '',
  `nationality` VARCHAR(50) NOT NULL DEFAULT 'ไทย',
  `religion` VARCHAR(50) NOT NULL DEFAULT '',
  `blood_type` VARCHAR(5) NOT NULL DEFAULT '',
  `address` VARCHAR(255) NOT NULL DEFAULT '',
  `parent_name` VARCHAR(120) NOT NULL DEFAULT '',
  `parent_relation` VARCHAR(30) NOT NULL DEFAULT '',
  `parent_phone` VARCHAR(30) NOT NULL DEFAULT '',
  `guardian_phone` VARCHAR(30) NOT NULL DEFAULT '',
  `status` ENUM('studying','graduated','transferred','inactive') NOT NULL DEFAULT 'studying',
  `admission_date` DATE NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_students_code` (`student_code`),
  KEY `idx_students_class` (`class_id`),
  KEY `idx_students_name` (`firstname`,`lastname`),
  CONSTRAINT `fk_students_class` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `attendance` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `student_id` INT UNSIGNED NOT NULL,
  `class_id` INT UNSIGNED NULL,
  `att_date` DATE NOT NULL,
  `status` ENUM('present','late','sick','business','absent','truant') NOT NULL DEFAULT 'present',
  `note` VARCHAR(255) NOT NULL DEFAULT '',
  `recorded_by` INT UNSIGNED NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_attendance_student_date` (`student_id`,`att_date`),
  KEY `idx_attendance_date` (`att_date`),
  KEY `idx_attendance_class_date` (`class_id`,`att_date`),
  CONSTRAINT `fk_attendance_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_attendance_class` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_attendance_user` FOREIGN KEY (`recorded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `grades` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `student_id` INT UNSIGNED NOT NULL,
  `subject_id` INT UNSIGNED NOT NULL,
  `academic_year` VARCHAR(4) NOT NULL,
  `semester` TINYINT UNSIGNED NOT NULL DEFAULT 1,
  `score` DECIMAL(5,2) NULL,
  `grade` VARCHAR(3) NOT NULL DEFAULT '',
  `updated_by` INT UNSIGNED NULL,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_grades` (`student_id`,`subject_id`,`academic_year`,`semester`),
  KEY `idx_grades_subject` (`subject_id`,`academic_year`,`semester`),
  CONSTRAINT `fk_grades_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_grades_subject` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_grades_user` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `documents` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `doc_no` VARCHAR(30) NOT NULL,
  `doc_type` VARCHAR(10) NOT NULL,
  `student_id` INT UNSIGNED NOT NULL,
  `title` VARCHAR(190) NOT NULL,
  `academic_year` VARCHAR(4) NOT NULL,
  `semester` TINYINT UNSIGNED NOT NULL DEFAULT 1,
  `issued_by` VARCHAR(120) NOT NULL DEFAULT '',
  `issued_by_id` INT UNSIGNED NULL,
  `issued_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `note` VARCHAR(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_documents_no` (`doc_no`),
  KEY `idx_documents_student` (`student_id`),
  KEY `idx_documents_type` (`doc_type`),
  CONSTRAINT `fk_documents_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_documents_user` FOREIGN KEY (`issued_by_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SCHEMA;

$sql .= insert_rows('school_info', [
    'id', 'name', 'name_en', 'affiliation', 'area_office', 'address', 'phone', 'email',
    'website', 'director', 'academic_year', 'semester',
], [[
    1,
    'โรงเรียนสาธิตวิทยาการ',
    'Satit Wittayakarn School',
    'สำนักงานคณะกรรมการการศึกษาขั้นพื้นฐาน',
    'สำนักงานเขตพื้นที่การศึกษามัธยมศึกษานนทบุรี',
    '99 หมู่ 5 ตำบลสาธิต อำเภอเมือง จังหวัดนนทบุรี 11000',
    '02-123-4567',
    'info@satitwittayakarn.ac.th',
    'www.satitwittayakarn.ac.th',
    'ดร.สมชาย วิทยานุภาพ',
    '2569',
    1,
]]);

$users = [
    ['admin', $hash, 'ดร.สมชาย วิทยานุภาพ', 'admin', 'ผู้อำนวยการสถานศึกษา', 'บริหารทั่วไป', '081-234-5678', 'director@school.ac.th'],
    ['academic', $hash, 'นางศิริพร บุญรักษา', 'deputy', 'รองผู้อำนวยการฝ่ายวิชาการ', 'วิชาการ', '081-234-5679', 'academic@school.ac.th'],
    ['registrar', $hash, 'นายชวลิต ปัญญาสิทธิ์', 'registrar', 'หัวหน้านายทะเบียน', 'วิชาการ/ทะเบียน', '081-234-5680', 'registrar@school.ac.th'],
    ['teacher.sunee', $hash, 'นางสุนีย์ ใจดี', 'teacher', 'ครูชำนาญการพิเศษ', 'ภาษาไทย', '082-345-6701', 'sunee@school.ac.th'],
    ['teacher.warakorn', $hash, 'ดร.วรากร อินทนนท์', 'teacher', 'ครูชำนาญการ', 'วิทยาศาสตร์และเทคโนโลยี', '082-345-6702', 'warakorn@school.ac.th'],
    ['teacher.kanda', $hash, 'นางสาวกานดา เมตตา', 'teacher', 'ครู คศ.2', 'สังคมศึกษา ศาสนา และวัฒนธรรม', '082-345-6703', 'kanda@school.ac.th'],
    ['staff.affairs', $hash, 'นายปิยะ ดูแลดี', 'staff', 'เจ้าหน้าที่ฝ่ายกิจการนักเรียน', 'กิจการนักเรียน', '083-456-7801', 'affairs@school.ac.th'],
    ['teacher.deputy', $hash, 'นายกิตติศักดิ์ บริหารกิจ', 'deputy', 'รองผู้อำนวยการสถานศึกษา (ปฏิบัติหน้าที่สอน)', 'คณิตศาสตร์', '082-999-1234', 'kittisak@school.ac.th'],
];

$sql .= insert_rows('users', [
    'username', 'password_hash', 'fullname', 'role', 'position', 'department', 'phone', 'email',
], $users);

$classDefs = [
    ['ม.1/1', 'ชั้นมัธยมศึกษาปีที่ 1', 'ม.1', '1', 'นางสาวศศิธร วาดสวย, นางพิมลวรรณ สุขเกษม'],
    ['ม.1/2', 'ชั้นมัธยมศึกษาปีที่ 1', 'ม.1', '2', 'นางสาวกานดา เมตตา'],
    ['ม.2/1', 'ชั้นมัธยมศึกษาปีที่ 2', 'ม.2', '1', 'นางสุนีย์ ใจดี'],
    ['ม.2/2', 'ชั้นมัธยมศึกษาปีที่ 2', 'ม.2', '2', 'Mr. John Smith'],
    ['ม.3/1', 'ชั้นมัธยมศึกษาปีที่ 3', 'ม.3', '1', 'นางสุนีย์ ใจดี, นางสาวกานดา เมตตา'],
    ['ม.3/2', 'ชั้นมัธยมศึกษาปีที่ 3', 'ม.3', '2', 'ดร.วรากร อินทนนท์'],
];

$sql .= insert_rows('classes', [
    'name', 'level', 'level_short', 'room', 'homeroom', 'academic_year', 'status',
], array_map(fn($c) => [$c[0], $c[1], $c[2], $c[3], $c[4], '2569', 'active'], $classDefs));

$subjects = [
    ['ท23101', 'ภาษาไทย', 'วิชาพื้นฐาน', 'ภาษาไทย', 60, 1.5],
    ['ค23101', 'คณิตศาสตร์', 'วิชาพื้นฐาน', 'คณิตศาสตร์', 60, 1.5],
    ['ว23101', 'วิทยาศาสตร์และเทคโนโลยี', 'วิชาพื้นฐาน', 'วิทยาศาสตร์และเทคโนโลยี', 60, 1.5],
    ['ส23101', 'สังคมศึกษา ศาสนา และวัฒนธรรม', 'วิชาพื้นฐาน', 'สังคมศึกษา ศาสนา และวัฒนธรรม', 40, 1.0],
    ['อ23101', 'ภาษาอังกฤษ', 'วิชาพื้นฐาน', 'ภาษาต่างประเทศ', 40, 1.0],
    ['พ23101', 'สุขศึกษาและพลศึกษา', 'วิชาพื้นฐาน', 'สุขศึกษาและพลศึกษา', 20, 0.5],
    ['ศ23101', 'ศิลปะ', 'วิชาพื้นฐาน', 'ศิลปะ', 20, 0.5],
    ['ก23101', 'การงานอาชีพ', 'วิชาพื้นฐาน', 'การงานอาชีพ', 20, 0.5],
    ['ว23205', 'วิทยาการคำนวณและปัญญาประดิษฐ์', 'วิชาเพิ่มเติม', 'วิทยาศาสตร์และเทคโนโลยี', 40, 1.0],
    ['ก23901', 'กิจกรรมพัฒนาผู้เรียน (ลูกเสือ-เนตรนารี)', 'กิจกรรมพัฒนาผู้เรียน', 'กิจกรรมพัฒนาผู้เรียน', 20, 0.5],
];
$sql .= insert_rows('subjects', [
    'code', 'name', 'category', 'department', 'hours', 'credits', 'status',
], array_map(fn($s) => [$s[0], $s[1], $s[2], $s[3], $s[4], $s[5], 'active'], $subjects));

$maleNames = [
    ['ธนภัทร', 'สุขสวัสดิ์เจริญ'], ['กิตติพงศ์', 'พิพัฒนมงคล'], ['ชัชวาลย์', 'รุ่งเรือง'], ['พงศกร', 'รัตนผล'],
    ['จิรพัฒน์', 'ชูใจ'], ['ณัฐวุฒิ', 'เจริญพร'], ['ภูริช', 'ธนากูล'], ['ศุภกิตติ์', 'มั่นคง'],
    ['อภิสิทธิ์', 'ทองคำ'], ['ธีรเดช', 'ศรีสุข'], ['รชต', 'วงศ์วิวัฒน์'], ['ปภาวิน', 'บุญมา'],
    ['กันต์กวี', 'อินทรีย์'], ['วรเมธ', 'แสงทอง'], ['ณเดชน์', 'ภูมิใจ'], ['สุรชัย', 'เพชรรัตน์'],
    ['นภดล', 'ไพโรจน์'], ['ตะวัน', 'อรุณรัตน์'], ['ปัณณวิชญ์', 'โชติช่วง'], ['กฤตเมธ', 'วัฒนศิลป์'],
    ['พีระพงษ์', 'จันทร์เพ็ญ'], ['ชนาธิป', 'เลิศไกร'], ['ศิวกร', 'ธารทอง'], ['เมธัส', 'รักเรียน'],
];
$femaleNames = [
    ['พิมพ์มาดา', 'อัครเดโชชัย'], ['อรวรรณ', 'โชคดี'], ['นภัสสร', 'อ่อนหวาน'], ['ณัฐธิดา', 'ศรีวิไล'],
    ['ชลธิชา', 'มั่นคง'], ['ปิยะดา', 'แสงจันทร์'], ['สุพิชญา', 'บุญมี'], ['กมลชนก', 'ทองแท้'],
    ['อารยา', 'พูลสวัสดิ์'], ['ธัญชนก', 'รุ่งโรจน์'], ['ภัณฑิรา', 'จันทร์ฉาย'], ['ศิริกัญญา', 'พรหมมา'],
    ['วรินทร', 'ดวงแก้ว'], ['ณิชกานต์', 'อินทร์ทอง'], ['พิมพ์ชนก', 'ศรีสมบัติ'], ['ชุติมา', 'ยอดเยี่ยม'],
    ['เบญจวรรณ', 'พงษ์พันธ์'], ['กัลยรัตน์', 'สุขใจ'], ['ฐิติพร', 'เกิดผล'], ['มณีรัตน์', 'รุ่งเรือง'],
    ['วิภาดา', 'ธนบดี'], ['สุธาสินี', 'ใจดี'], ['แพรวา', 'บุญช่วย'], ['ณัฐริกา', 'เพ็ชรดี'],
];
$provinces = ['นนทบุรี', 'ปทุมธานี', 'กรุงเทพมหานคร', 'สมุทรปราการ'];
$studentRows = [];
$studentMeta = [];
for ($i = 0; $i < 48; $i++) {
    $classIndex = intdiv($i, 8);
    $class = $classDefs[$classIndex];
    $levelDigit = (int) preg_replace('/\D/', '', $class[2]);
    $isMale = ($i % 8) % 2 === 0;
    $source = $isMale ? $maleNames : $femaleNames;
    $name = $source[(intdiv($i, 2) + $i) % count($source)];
    $surname = $name[1];
    $code = (string) (1001 + $i);
    $birthYear = 2557 - $levelDigit - 543;
    $birthMonth = ($i * 3) % 12 + 1;
    $birthDay = ($i * 7) % 28 + 1;
    $province = $provinces[$i % 4];
    $prefix = $isMale ? ($levelDigit === 3 && $i % 15 === 0 ? 'นาย' : 'เด็กชาย') : 'เด็กหญิง';
    $prefix = $isMale ? 'เด็กชาย' : 'เด็กหญิง';
    $citizen = '1' . '1000' . str_pad((string) (10000 + $i), 5, '0', STR_PAD_LEFT) . str_pad((string) (100 + $i), 3, '0', STR_PAD_LEFT);
    $parentName = ($isMale ? 'นาย' : 'นาง') . $maleNames[($i + 7) % count($maleNames)][0] . ' ' . $surname;
    $studentRows[] = [
        $code, $prefix, $name[0], $surname, $isMale ? 'male' : 'female',
        $classIndex + 1, ($i % 8) + 1, $citizen, $code,
        sprintf('%04d-%02d-%02d', $birthYear, $birthMonth, $birthDay),
        $province, 'ไทย', $i % 7 === 0 ? 'อิสลาม' : 'พุทธ',
        ['A', 'B', 'O', 'AB'][$i % 4],
        (10 + $i) . ' หมู่ ' . (($i % 8) + 1) . ' ตำบลสาธิต อำเภอเมือง จังหวัด' . $province . ' 11000',
        $parentName, $i % 3 === 0 ? 'มารดา' : 'บิดา',
        sprintf('08%d-%03d-%04d', $i % 10, 100 + $i, 2000 + $i),
        sprintf('09%d-%03d-%04d', $i % 10, 300 + $i, 4000 + $i),
        'studying',
        '2026-05-16',
    ];
    $studentMeta[] = [
        'id' => $i + 1,
        'code' => $code,
        'class_id' => $classIndex + 1,
        'class_name' => $class[0],
        'level' => $levelDigit,
    ];
}
$sql .= insert_rows('students', [
    'student_code', 'prefix', 'firstname', 'lastname', 'gender', 'class_id', 'student_number',
    'citizen_id', 'portal_pin', 'birth_date', 'birth_place', 'nationality', 'religion',
    'blood_type', 'address', 'parent_name', 'parent_relation', 'parent_phone', 'guardian_phone',
    'status', 'admission_date',
], $studentRows);

$holidays = ['2026-07-28', '2026-08-12', '2026-10-13', '2026-10-23'];
$schoolDays = [];
$cursor = new DateTime('2026-09-01');
$end = new DateTime('2026-11-05');
while ($cursor <= $end) {
    $dow = (int) $cursor->format('N');
    $iso = $cursor->format('Y-m-d');
    if ($dow < 6 && !in_array($iso, $holidays, true)) {
        $schoolDays[] = $iso;
    }
    $cursor->modify('+1 day');
}

$attendanceRows = [];
$statuses = ['present', 'late', 'sick', 'business', 'absent', 'truant'];
foreach ($schoolDays as $date) {
    foreach ($studentMeta as $student) {
        $r = abs(crc32($date . ':' . $student['code'])) % 1000;
        if ($r < 865) $status = 'present';
        elseif ($r < 930) $status = 'late';
        elseif ($r < 963) $status = 'sick';
        elseif ($r < 981) $status = 'business';
        elseif ($r < 995) $status = 'absent';
        else $status = 'truant';
        $attendanceRows[] = [$student['id'], $student['class_id'], $date, $status, '', 1];
    }
}
$sql .= insert_rows('attendance', [
    'student_id', 'class_id', 'att_date', 'status', 'note', 'recorded_by',
], $attendanceRows);

$gradeRows = [];
foreach ($studentMeta as $student) {
    foreach ($subjects as $sIndex => $subject) {
        $base = 48 + (($student['id'] * 17 + $sIndex * 9 + 7) % 49);
        $score = max(44, min(96, $base));
        $grade = $score >= 80 ? '4.0' : ($score >= 75 ? '3.5' : ($score >= 70 ? '3.0' : ($score >= 65 ? '2.5' : ($score >= 60 ? '2.0' : ($score >= 55 ? '1.5' : ($score >= 50 ? '1.0' : '0.0'))))));
        $gradeRows[] = [$student['id'], $sIndex + 1, '2569', 1, $score, $grade, 1];
    }
}
$sql .= insert_rows('grades', [
    'student_id', 'subject_id', 'academic_year', 'semester', 'score', 'grade', 'updated_by',
], $gradeRows);

$documents = [
    ['PP7-2569-0001', 'pp7', 1, 'ปพ.7 ใบรับรองผลการศึกษา', '2569', 1, 'ดร.สมชาย วิทยานุภาพ', 1, '2026-11-03 09:30:00', 'ใช้ประกอบการสมัครเรียนต่อ'],
    ['PP6-2569-0001', 'pp6', 2, 'ปพ.6 สมุดรายงานประจำตัวนักเรียน', '2569', 1, 'นายชวลิต ปัญญาสิทธิ์', 3, '2026-11-04 13:15:00', ''],
    ['PP4-2569-0001', 'pp4', 9, 'ปพ.4 หนังสือรับรองการเป็นนักเรียน', '2569', 1, 'นายชวลิต ปัญญาสิทธิ์', 3, '2026-11-05 08:45:00', 'ใช้ยืนยันสิทธิ์นักเรียน'],
];
$sql .= insert_rows('documents', [
    'doc_no', 'doc_type', 'student_id', 'title', 'academic_year', 'semester', 'issued_by', 'issued_by_id', 'issued_at', 'note',
], $documents);

file_put_contents(__DIR__ . '/../database/database.sql', $sql);
echo "database.sql generated: " . number_format(strlen($sql)) . " bytes\n";
echo "School days: " . count($schoolDays) . ", attendance rows: " . count($attendanceRows) . ", grades: " . count($gradeRows) . "\n";
