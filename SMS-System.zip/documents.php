<?php

require_once __DIR__ . '/includes/bootstrap.php';

$user = require_staff();
$pdo = db();
$docTypes = doc_types();

$errors = [];
$form = [
    'student_id' => get_int('student_id'),
    'doc_type' => 'pp7',
    'academic_year' => academic_year(),
    'semester' => academic_semester(),
    'note' => '',
];
$showForm = get_str('new') === '1' || get_int('student_id') > 0;

$batchErrors = [];
$batchForm = [
    'class_id' => get_int('batch_class'),
    'doc_type' => 'pp7',
    'academic_year' => academic_year(),
    'semester' => academic_semester(),
    'note' => '',
    'reuse' => true,
];
$showBatchForm = get_str('batch') === '1';

if (is_post()) {
    verify_csrf();
    $action = post_str('action');

    if ($action === 'delete') {
        require_manage();
        $deleteId = (int) ($_POST['document_id'] ?? 0);
        $stmt = $pdo->prepare('SELECT doc_no FROM documents WHERE id = ?');
        $stmt->execute([$deleteId]);
        $existing = $stmt->fetch();
        if ($existing) {
            $del = $pdo->prepare('DELETE FROM documents WHERE id = ?');
            $del->execute([$deleteId]);
            flash('success', 'ลบเอกสารเลขที่ ' . $existing['doc_no'] . ' เรียบร้อยแล้ว');
        } else {
            flash('danger', 'ไม่พบเอกสารที่ต้องการลบ');
        }
        redirect('documents.php');
    }

    if ($action === 'issue') {
        $form['student_id'] = (int) ($_POST['student_id'] ?? 0);
        $form['doc_type'] = post_str('doc_type');
        $form['academic_year'] = post_str('academic_year');
        $form['semester'] = (int) ($_POST['semester'] ?? 0);
        $form['note'] = post_str('note');

        $stmt = $pdo->prepare("SELECT id, prefix, firstname, lastname, class_id FROM students WHERE id = ? AND status IN ('studying','graduated')");
        $stmt->execute([$form['student_id']]);
        $student = $stmt->fetch();

        if (!$student) {
            $errors['student_id'] = 'กรุณาเลือกนักเรียนที่ต้องการออกเอกสาร';
        }
        if (!isset($docTypes[$form['doc_type']])) {
            $errors['doc_type'] = 'กรุณาเลือกประเภทเอกสาร';
        }
        if (!preg_match('/^\d{4}$/', $form['academic_year'])) {
            $errors['academic_year'] = 'ปีการศึกษาต้องเป็นตัวเลข 4 หลัก';
        }
        if (!in_array($form['semester'], [1, 2], true)) {
            $errors['semester'] = 'กรุณาเลือกภาคเรียน';
        }

        if (!$errors) {
            $type = $docTypes[$form['doc_type']];
            $prefixCode = strtoupper($form['doc_type']);
            $pdo->beginTransaction();
            try {
                $seqStmt = $pdo->prepare("SELECT COALESCE(MAX(CAST(SUBSTRING_INDEX(doc_no, '-', -1) AS UNSIGNED)), 0)
                    FROM documents WHERE doc_type = ? AND academic_year = ?");
                $seqStmt->execute([$form['doc_type'], $form['academic_year']]);
                $seq = (int) $seqStmt->fetchColumn() + 1;
                $docNo = $prefixCode . '-' . $form['academic_year'] . '-' . str_pad((string) $seq, 4, '0', STR_PAD_LEFT);
                $title = $type['label'] . ' ' . $type['name'];
                $stmt = $pdo->prepare('INSERT INTO documents (doc_no, doc_type, student_id, title, academic_year, semester, issued_by, issued_by_id, issued_at, note)
                    VALUES (?,?,?,?,?,?,?,?,NOW(),?)');
                $stmt->execute([$docNo, $form['doc_type'], $form['student_id'], $title, $form['academic_year'], $form['semester'], $user['fullname'], (int) $user['id'], $form['note']]);
                $newId = (int) $pdo->lastInsertId();
                $pdo->commit();
                flash('success', 'ออกเอกสาร ' . $type['label'] . ' เลขที่ ' . $docNo . ' ให้ ' . student_name($student) . ' เรียบร้อยแล้ว');
                redirect('document-print.php?id=' . $newId);
            } catch (Throwable $e) {
                $pdo->rollBack();
                $errors['general'] = 'ไม่สามารถออกเอกสารได้ กรุณาลองใหม่อีกครั้ง';
                $showForm = true;
            }
        } else {
            $showForm = true;
        }
    }

    if ($action === 'issue_class') {
        $batchForm['class_id'] = (int) ($_POST['class_id'] ?? 0);
        $batchForm['doc_type'] = post_str('doc_type');
        $batchForm['academic_year'] = post_str('academic_year');
        $batchForm['semester'] = (int) ($_POST['semester'] ?? 0);
        $batchForm['note'] = post_str('note');
        $batchForm['reuse'] = isset($_POST['reuse']);

        $classStmt = $pdo->prepare('SELECT id, name FROM classes WHERE id = ? LIMIT 1');
        $classStmt->execute([$batchForm['class_id']]);
        $batchClass = $classStmt->fetch();

        if (!$batchClass) {
            $batchErrors['class_id'] = 'กรุณาเลือกชั้นเรียนที่ต้องการพิมพ์ทั้งห้อง';
        }
        if (!isset($docTypes[$batchForm['doc_type']])) {
            $batchErrors['doc_type'] = 'กรุณาเลือกประเภทเอกสาร';
        }
        if (!preg_match('/^\d{4}$/', $batchForm['academic_year'])) {
            $batchErrors['academic_year'] = 'ปีการศึกษาต้องเป็นตัวเลข 4 หลัก';
        }
        if (!in_array($batchForm['semester'], [1, 2], true)) {
            $batchErrors['semester'] = 'กรุณาเลือกภาคเรียน';
        }

        $classStudents = [];
        if (!$batchErrors) {
            $stuStmt = $pdo->prepare("SELECT id, prefix, firstname, lastname FROM students
                WHERE class_id = ? AND status IN ('studying','graduated')
                ORDER BY student_number, student_code");
            $stuStmt->execute([$batchForm['class_id']]);
            $classStudents = $stuStmt->fetchAll();
            if (!$classStudents) {
                $batchErrors['class_id'] = 'ไม่พบนักเรียนที่กำลังศึกษาหรือสำเร็จการศึกษาในชั้นเรียนนี้';
            }
        }

        if (!$batchErrors) {
            $type = $docTypes[$batchForm['doc_type']];
            $prefixCode = strtoupper($batchForm['doc_type']);
            $title = $type['label'] . ' ' . $type['name'];
            $ids = [];
            $created = 0;
            $reused = 0;

            $pdo->beginTransaction();
            try {
                $existingStmt = $pdo->prepare('SELECT id FROM documents
                    WHERE doc_type = ? AND student_id = ? AND academic_year = ? AND semester = ?
                    ORDER BY id DESC LIMIT 1');
                $seqStmt = $pdo->prepare("SELECT COALESCE(MAX(CAST(SUBSTRING_INDEX(doc_no, '-', -1) AS UNSIGNED)), 0)
                    FROM documents WHERE doc_type = ? AND academic_year = ?");
                $insertStmt = $pdo->prepare('INSERT INTO documents (doc_no, doc_type, student_id, title, academic_year, semester, issued_by, issued_by_id, issued_at, note)
                    VALUES (?,?,?,?,?,?,?,?,NOW(),?)');

                foreach ($classStudents as $student) {
                    $existingStmt->execute([$batchForm['doc_type'], (int) $student['id'], $batchForm['academic_year'], $batchForm['semester']]);
                    $existingId = (int) $existingStmt->fetchColumn();

                    if ($existingId > 0 && $batchForm['reuse']) {
                        $ids[] = $existingId;
                        $reused++;
                        continue;
                    }

                    $seqStmt->execute([$batchForm['doc_type'], $batchForm['academic_year']]);
                    $seq = (int) $seqStmt->fetchColumn() + 1;
                    $docNo = $prefixCode . '-' . $batchForm['academic_year'] . '-' . str_pad((string) $seq, 4, '0', STR_PAD_LEFT);
                    $insertStmt->execute([
                        $docNo,
                        $batchForm['doc_type'],
                        (int) $student['id'],
                        $title,
                        $batchForm['academic_year'],
                        $batchForm['semester'],
                        $user['fullname'],
                        (int) $user['id'],
                        $batchForm['note'],
                    ]);
                    $ids[] = (int) $pdo->lastInsertId();
                    $created++;
                }

                $pdo->commit();
            } catch (Throwable $e) {
                $pdo->rollBack();
                $batchErrors['general'] = 'ไม่สามารถสร้างชุดเอกสารได้ กรุณาลองใหม่อีกครั้ง';
                $showBatchForm = true;
            }

            if (!$batchErrors) {
                $_SESSION['doc_print_batch'] = [
                    'ids' => $ids,
                    'label' => $type['label'] . ' · ' . $batchClass['name'] . ' · ปี ' . $batchForm['academic_year'] . ' ภาค ' . $batchForm['semester'],
                    'class_name' => $batchClass['name'],
                    'doc_type' => $batchForm['doc_type'],
                    'created' => time(),
                ];
                flash('success', 'สร้างชุดเอกสาร ' . $type['label'] . ' ให้ ' . $batchClass['name'] . ' จำนวน ' . count($ids) . ' ฉบับ'
                    . ' (ออกใหม่ ' . $created . ($reused > 0 ? ' · ใช้เอกสารเดิม ' . $reused : '') . ') เรียบร้อยแล้ว');
                redirect('document-print-batch.php');
            }
        } else {
            $showBatchForm = true;
        }
    }
}

$q = get_str('q');
$typeFilter = get_str('type');
$classId = get_int('class_id');
$classes = $pdo->query("SELECT c.id, c.name,
        (SELECT COUNT(*) FROM students s WHERE s.class_id = c.id AND s.status IN ('studying','graduated')) AS students
    FROM classes c WHERE c.status = 'active' ORDER BY c.name")->fetchAll();

$where = [];
$params = [];
if ($q !== '') {
    $where[] = '(d.doc_no LIKE ? OR d.title LIKE ? OR CONCAT(s.firstname, " ", s.lastname) LIKE ? OR s.student_code LIKE ?)';
    $like = '%' . $q . '%';
    array_push($params, $like, $like, $like, $like);
}
if (isset($docTypes[$typeFilter])) {
    $where[] = 'd.doc_type = ?';
    $params[] = $typeFilter;
}
if ($classId > 0) {
    $where[] = 's.class_id = ?';
    $params[] = $classId;
}
$whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';
$stmt = $pdo->prepare("SELECT d.*, s.prefix, s.firstname, s.lastname, s.student_code, c.name AS class_name
    FROM documents d
    JOIN students s ON s.id = d.student_id
    LEFT JOIN classes c ON c.id = s.class_id
    $whereSql
    ORDER BY d.issued_at DESC, d.id DESC
    LIMIT 200");
$stmt->execute($params);
$documents = $stmt->fetchAll();

$stats = $pdo->query("SELECT COUNT(*) AS total,
    SUM(DATE_FORMAT(issued_at, '%Y-%m') = DATE_FORMAT(NOW(), '%Y-%m')) AS this_month
    FROM documents")->fetch();

$studentsStmt = $pdo->query("SELECT s.id, s.student_code, s.prefix, s.firstname, s.lastname, c.name AS class_name
    FROM students s LEFT JOIN classes c ON c.id = s.class_id
    WHERE s.status IN ('studying','graduated') ORDER BY c.name, s.student_number, s.student_code");
$allStudents = $studentsStmt->fetchAll();
$studentsByClass = [];
foreach ($allStudents as $student) {
    $studentsByClass[$student['class_name'] ?: 'ไม่ระบุชั้นเรียน'][] = $student;
}

$pageTitle = 'ศูนย์เอกสาร ปพ.';
$pageSubtitle = 'ออก จัดเก็บ และพิมพ์เอกสารทางการศึกษา ปพ.1–ปพ.9';
$activeNav = 'documents';
$pageActions = '<a class="btn btn-soft btn-sm" href="' . url('documents.php?batch=1') . '">' . icon('printer', 16) . '<span>พิมพ์ทั้งห้อง</span></a>'
    . '<a class="btn btn-primary btn-sm" href="' . url('documents.php?new=1') . '">' . icon('plus', 16) . '<span>ออกเอกสารใหม่</span></a>';

require_once __DIR__ . '/includes/header.php';
?>

<section class="stat-grid mb-3">
  <article class="stat-card" style="--accent:#4f46e5;--accent-soft:#eef2ff;--i:0">
    <div class="stat-icon"><?= icon('file', 22) ?></div>
    <div class="stat-value num" data-count="<?= (int) $stats['total'] ?>">0</div>
    <div class="stat-label">เอกสารทั้งหมด</div>
    <div class="stat-foot"><span class="stat-trend neutral"><?= icon('clipboard', 12) ?> 9 ประเภท ปพ.</span></div>
  </article>
  <article class="stat-card" style="--accent:#10b981;--accent-soft:#ecfdf5;--i:1">
    <div class="stat-icon"><?= icon('calendar', 22) ?></div>
    <div class="stat-value num" data-count="<?= (int) $stats['this_month'] ?>">0</div>
    <div class="stat-label">ออกเอกสารเดือนนี้</div>
    <div class="stat-foot"><span class="stat-trend up"><?= icon('trending', 12) ?><?= e(month_label(date('Y-m'))) ?></span></div>
  </article>
  <article class="stat-card" style="--accent:#7c3aed;--accent-soft:#f5f3ff;--i:2">
    <div class="stat-icon"><?= icon('users', 22) ?></div>
    <div class="stat-value num" data-count="<?= count($allStudents) ?>">0</div>
    <div class="stat-label">นักเรียนที่ออกเอกสารได้</div>
    <div class="stat-foot"><span class="stat-trend neutral"><?= icon('graduation', 12) ?> กำลังศึกษา / จบ</span></div>
  </article>
  <article class="stat-card" style="--accent:#ec4899;--accent-soft:#fdf2f8;--i:3">
    <div class="stat-icon"><?= icon('printer', 22) ?></div>
    <div class="stat-value num" data-count="<?= count($documents) ?>">0</div>
    <div class="stat-label">รายการตามตัวกรอง</div>
    <div class="stat-foot"><span class="stat-trend neutral"><?= icon('filter', 12) ?> พร้อมพิมพ์ A4</span></div>
  </article>
</section>

<?php if ($showForm): ?>
<section class="card mb-3 animate-pop">
  <div class="card-head bordered">
    <div>
      <h3 class="card-title"><?= icon('file', 19) ?> ออกเอกสารทางการศึกษา</h3>
      <p class="card-sub">เลือกนักเรียนและประเภทเอกสาร ระบบจะออกเลขที่เอกสารให้อัตโนมัติ</p>
    </div>
    <div class="card-actions"><a class="btn btn-ghost btn-sm" href="<?= url('documents.php') ?>"><?= icon('x', 15) ?> ปิด</a></div>
  </div>
  <div class="card-body">
    <?php if (isset($errors['general'])): ?><div class="notice notice-danger mb-2"><?= icon('alert', 18) ?><div><?= e($errors['general']) ?></div></div><?php endif; ?>
    <form method="post" action="<?= url('documents.php?new=1') ?>">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="issue">
      <div class="form-grid">
        <div class="field span-2">
          <label>นักเรียน <span class="req">*</span></label>
          <select class="select <?= isset($errors['student_id']) ? 'is-invalid' : '' ?>" name="student_id" required>
            <option value="">— เลือกนักเรียน —</option>
            <?php foreach ($studentsByClass as $groupName => $groupStudents): ?>
              <optgroup label="<?= e($groupName) ?>">
                <?php foreach ($groupStudents as $student): ?>
                  <option value="<?= (int) $student['id'] ?>" <?= (int) $form['student_id'] === (int) $student['id'] ? 'selected' : '' ?>><?= e($student['student_code'] . ' · ' . student_name($student)) ?></option>
                <?php endforeach; ?>
              </optgroup>
            <?php endforeach; ?>
          </select>
          <?php if (isset($errors['student_id'])): ?><span class="field-error"><?= e($errors['student_id']) ?></span><?php endif; ?>
        </div>

        <div class="field span-2">
          <label>ประเภทเอกสาร <span class="req">*</span></label>
          <div class="doc-type-grid">
            <?php foreach ($docTypes as $key => $type): ?>
              <label class="doc-type-opt">
                <input type="radio" name="doc_type" value="<?= e($key) ?>" <?= $form['doc_type'] === $key ? 'checked' : '' ?>>
                <span><?= icon($type['icon'], 18) ?><b><?= e($type['label']) ?></b><small><?= e($type['name']) ?></small></span>
              </label>
            <?php endforeach; ?>
          </div>
          <?php if (isset($errors['doc_type'])): ?><span class="field-error"><?= e($errors['doc_type']) ?></span><?php endif; ?>
        </div>

        <div class="field">
          <label>ปีการศึกษา</label>
          <input class="input <?= isset($errors['academic_year']) ? 'is-invalid' : '' ?>" type="text" name="academic_year" value="<?= e($form['academic_year']) ?>" maxlength="4">
          <?php if (isset($errors['academic_year'])): ?><span class="field-error"><?= e($errors['academic_year']) ?></span><?php endif; ?>
        </div>
        <div class="field">
          <label>ภาคเรียน</label>
          <select class="select" name="semester">
            <option value="1" <?= (int) $form['semester'] === 1 ? 'selected' : '' ?>>ภาคเรียนที่ 1</option>
            <option value="2" <?= (int) $form['semester'] === 2 ? 'selected' : '' ?>>ภาคเรียนที่ 2</option>
          </select>
        </div>
        <div class="field span-2">
          <label>หมายเหตุ / วัตถุประสงค์การใช้งาน</label>
          <textarea class="textarea" name="note" placeholder="เช่น ใช้ประกอบการสมัครเรียนต่อ"><?= e($form['note']) ?></textarea>
        </div>
      </div>
      <div class="form-actions">
        <button class="btn btn-primary" type="submit"><?= icon('file', 17) ?> ออกเอกสารและเปิดหน้าพิมพ์</button>
        <a class="btn btn-ghost" href="<?= url('documents.php') ?>">ยกเลิก</a>
      </div>
    </form>
  </div>
</section>
<?php endif; ?>

<?php if ($showBatchForm): ?>
<section class="card mb-3 animate-pop batch-panel">
  <div class="card-head bordered">
    <div>
      <h3 class="card-title"><?= icon('printer', 19) ?> พิมพ์เอกสารทั้งห้อง</h3>
      <p class="card-sub">ออกเอกสาร ปพ. ให้นักเรียนทุกคนในชั้นเรียน แล้วเปิดชุดพิมพ์ A4 ต่อเนื่องในครั้งเดียว</p>
    </div>
    <div class="card-actions"><a class="btn btn-ghost btn-sm" href="<?= url('documents.php') ?>"><?= icon('x', 15) ?> ปิด</a></div>
  </div>
  <div class="card-body">
    <?php if (isset($batchErrors['general'])): ?><div class="notice notice-danger mb-2"><?= icon('alert', 18) ?><div><?= e($batchErrors['general']) ?></div></div><?php endif; ?>
    <form method="post" action="<?= url('documents.php?batch=1') ?>" data-batch-form>
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="issue_class">
      <div class="form-grid">
        <div class="field span-2">
          <label>ชั้นเรียน <span class="req">*</span></label>
          <select class="select <?= isset($batchErrors['class_id']) ? 'is-invalid' : '' ?>" name="class_id" required data-batch-class>
            <option value="" data-count="0" data-name="">— เลือกชั้นเรียน —</option>
            <?php foreach ($classes as $class): ?>
              <option value="<?= (int) $class['id'] ?>" data-count="<?= (int) ($class['students'] ?? 0) ?>" data-name="<?= e($class['name']) ?>" <?= (int) $batchForm['class_id'] === (int) $class['id'] ? 'selected' : '' ?>>
                <?= e($class['name']) ?> · <?= (int) ($class['students'] ?? 0) ?> คน
              </option>
            <?php endforeach; ?>
          </select>
          <?php if (isset($batchErrors['class_id'])): ?><span class="field-error"><?= e($batchErrors['class_id']) ?></span><?php endif; ?>
        </div>

        <div class="field span-2">
          <label>ประเภทเอกสาร <span class="req">*</span></label>
          <div class="doc-type-grid">
            <?php foreach ($docTypes as $key => $type): ?>
              <label class="doc-type-opt">
                <input type="radio" name="doc_type" value="<?= e($key) ?>" <?= $batchForm['doc_type'] === $key ? 'checked' : '' ?>>
                <span><?= icon($type['icon'], 18) ?><b><?= e($type['label']) ?></b><small><?= e($type['name']) ?></small></span>
              </label>
            <?php endforeach; ?>
          </div>
          <?php if (isset($batchErrors['doc_type'])): ?><span class="field-error"><?= e($batchErrors['doc_type']) ?></span><?php endif; ?>
        </div>

        <div class="field">
          <label>ปีการศึกษา</label>
          <input class="input <?= isset($batchErrors['academic_year']) ? 'is-invalid' : '' ?>" type="text" name="academic_year" value="<?= e($batchForm['academic_year']) ?>" maxlength="4">
          <?php if (isset($batchErrors['academic_year'])): ?><span class="field-error"><?= e($batchErrors['academic_year']) ?></span><?php endif; ?>
        </div>
        <div class="field">
          <label>ภาคเรียน</label>
          <select class="select" name="semester">
            <option value="1" <?= (int) $batchForm['semester'] === 1 ? 'selected' : '' ?>>ภาคเรียนที่ 1</option>
            <option value="2" <?= (int) $batchForm['semester'] === 2 ? 'selected' : '' ?>>ภาคเรียนที่ 2</option>
          </select>
          <?php if (isset($batchErrors['semester'])): ?><span class="field-error"><?= e($batchErrors['semester']) ?></span><?php endif; ?>
        </div>
        <div class="field span-2">
          <label>หมายเหตุ (ใช้กับทุกฉบับ)</label>
          <textarea class="textarea" name="note" placeholder="เช่น ใช้ประกอบการสมัครเรียนต่อ"><?= e($batchForm['note']) ?></textarea>
        </div>
      </div>

      <label class="switch-row">
        <input type="checkbox" name="reuse" value="1" <?= $batchForm['reuse'] ? 'checked' : '' ?>>
        <span class="switch-track" aria-hidden="true"><span></span></span>
        <span class="switch-text">
          <b>ใช้เอกสารเดิมถ้ามีอยู่แล้ว</b>
          <small>ไม่สร้างเลขที่ซ้ำสำหรับนักเรียนที่ออกเอกสารประเภทนี้ในภาคเรียนเดียวกันแล้ว</small>
        </span>
      </label>

      <div class="batch-preview" data-batch-preview>
        <span class="batch-preview-icon"><?= icon('printer', 20) ?></span>
        <div class="batch-preview-text">
          <b data-batch-count aria-live="polite">พร้อมพิมพ์ 0 ฉบับ</b>
          <small data-batch-hint>เลือกชั้นเรียนเพื่อดูจำนวนเอกสาร</small>
        </div>
        <span class="batch-preview-chip"><?= icon('file', 14) ?> A4 · 1 ฉบับ / 1 หน้า</span>
      </div>

      <div class="form-actions">
        <button class="btn btn-primary" type="submit"><?= icon('printer', 17) ?> สร้างชุดเอกสารและเปิดหน้าพิมพ์</button>
        <a class="btn btn-ghost" href="<?= url('documents.php') ?>">ยกเลิก</a>
      </div>
    </form>
  </div>
</section>
<script>
(function () {
  var form = document.querySelector('[data-batch-form]');
  if (!form) return;
  var select = form.querySelector('[data-batch-class]');
  var countEl = form.querySelector('[data-batch-count]');
  var hintEl = form.querySelector('[data-batch-hint]');
  function update() {
    var opt = select && select.options[select.selectedIndex];
    var count = opt ? parseInt(opt.getAttribute('data-count') || '0', 10) : 0;
    var name = opt ? (opt.getAttribute('data-name') || '') : '';
    if (countEl) countEl.textContent = 'พร้อมพิมพ์ ' + count + ' ฉบับ';
    if (hintEl) hintEl.textContent = count > 0
      ? name + ' · ระบบจะออกเลขที่เอกสารให้อัตโนมัติทีละฉบับ'
      : 'เลือกชั้นเรียนเพื่อดูจำนวนเอกสาร';
  }
  if (select) select.addEventListener('change', update);
  update();
})();
</script>
<?php endif; ?>

<form class="toolbar" method="get" action="<?= url('documents.php') ?>">
  <div class="toolbar-left">
    <div class="searchbox">
      <?= icon('search', 17) ?>
      <input class="input" type="search" name="q" value="<?= e($q) ?>" placeholder="ค้นหาเลขที่เอกสาร ชื่อนักเรียน หรือรหัส…">
    </div>
    <select class="select" name="type">
      <option value="">ทุกประเภท</option>
      <?php foreach ($docTypes as $key => $type): ?>
        <option value="<?= e($key) ?>" <?= $typeFilter === $key ? 'selected' : '' ?>><?= e($type['label'] . ' ' . $type['name']) ?></option>
      <?php endforeach; ?>
    </select>
    <select class="select" name="class_id">
      <option value="">ทุกชั้นเรียน</option>
      <?php foreach ($classes as $class): ?>
        <option value="<?= (int) $class['id'] ?>" <?= $classId === (int) $class['id'] ? 'selected' : '' ?>><?= e($class['name']) ?></option>
      <?php endforeach; ?>
    </select>
    <button class="btn btn-primary btn-sm" type="submit"><?= icon('filter', 15) ?> กรองข้อมูล</button>
    <?php if ($where): ?><a class="btn btn-ghost btn-sm" href="<?= url('documents.php') ?>"><?= icon('refresh', 15) ?> ล้าง</a><?php endif; ?>
  </div>
</form>

<div class="chips-row mb-2" style="display:flex;gap:6px;flex-wrap:wrap">
  <a class="chip <?= $typeFilter === '' ? 'chip-soft' : '' ?>" href="<?= url('documents.php') ?>"><?= icon('file', 13) ?> ทั้งหมด</a>
  <?php foreach ($docTypes as $key => $type): ?>
    <a class="chip <?= $typeFilter === $key ? 'chip-soft' : '' ?>" href="<?= url('documents.php?type=' . $key) ?>"><?= icon($type['icon'], 13) ?> <?= e($type['label']) ?></a>
  <?php endforeach; ?>
</div>

<div class="table-wrap">
  <table class="table">
    <thead>
      <tr>
        <th>เลขที่เอกสาร</th>
        <th>นักเรียน</th>
        <th>ประเภท</th>
        <th>ชื่อเอกสาร</th>
        <th>วันที่ออก</th>
        <th>ผู้ออก</th>
        <th class="text-right">จัดการ</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach ($documents as $doc): ?>
      <?php $type = doc_type($doc['doc_type']); ?>
      <tr>
        <td><span class="doc-no"><?= e($doc['doc_no']) ?></span></td>
        <td>
          <div class="cell-user">
            <span class="avatar sm <?= avatar_class($doc['firstname']) ?>"><?= e(name_initials($doc['firstname'], $doc['lastname'])) ?></span>
            <div><b><?= e(student_name($doc)) ?></b><small><?= e($doc['class_name'] ?: '—') ?> · <?= e($doc['student_code']) ?></small></div>
          </div>
        </td>
        <td><span class="doc-badge"><?= e($type['label']) ?></span></td>
        <td class="text-sm"><?= e($doc['title']) ?><br><small class="text-muted"><?= e($doc['note'] ?: '—') ?></small></td>
        <td class="text-sm"><?= e(thai_datetime($doc['issued_at'], true)) ?></td>
        <td class="text-sm text-muted"><?= e($doc['issued_by'] ?: '—') ?></td>
        <td>
          <div class="cell-actions">
            <a class="icon-btn" href="<?= url('document-print.php?id=' . (int) $doc['id']) ?>" target="_blank" rel="noopener" title="พิมพ์เอกสาร"><?= icon('printer', 16) ?></a>
            <a class="icon-btn" href="<?= url('student-view.php?id=' . (int) $doc['student_id']) ?>" title="ดูข้อมูลนักเรียน"><?= icon('eye', 16) ?></a>
            <?php if (can_manage()): ?>
              <form method="post" action="<?= url('documents.php') ?>" data-confirm="ต้องการลบเอกสารเลขที่ <?= e($doc['doc_no']) ?> ใช่หรือไม่?">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="document_id" value="<?= (int) $doc['id'] ?>">
                <button class="icon-btn danger" type="submit" title="ลบ"><?= icon('trash', 16) ?></button>
              </form>
            <?php endif; ?>
          </div>
        </td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$documents): ?>
      <tr><td colspan="7">
        <div class="empty-state">
          <div class="empty-ico"><?= icon('file', 30) ?></div>
          <h3>ไม่พบเอกสาร</h3>
          <p>ลองปรับเงื่อนไข หรือออกเอกสารฉบับใหม่</p>
          <a class="btn btn-primary btn-sm" href="<?= url('documents.php?new=1') ?>"><?= icon('plus', 15) ?> ออกเอกสารใหม่</a>
          <a class="btn btn-soft btn-sm" href="<?= url('documents.php?batch=1') ?>"><?= icon('printer', 15) ?> พิมพ์ทั้งห้อง</a>
        </div>
      </td></tr>
    <?php endif; ?>
    </tbody>
  </table>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
