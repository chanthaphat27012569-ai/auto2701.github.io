<?php

require_once __DIR__ . '/includes/bootstrap.php';

$staff = require_staff();
$pdo = db();

$batch = is_array($_SESSION['doc_print_batch'] ?? null) ? $_SESSION['doc_print_batch'] : [];
$ids = array_values(array_unique(array_filter(array_map('intval', $batch['ids'] ?? []))));
if (!$ids) {
    flash('warning', 'ไม่พบรายการพิมพ์ทั้งห้อง กรุณาเลือกชั้นเรียนและสร้างชุดเอกสารใหม่');
    redirect('documents.php?batch=1');
}

$placeholders = implode(',', array_fill(0, count($ids), '?'));
$stmt = $pdo->prepare("SELECT d.*, s.prefix, s.firstname, s.lastname, s.student_code, s.gender, s.birth_date, s.birth_place,
        s.nationality, s.religion, s.citizen_id, s.address, s.parent_name, s.parent_relation, s.parent_phone, s.status AS student_status,
        c.name AS class_name, c.level, c.level_short, c.room
    FROM documents d
    JOIN students s ON s.id = d.student_id
    LEFT JOIN classes c ON c.id = s.class_id
    WHERE d.id IN ($placeholders)");
$stmt->execute($ids);

$byId = [];
foreach ($stmt->fetchAll() as $row) {
    $byId[(int) $row['id']] = $row;
}
$docs = [];
foreach ($ids as $id) {
    if (isset($byId[$id])) {
        $docs[] = $byId[$id];
    }
}
if (!$docs) {
    flash('danger', 'ไม่พบเอกสารในชุดพิมพ์ที่เลือก');
    redirect('documents.php');
}

$doc = $docs[0];
$type = doc_type($doc['doc_type']);
$schoolName = school('name', APP_TITLE);

$gStmt = $pdo->prepare('SELECT g.score, g.grade, sub.code, sub.name, sub.credits
    FROM grades g JOIN subjects sub ON sub.id = g.subject_id
    WHERE g.student_id = ? AND g.academic_year = ? AND g.semester = ?
    ORDER BY sub.code');
$aStmt = $pdo->prepare("SELECT COUNT(*) AS total,
        SUM(status = 'present') AS present, SUM(status = 'late') AS late, SUM(status = 'sick') AS sick,
        SUM(status = 'business') AS business, SUM(status = 'absent') AS absent, SUM(status = 'truant') AS truant
    FROM attendance WHERE student_id = ?");

$pageTitle = 'พิมพ์เอกสารทั้งห้อง';
$pageSubtitle = ($batch['label'] ?? $type['label']) . ' · ' . count($docs) . ' ฉบับ';
$activeNav = 'documents';
$pageActions = '<button class="btn btn-primary btn-sm" type="button" data-print>' . icon('printer', 16) . '<span>พิมพ์ทั้งหมด</span></button>'
    . '<a class="btn btn-ghost btn-sm" href="' . url('documents.php?batch=1') . '">' . icon('plus', 16) . '<span>ชุดใหม่</span></a>'
    . '<a class="btn btn-ghost btn-sm" href="' . url('documents.php') . '">' . icon('arrow-left', 16) . '<span>กลับ</span></a>';

require_once __DIR__ . '/includes/header.php';
?>

<div class="batch-print-head no-print">
  <div class="batch-print-summary">
    <span class="doc-badge"><?= e($type['label']) ?></span>
    <span class="text-sm text-muted"><?= e($type['name']) ?></span>
    <span class="chip chip-soft"><?= icon('users', 13) ?> <?= number_format(count($docs)) ?> ฉบับ</span>
    <?php if (!empty($batch['class_name'])): ?><span class="chip"><?= icon('building', 13) ?> <?= e($batch['class_name']) ?></span><?php endif; ?>
    <span class="chip"><?= icon('calendar', 13) ?> ปี <?= e($doc['academic_year']) ?> · ภาค <?= (int) $doc['semester'] ?></span>
  </div>
  <div class="row">
    <button class="btn btn-primary btn-sm" type="button" data-print><?= icon('printer', 16) ?> พิมพ์ทั้งหมด <?= number_format(count($docs)) ?> ฉบับ</button>
  </div>
</div>

<div class="doc-preview-wrap is-batch">
  <div class="doc-batch">
    <?php foreach ($docs as $doc): ?>
      <?php
      $gStmt->execute([(int) $doc['student_id'], $doc['academic_year'], (int) $doc['semester']]);
      $grades = $gStmt->fetchAll();
      $points = [];
      $creditSum = 0.0;
      foreach ($grades as $row) {
          if (is_numeric($row['grade'])) {
              $points[] = (float) $row['grade'];
              $creditSum += (float) $row['credits'];
          }
      }
      $gpa = $points ? array_sum($points) / count($points) : 0.0;

      $aStmt->execute([(int) $doc['student_id']]);
      $att = $aStmt->fetch() ?: [];
      $attTotal = (int) ($att['total'] ?? 0);
      $attRate = $attTotal > 0 ? ((int) $att['present'] + (int) $att['late']) / $attTotal * 100 : 0;

      $type = doc_type($doc['doc_type']);
      $isLetter = in_array($doc['doc_type'], ['pp4', 'pp7', 'pp9'], true);
      $fullname = student_name($doc);
      $classText = $doc['class_name'] ?: ($doc['level_short'] ?: '—');
      $studentStatusMeta = student_status_meta();
      $studentStatus = $studentStatusMeta[$doc['student_status']] ?? $studentStatusMeta['studying'];
      ?>
      <?php require __DIR__ . '/includes/document-sheet.php'; ?>
    <?php endforeach; ?>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
