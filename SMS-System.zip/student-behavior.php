<?php

require_once __DIR__ . '/includes/bootstrap.php';

$portalActive = 'behavior';
$pageTitle = 'คะแนนพฤติกรรม';
$pageSubtitle = 'คะแนนและประวัติการเพิ่ม–ลดคะแนน';
require __DIR__ . '/includes/student-context.php';

$studentId = (int) $student['id'];
$portalTablesReady = portal_tables_ready();
$baseScore = 100;

$records = [];
$history = [];
$added = 0;
$deducted = 0;
$currentScore = $baseScore;

if ($portalTablesReady) {
    $recordStmt = $pdo->prepare('SELECT b.*, u.fullname AS recorder
        FROM behavior_records b
        LEFT JOIN users u ON u.id = b.recorded_by
        WHERE b.student_id = ?
        ORDER BY b.created_at ASC, b.id ASC');
    $recordStmt->execute([$studentId]);
    $records = $recordStmt->fetchAll();

    $running = $baseScore;
    foreach ($records as $record) {
        $points = (int) $record['points'];
        $before = $running;
        $running = max(0, $running + $points);
        if ($points >= 0) {
            $added += $points;
        } else {
            $deducted += abs($points);
        }
        $record['before'] = $before;
        $record['after'] = $running;
        $history[] = $record;
    }
    $currentScore = $running;
}

$history = array_reverse($history);
$meta = behavior_score_meta($currentScore);
$meterPercent = max(0, min(100, $currentScore));

$categoryTotals = [];
foreach ($history as $row) {
    $category = (string) ($row['category'] ?: 'ทั่วไป');
    if (!isset($categoryTotals[$category])) {
        $categoryTotals[$category] = 0;
    }
    $categoryTotals[$category] += (int) $row['points'];
}
arsort($categoryTotals);

require __DIR__ . '/includes/student-portal-top.php';
?>

<div class="page-heading">
  <div>
    <span class="hero-kicker dark"><?= icon('award', 15) ?> วินัยและพฤติกรรม</span>
    <h1>คะแนนพฤติกรรม</h1>
    <p>คะแนนเริ่มต้น <?= number_format($baseScore) ?> คะแนน · <?= e(student_name($student, false)) ?> รหัส <?= e($student['student_code']) ?></p>
  </div>
  <span class="badge badge-<?= e($meta['class']) ?>"><span class="dot"></span><?= e($meta['label']) ?></span>
</div>

<?php if (!$portalTablesReady): ?>
  <div class="notice notice-warning mb-2"><?= icon('alert', 18) ?><div><strong>ยังไม่มีข้อมูลคะแนนพฤติกรรม</strong><br>กรุณาให้เจ้าหน้าที่นำเข้าไฟล์ <code>database/student-portal.sql</code> เพื่อเปิดใช้งานระบบคะแนนพฤติกรรม</div></div>
<?php endif; ?>

<div class="grid grid-2-1">
  <div class="stack">
    <div class="behavior-hero" style="--accent:<?= e($meta['color']) ?>">
      <div class="behavior-score">
        <span class="behavior-score-label">คะแนนปัจจุบัน</span>
        <b><?= number_format($currentScore) ?></b>
        <span class="badge badge-<?= e($meta['class']) ?>"><?= e($meta['label']) ?></span>
      </div>
      <div class="behavior-meter">
        <div class="score-meter" role="img" aria-label="คะแนนพฤติกรรม <?= number_format($currentScore) ?> จาก 100">
          <span style="width:<?= $meterPercent ?>%;background:<?= e($meta['color']) ?>"></span>
        </div>
        <div class="behavior-meter-labels"><span>0</span><span>50</span><span>100</span></div>
        <div class="behavior-totals">
          <div><b style="color:#059669">+<?= number_format($added) ?></b><span>คะแนนที่ได้รับ</span></div>
          <div><b style="color:#dc2626">−<?= number_format($deducted) ?></b><span>คะแนนที่ถูกหัก</span></div>
          <div><b><?= number_format(count($history)) ?></b><span>รายการทั้งหมด</span></div>
        </div>
      </div>
    </div>

    <article class="card">
      <div class="card-head bordered">
        <div><h3 class="card-title"><?= icon('clipboard', 19) ?> ประวัติคะแนนพฤติกรรม</h3><p class="card-sub">แสดงลำดับคะแนนก่อน–หลังทุกรายการ</p></div>
        <div class="card-actions"><span class="chip"><?= icon('clock', 13) ?> ใหม่ล่าสุดก่อน</span></div>
      </div>
      <div class="table-wrap" style="border:0;box-shadow:none;border-radius:0">
        <table class="table">
          <thead><tr><th>วันที่</th><th>หมวด</th><th>รายละเอียด</th><th class="text-center">คะแนน</th><th class="text-center">ก่อน → หลัง</th><th>ผู้บันทึก</th></tr></thead>
          <tbody>
            <?php foreach ($history as $row): ?>
              <?php $points = (int) $row['points']; ?>
              <tr>
                <td class="text-sm"><?= e(thai_datetime($row['created_at'], true)) ?></td>
                <td><span class="badge badge-<?= $points >= 0 ? 'success' : 'danger' ?>"><?= e($row['category'] ?: 'ทั่วไป') ?></span></td>
                <td class="text-sm"><?= e($row['reason'] ?: '—') ?></td>
                <td class="text-center"><b style="color:<?= $points >= 0 ? '#059669' : '#dc2626' ?>"><?= $points >= 0 ? '+' : '−' ?><?= number_format(abs($points)) ?></b></td>
                <td class="text-center text-sm num"><span class="text-muted"><?= number_format((int) $row['before']) ?></span> → <b><?= number_format((int) $row['after']) ?></b></td>
                <td class="text-sm text-muted"><?= e($row['recorder'] ?: '—') ?></td>
              </tr>
            <?php endforeach; ?>
            <?php if (!$history): ?>
              <tr><td colspan="6"><div class="empty-state"><div class="empty-ico"><?= icon('award', 28) ?></div><h3>ยังไม่มีประวัติคะแนน</h3><p>เมื่อครูบันทึกคะแนนพฤติกรรม ประวัติจะแสดงที่นี่</p></div></td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </article>
  </div>

  <div class="stack">
    <article class="card">
      <div class="card-head"><div><h3 class="card-title"><?= icon('chart', 19) ?> สรุปตามหมวด</h3><p class="card-sub">คะแนนสุทธิรายหมวด</p></div></div>
      <div class="card-body" style="padding-top:8px">
        <div class="stack" style="gap:8px">
          <?php foreach ($categoryTotals as $category => $points): ?>
            <div class="row" style="justify-content:space-between;padding:9px 12px;border-radius:10px;background:#f8faff;border:1px solid #eef1f9">
              <span class="text-sm" style="font-weight:600"><?= e($category) ?></span>
              <b style="color:<?= $points >= 0 ? '#059669' : '#dc2626' ?>;font-size:.86rem"><?= $points >= 0 ? '+' : '−' ?><?= number_format(abs($points)) ?></b>
            </div>
          <?php endforeach; ?>
          <?php if (!$categoryTotals): ?><div class="empty-state" style="padding:24px"><p>ยังไม่มีข้อมูล</p></div><?php endif; ?>
        </div>
      </div>
    </article>

    <article class="card">
      <div class="card-head"><div><h3 class="card-title"><?= icon('info', 19) ?> เกณฑ์คะแนน</h3><p class="card-sub">การแปลผลคะแนนพฤติกรรม</p></div></div>
      <div class="card-body" style="padding-top:8px">
        <div class="legend" style="width:100%">
          <div class="legend-item"><span class="swatch" style="background:#10b981"></span>ดีมาก<b>90–100</b></div>
          <div class="legend-item"><span class="swatch" style="background:#3b82f6"></span>ดี<b>80–89</b></div>
          <div class="legend-item"><span class="swatch" style="background:#f59e0b"></span>พอใช้<b>60–79</b></div>
          <div class="legend-item"><span class="swatch" style="background:#ef4444"></span>ควรปรับปรุง<b>ต่ำกว่า 60</b></div>
        </div>
        <div class="notice notice-info mt-2" style="margin-bottom:0"><?= icon('shield', 17) ?><div>คะแนนพฤติกรรมคำนวณจากคะแนนเริ่มต้น <?= number_format($baseScore) ?> บวก–ลบรายการที่ครูบันทึก และไม่ต่ำกว่า 0</div></div>
      </div>
    </article>
  </div>
</div>

<?php require __DIR__ . '/includes/student-portal-bottom.php'; ?>
