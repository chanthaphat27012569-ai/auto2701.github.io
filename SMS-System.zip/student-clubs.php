<?php

require_once __DIR__ . '/includes/bootstrap.php';

$portalActive = 'clubs';
$pageTitle = 'ลงทะเบียนชุมนุม';
$pageSubtitle = 'เลือกชุมนุมได้ 1 ชุมนุมต่อภาคเรียน';
require __DIR__ . '/includes/student-context.php';

$studentId = (int) $student['id'];
$portalTablesReady = portal_tables_ready();
$error = '';

if (is_post() && post_str('action') === 'register_club') {
    verify_csrf();
    if ($isPreview) {
        flash('warning', 'โหมดตัวอย่างไม่สามารถลงทะเบียนชุมนุมได้');
        redirect('student-clubs.php');
    }
    if (!$portalTablesReady) {
        flash('danger', 'ระบบชุมนุมยังไม่พร้อมใช้งาน กรุณานำเข้า student-portal.sql');
        redirect('student-clubs.php');
    }

    $clubId = (int) post_str('club_id');
    if ($clubId <= 0) {
        $error = 'กรุณาเลือกชุมนุมที่ต้องการลงทะเบียน';
    }

    if ($error === '') {
        try {
            $pdo->beginTransaction();

            $lockStmt = $pdo->prepare('SELECT * FROM clubs
                WHERE id = ? AND status = "active" AND academic_year = ? AND semester = ? FOR UPDATE');
            $lockStmt->execute([$clubId, $year, $semester]);
            $club = $lockStmt->fetch();

            if (!$club) {
                $pdo->rollBack();
                $error = 'ไม่พบชุมนุมที่เลือก หรือชุมนุมปิดรับสมัครแล้ว';
            } else {
                $existingStmt = $pdo->prepare('SELECT c.name FROM club_registrations cr
                    JOIN clubs c ON c.id = cr.club_id
                    WHERE cr.student_id = ? AND cr.academic_year = ? AND cr.semester = ? LIMIT 1');
                $existingStmt->execute([$studentId, $year, $semester]);
                $existingName = $existingStmt->fetchColumn();

                if ($existingName !== false && $existingName !== null) {
                    $pdo->rollBack();
                    $error = 'ลงทะเบียนชุมนุม "' . $existingName . '" ไปแล้ว และไม่สามารถเปลี่ยนเองได้';
                } else {
                    $countStmt = $pdo->prepare('SELECT COUNT(*) FROM club_registrations WHERE club_id = ?');
                    $countStmt->execute([$clubId]);
                    $memberCount = (int) $countStmt->fetchColumn();

                    if ($memberCount >= (int) $club['capacity']) {
                        $pdo->rollBack();
                        $error = 'ชุมนุม "' . $club['name'] . '" เต็มแล้ว';
                    } else {
                        $insertStmt = $pdo->prepare('INSERT INTO club_registrations (club_id, student_id, academic_year, semester) VALUES (?, ?, ?, ?)');
                        $insertStmt->execute([$clubId, $studentId, $year, $semester]);
                        $pdo->commit();
                        flash('success', 'ลงทะเบียนชุมนุม "' . $club['name'] . '" สำเร็จ');
                        redirect('student-clubs.php');
                    }
                }
            }
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $error = 'ไม่สามารถลงทะเบียนได้ กรุณาลองใหม่อีกครั้ง';
        }
    }

    if ($error !== '') {
        flash('danger', $error);
        redirect('student-clubs.php');
    }
}

$clubs = [];
$memberCounts = [];
$myRegistration = null;

if ($portalTablesReady) {
    $clubStmt = $pdo->prepare("SELECT * FROM clubs
        WHERE status = 'active' AND academic_year = ? AND semester = ?
        ORDER BY code");
    $clubStmt->execute([$year, $semester]);
    $clubs = $clubStmt->fetchAll();

    if ($clubs) {
        $ids = array_map('intval', array_column($clubs, 'id'));
        $in = implode(',', array_fill(0, count($ids), '?'));
        $countStmt = $pdo->prepare('SELECT club_id, COUNT(*) AS total FROM club_registrations WHERE club_id IN (' . $in . ') GROUP BY club_id');
        $countStmt->execute($ids);
        foreach ($countStmt->fetchAll() as $row) {
            $memberCounts[(int) $row['club_id']] = (int) $row['total'];
        }
    }

    $myStmt = $pdo->prepare('SELECT cr.*, c.code, c.name, c.teacher_name, c.location
        FROM club_registrations cr JOIN clubs c ON c.id = cr.club_id
        WHERE cr.student_id = ? AND cr.academic_year = ? AND cr.semester = ?
        ORDER BY cr.id DESC LIMIT 1');
    $myStmt->execute([$studentId, $year, $semester]);
    $myRegistration = $myStmt->fetch() ?: null;
}

$registrationLocked = (bool) $myRegistration;

require __DIR__ . '/includes/student-portal-top.php';
?>

<div class="page-heading">
  <div>
    <span class="hero-kicker dark"><?= icon('users', 15) ?> ชุมนุมโรงเรียน</span>
    <h1>ลงทะเบียนชุมนุม</h1>
    <p>ปีการศึกษา <?= e($year) ?> ภาคเรียนที่ <?= $semester ?> · เลือกได้ 1 ชุมนุม และไม่สามารถยกเลิกหรือเปลี่ยนเองได้</p>
  </div>
  <?php if ($registrationLocked): ?>
    <span class="badge badge-success"><span class="dot"></span>ลงทะเบียนแล้ว</span>
  <?php else: ?>
    <span class="badge badge-warning"><span class="dot"></span>ยังไม่ลงทะเบียน</span>
  <?php endif; ?>
</div>

<?php if (!$portalTablesReady): ?>
  <div class="notice notice-warning mb-2"><?= icon('alert', 18) ?><div><strong>ยังไม่มีข้อมูลชุมนุม</strong><br>กรุณาให้เจ้าหน้าที่นำเข้าไฟล์ <code>database/student-portal.sql</code> เพื่อเปิดใช้งานระบบลงทะเบียนชุมนุม</div></div>
<?php endif; ?>

<?php if ($isPreview): ?>
  <div class="notice notice-info mb-2"><?= icon('eye', 18) ?><div>โหมดตัวอย่างสำหรับเจ้าหน้าที่ — ไม่สามารถลงทะเบียนชุมนุมแทนนักเรียนได้</div></div>
<?php endif; ?>

<?php if ($myRegistration): ?>
  <article class="card registration-hero mb-2">
    <div class="card-body">
      <div class="registration-hero-main">
        <span class="reg-ico"><?= icon('users', 24) ?></span>
        <div>
          <span class="hero-kicker dark">ชุมนุมที่ลงทะเบียนแล้ว</span>
          <h2><?= e($myRegistration['name']) ?></h2>
          <p class="text-sm text-muted"><?= icon('user', 13) ?> <?= e($myRegistration['teacher_name'] ?: '—') ?><?php if ($myRegistration['location'] !== ''): ?> · <?= icon('map-pin', 13) ?> <?= e($myRegistration['location']) ?><?php endif; ?></p>
        </div>
      </div>
      <div class="registration-hero-side">
        <span class="badge badge-success"><span class="dot"></span>ยืนยันการลงทะเบียนแล้ว</span>
        <small class="text-muted">หากต้องการเปลี่ยนแปลง กรุณาติดต่อครูที่ปรึกษาชุมนุม</small>
      </div>
    </div>
  </article>
<?php endif; ?>

<div class="club-grid">
  <?php foreach ($clubs as $club): ?>
    <?php
      $members = (int) ($memberCounts[(int) $club['id']] ?? 0);
      $capacity = max(1, (int) $club['capacity']);
      $seats = max(0, $capacity - $members);
      $percent = min(100, $members / $capacity * 100);
      $isMine = $myRegistration && (int) $myRegistration['club_id'] === (int) $club['id'];
    ?>
    <article class="club-card <?= $isMine ? 'is-mine' : '' ?>">
      <div class="club-card-head">
        <span class="club-code"><?= e($club['code']) ?></span>
        <?php if ($isMine): ?><span class="badge badge-success"><span class="dot"></span>ชุมนุมของฉัน</span><?php elseif ($seats <= 0): ?><span class="badge badge-danger">เต็ม</span><?php else: ?><span class="badge badge-<?= $seats <= 5 ? 'warning' : 'info' ?>">เหลือ <?= number_format($seats) ?> ที่นั่ง</span><?php endif; ?>
      </div>
      <h3><?= e($club['name']) ?></h3>
      <p><?= e($club['description'] ?: 'ชุมนุมสำหรับนักเรียนที่สนใจ') ?></p>
      <div class="club-meta">
        <span><?= icon('user', 13) ?> <?= e($club['teacher_name'] ?: '—') ?></span>
        <?php if ($club['location'] !== ''): ?><span><?= icon('map-pin', 13) ?> <?= e($club['location']) ?></span><?php endif; ?>
      </div>
      <div class="club-capacity">
        <div class="club-capacity-head"><span>สมาชิก <?= number_format($members) ?>/<?= number_format($capacity) ?></span><span><?= number_format($percent, 0) ?>%</span></div>
        <div class="club-capacity-bar"><span style="width:<?= $percent ?>%"></span></div>
      </div>
      <form method="post" action="<?= e(portal_url('student-clubs.php')) ?>" class="club-action"
        <?php if (!$isMine && !$myRegistration && !$isPreview && $seats > 0): ?>data-confirm="ยืนยันลงทะเบียนชุมนุม &quot;<?= e($club['name']) ?>&quot;? หลังลงทะเบียนแล้วจะไม่สามารถเปลี่ยนหรือยกเลิกเองได้"<?php endif; ?>>
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="register_club">
        <input type="hidden" name="club_id" value="<?= (int) $club['id'] ?>">
        <?php if ($isMine): ?>
          <button type="button" class="btn btn-ghost" style="width:100%" disabled><?= icon('check', 16) ?> ลงทะเบียนแล้ว</button>
        <?php elseif ($myRegistration): ?>
          <button type="button" class="btn btn-ghost" style="width:100%" disabled><?= icon('lock', 16) ?> ล็อกแล้ว</button>
        <?php elseif ($isPreview): ?>
          <button type="button" class="btn btn-ghost" style="width:100%" disabled><?= icon('eye', 16) ?> โหมดตัวอย่าง</button>
        <?php elseif ($seats <= 0): ?>
          <button type="button" class="btn btn-ghost" style="width:100%" disabled><?= icon('x-circle', 16) ?> ที่นั่งเต็ม</button>
        <?php else: ?>
          <button type="submit" class="btn btn-primary" style="width:100%"><?= icon('check', 16) ?> ลงทะเบียนชุมนุมนี้</button>
        <?php endif; ?>
      </form>
    </article>
  <?php endforeach; ?>
  <?php if (!$clubs): ?>
    <div class="card"><div class="empty-state"><div class="empty-ico"><?= icon('users', 28) ?></div><h3>ยังไม่มีชุมนุมเปิดรับสมัคร</h3><p>ชุมนุมสำหรับภาคเรียนนี้จะแสดงที่นี่</p></div></div>
  <?php endif; ?>
</div>

<div class="notice notice-info mt-2">
  <?= icon('lock', 18) ?>
  <div><strong>เงื่อนไขการลงทะเบียนชุมนุม</strong><br>นักเรียนเลือกได้ 1 ชุมนุมต่อภาคเรียน เมื่อลงทะเบียนแล้วระบบจะล็อกและไม่สามารถยกเลิกหรือเปลี่ยนชุมนุมเองได้ หากมีความจำเป็นกรุณาติดต่อครูที่ปรึกษาชุมนุมหรือฝ่ายกิจการนักเรียน</div>
</div>

<?php require __DIR__ . '/includes/student-portal-bottom.php'; ?>
