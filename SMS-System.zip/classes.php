<?php

require_once __DIR__ . '/includes/bootstrap.php';

$user = require_staff();
$pdo = db();

$errors = [];
$form = [
    'id' => 0,
    'name' => '',
    'level' => '',
    'level_short' => '',
    'room' => '',
    'homeroom' => '',
    'academic_year' => academic_year(),
    'status' => 'active',
];
$showForm = get_str('new') === '1' || get_int('edit') > 0;

if (get_int('edit') > 0) {
    $stmt = $pdo->prepare('SELECT * FROM classes WHERE id = ?');
    $stmt->execute([get_int('edit')]);
    $row = $stmt->fetch();
    if ($row) {
        $form = array_merge($form, $row);
        $form['id'] = (int) $row['id'];
    }
}

if (is_post()) {
    verify_csrf();
    require_manage();
    $action = post_str('action');

    if ($action === 'delete') {
        $deleteId = (int) ($_POST['class_id'] ?? 0);
        $stmt = $pdo->prepare('SELECT name FROM classes WHERE id = ?');
        $stmt->execute([$deleteId]);
        $existing = $stmt->fetch();
        if ($existing) {
            $del = $pdo->prepare('DELETE FROM classes WHERE id = ?');
            $del->execute([$deleteId]);
            flash('success', 'ลบชั้นเรียน ' . $existing['name'] . ' แล้ว นักเรียนในชั้นนี้จะถูกย้ายไปสถานะไม่ระบุชั้นเรียน');
        } else {
            flash('danger', 'ไม่พบชั้นเรียนที่ต้องการลบ');
        }
        redirect('classes.php');
    }

    if ($action === 'save') {
        foreach (['name', 'level', 'level_short', 'room', 'homeroom', 'academic_year'] as $key) {
            $form[$key] = post_str($key);
        }
        $form['status'] = post_str('status') === 'inactive' ? 'inactive' : 'active';

        if ($form['name'] === '') {
            $errors['name'] = 'กรุณากรอกชื่อชั้นเรียน';
        }
        if ($form['level_short'] === '') {
            $errors['level_short'] = 'กรุณากรอกชื่อย่อระดับชั้น';
        }
        if ($form['academic_year'] === '' || !preg_match('/^\d{4}$/', $form['academic_year'])) {
            $errors['academic_year'] = 'ปีการศึกษาต้องเป็นตัวเลข 4 หลัก';
        }
        if (!$errors) {
            $stmt = $pdo->prepare('SELECT id FROM classes WHERE name = ? AND id <> ? LIMIT 1');
            $stmt->execute([$form['name'], $form['id']]);
            if ($stmt->fetch()) {
                $errors['name'] = 'มีชื่อชั้นเรียนนี้อยู่แล้ว';
            }
        }
        if (!$errors) {
            if ($form['id'] > 0) {
                $stmt = $pdo->prepare('UPDATE classes SET name=?, level=?, level_short=?, room=?, homeroom=?, academic_year=?, status=? WHERE id=?');
                $stmt->execute([$form['name'], $form['level'], $form['level_short'], $form['room'], $form['homeroom'], $form['academic_year'], $form['status'], $form['id']]);
                flash('success', 'บันทึกข้อมูลชั้นเรียน ' . $form['name'] . ' เรียบร้อยแล้ว');
            } else {
                $stmt = $pdo->prepare('INSERT INTO classes (name, level, level_short, room, homeroom, academic_year, status) VALUES (?,?,?,?,?,?,?)');
                $stmt->execute([$form['name'], $form['level'], $form['level_short'], $form['room'], $form['homeroom'], $form['academic_year'], $form['status']]);
                flash('success', 'เพิ่มชั้นเรียน ' . $form['name'] . ' เรียบร้อยแล้ว');
            }
            redirect('classes.php');
        }
        $showForm = true;
    }
}

$month = date('Y-m');
$stmt = $pdo->prepare("SELECT c.*,
        (SELECT COUNT(*) FROM students s WHERE s.class_id = c.id AND s.status = 'studying') AS students,
        (SELECT COUNT(*) FROM students s WHERE s.class_id = c.id AND s.status = 'studying' AND s.gender = 'male') AS males,
        (SELECT COUNT(*) FROM attendance a WHERE a.class_id = c.id AND DATE_FORMAT(a.att_date, '%Y-%m') = ? AND a.status IN ('present','late')) AS attended,
        (SELECT COUNT(*) FROM attendance a WHERE a.class_id = c.id AND DATE_FORMAT(a.att_date, '%Y-%m') = ?) AS recorded
    FROM classes c
    ORDER BY c.academic_year DESC, c.name");
$stmt->execute([$month, $month]);
$classes = $stmt->fetchAll();

$totalStudents = array_sum(array_map(fn($c) => (int) $c['students'], $classes));
$banners = [
    'linear-gradient(125deg, #4f46e5, #7c3aed)',
    'linear-gradient(125deg, #0ea5e9, #4f46e5)',
    'linear-gradient(125deg, #ec4899, #8b5cf6)',
    'linear-gradient(125deg, #10b981, #0d9488)',
    'linear-gradient(125deg, #f59e0b, #ef4444)',
    'linear-gradient(125deg, #6366f1, #ec4899)',
];

$pageTitle = 'ชั้นเรียน';
$pageSubtitle = 'จัดการห้องเรียน ครูประจำชั้น และภาพรวมนักเรียน';
$activeNav = 'classes';
$pageActions = can_manage() ? '<a class="btn btn-primary btn-sm" href="' . url('classes.php?new=1') . '">' . icon('plus', 16) . '<span>เพิ่มชั้นเรียน</span></a>' : '';

require_once __DIR__ . '/includes/header.php';
?>

<section class="stat-grid mb-3">
  <article class="stat-card" style="--accent:#4f46e5;--accent-soft:#eef2ff;--i:0">
    <div class="stat-icon"><?= icon('building', 22) ?></div>
    <div class="stat-value num" data-count="<?= count($classes) ?>">0</div>
    <div class="stat-label">ชั้นเรียนทั้งหมด</div>
    <div class="stat-foot"><span class="stat-trend neutral"><?= icon('book', 12) ?> ปี <?= e(academic_year()) ?></span></div>
  </article>
  <article class="stat-card" style="--accent:#10b981;--accent-soft:#ecfdf5;--i:1">
    <div class="stat-icon"><?= icon('users', 22) ?></div>
    <div class="stat-value num" data-count="<?= (int) $totalStudents ?>">0</div>
    <div class="stat-label">นักเรียนที่กำลังศึกษา</div>
    <div class="stat-foot"><span class="stat-trend up"><?= icon('check-circle', 12) ?> ทุกชั้นเรียน</span></div>
  </article>
  <article class="stat-card" style="--accent:#0ea5e9;--accent-soft:#e0f2fe;--i:2">
    <div class="stat-icon"><?= icon('user', 22) ?></div>
    <div class="stat-value num" data-count="<?= count(array_filter($classes, fn($c) => $c['homeroom'] !== '')) ?>">0</div>
    <div class="stat-label">ชั้นเรียนที่มีครูประจำชั้น</div>
    <div class="stat-foot"><span class="stat-trend neutral"><?= icon('graduation', 12) ?> ดูแลใกล้ชิด</span></div>
  </article>
  <article class="stat-card" style="--accent:#f59e0b;--accent-soft:#fffbeb;--i:3">
    <div class="stat-icon"><?= icon('clock', 22) ?></div>
    <div class="stat-value num" data-count="<?= $totalStudents > 0 ? round($totalStudents / max(1, count($classes)), 1) : 0 ?>" data-decimals="1">0</div>
    <div class="stat-label">เฉลี่ยนักเรียนต่อห้อง</div>
    <div class="stat-foot"><span class="stat-trend neutral"><?= icon('chart', 12) ?> คน / ห้อง</span></div>
  </article>
</section>

<?php if ($showForm): ?>
<section class="card mb-3 animate-pop">
  <div class="card-head bordered">
    <div>
      <h3 class="card-title"><?= icon($form['id'] > 0 ? 'edit' : 'plus', 19) ?> <?= $form['id'] > 0 ? 'แก้ไขชั้นเรียน' : 'เพิ่มชั้นเรียนใหม่' ?></h3>
      <p class="card-sub">กำหนดชื่อห้อง ระดับชั้น ครูประจำชั้น และสถานะการเปิดสอน</p>
    </div>
    <div class="card-actions"><a class="btn btn-ghost btn-sm" href="<?= url('classes.php') ?>"><?= icon('x', 15) ?> ปิด</a></div>
  </div>
  <div class="card-body">
    <form method="post" action="<?= url('classes.php') ?>">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="save">
      <input type="hidden" name="id" value="<?= (int) $form['id'] ?>">
      <div class="form-grid">
        <div class="field">
          <label>ชื่อชั้นเรียน <span class="req">*</span></label>
          <input class="input <?= isset($errors['name']) ? 'is-invalid' : '' ?>" type="text" name="name" value="<?= e($form['name']) ?>" placeholder="เช่น ม.1/1" required>
          <?php if (isset($errors['name'])): ?><span class="field-error"><?= e($errors['name']) ?></span><?php endif; ?>
        </div>
        <div class="field">
          <label>ระดับชั้น</label>
          <input class="input" type="text" name="level" value="<?= e($form['level']) ?>" placeholder="เช่น มัธยมศึกษาปีที่ 1">
        </div>
        <div class="field">
          <label>ชื่อย่อระดับชั้น <span class="req">*</span></label>
          <input class="input <?= isset($errors['level_short']) ? 'is-invalid' : '' ?>" type="text" name="level_short" value="<?= e($form['level_short']) ?>" placeholder="เช่น ม.1" required>
          <?php if (isset($errors['level_short'])): ?><span class="field-error"><?= e($errors['level_short']) ?></span><?php endif; ?>
        </div>
        <div class="field">
          <label>ห้อง</label>
          <input class="input" type="text" name="room" value="<?= e($form['room']) ?>" placeholder="เช่น 1">
        </div>
        <div class="field span-2">
          <label>ครูประจำชั้น</label>
          <input class="input" type="text" name="homeroom" value="<?= e($form['homeroom']) ?>" placeholder="ชื่อ-สกุล ครูประจำชั้น">
        </div>
        <div class="field">
          <label>ปีการศึกษา</label>
          <input class="input <?= isset($errors['academic_year']) ? 'is-invalid' : '' ?>" type="text" name="academic_year" value="<?= e($form['academic_year']) ?>" maxlength="4">
          <?php if (isset($errors['academic_year'])): ?><span class="field-error"><?= e($errors['academic_year']) ?></span><?php endif; ?>
        </div>
        <div class="field">
          <label>สถานะ</label>
          <select class="select" name="status">
            <option value="active" <?= $form['status'] === 'active' ? 'selected' : '' ?>>เปิดสอน</option>
            <option value="inactive" <?= $form['status'] === 'inactive' ? 'selected' : '' ?>>ปิด / ไม่ใช้งาน</option>
          </select>
        </div>
      </div>
      <div class="form-actions">
        <button class="btn btn-primary" type="submit"><?= icon('save', 17) ?> บันทึกชั้นเรียน</button>
        <a class="btn btn-ghost" href="<?= url('classes.php') ?>">ยกเลิก</a>
      </div>
    </form>
  </div>
</section>
<?php endif; ?>

<div class="row-between mb-2 wrap">
  <div>
    <h2 style="font-size:1.1rem;font-weight:800;display:flex;align-items:center;gap:8px"><?= icon('building', 20) ?> ชั้นเรียนทั้งหมด</h2>
    <p class="text-sm text-muted"><?= count($classes) ?> ห้องเรียน · <?= number_format($totalStudents) ?> คน</p>
  </div>
  <div class="row">
    <span class="chip chip-soft"><span class="dot"></span>อัตรามาเรียน <?= e(month_label($month)) ?></span>
  </div>
</div>

<?php if ($classes): ?>
<div class="class-grid">
  <?php foreach ($classes as $i => $class): ?>
    <?php $rate = (int) $class['recorded'] > 0 ? (int) $class['attended'] / (int) $class['recorded'] * 100 : 0; ?>
    <article class="class-card" style="--i:<?= $i ?>">
      <div class="class-banner" style="--banner:<?= $banners[$i % count($banners)] ?>">
        <span class="level"><?= e($class['level'] ?: 'ระดับชั้น') ?></span>
        <h3><?= e($class['name']) ?></h3>
        <span class="room-pill"><?= icon('users', 12) ?> <?= (int) $class['students'] ?> คน · <?= e($class['academic_year']) ?></span>
      </div>
      <div class="class-body">
        <div class="class-homeroom"><?= icon('user', 15) ?><span><?= e($class['homeroom'] ?: 'ยังไม่กำหนดครูประจำชั้น') ?></span></div>
        <div class="class-stats">
          <div class="class-stat"><b><?= (int) $class['students'] ?></b><span>นักเรียน</span></div>
          <div class="class-stat"><b><?= number_format($rate, 1) ?>%</b><span>มาเรียนเดือนนี้</span></div>
        </div>
        <div class="meter <?= $rate >= 90 ? 'green' : ($rate >= 75 ? '' : 'amber') ?>"><span data-meter="<?= round($rate, 1) ?>"></span></div>
        <div class="class-actions">
          <a class="btn btn-ghost btn-sm" href="<?= url('students.php?class_id=' . (int) $class['id']) ?>"><?= icon('users', 14) ?> นักเรียน</a>
          <a class="btn btn-ghost btn-sm" href="<?= url('attendance-report.php?class_id=' . (int) $class['id']) ?>"><?= icon('chart', 14) ?> รายงาน</a>
          <?php if (can_manage()): ?>
            <a class="icon-btn" href="<?= url('classes.php?edit=' . (int) $class['id']) ?>" title="แก้ไข"><?= icon('edit', 15) ?></a>
            <form method="post" action="<?= url('classes.php') ?>" data-confirm="ต้องการลบชั้นเรียน <?= e($class['name']) ?> ใช่หรือไม่? นักเรียนจะถูกย้ายออกจากชั้นเรียนนี้">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="delete">
              <input type="hidden" name="class_id" value="<?= (int) $class['id'] ?>">
              <button class="icon-btn danger" type="submit" title="ลบ"><?= icon('trash', 15) ?></button>
            </form>
          <?php endif; ?>
        </div>
      </div>
    </article>
  <?php endforeach; ?>
</div>
<?php else: ?>
<div class="card">
  <div class="empty-state">
    <div class="empty-ico"><?= icon('building', 30) ?></div>
    <h3>ยังไม่มีชั้นเรียน</h3>
    <p>เริ่มต้นด้วยการเพิ่มห้องเรียนแรกของโรงเรียน</p>
    <?php if (can_manage()): ?><a class="btn btn-primary btn-sm" href="<?= url('classes.php?new=1') ?>"><?= icon('plus', 15) ?> เพิ่มชั้นเรียน</a><?php endif; ?>
  </div>
</div>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
