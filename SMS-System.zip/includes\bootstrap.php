<?php

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/auth.php';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

$school = [
    'name' => 'โรงเรียนสาธิตวิทยาการ',
    'name_en' => 'Satit Wittayakarn School',
    'affiliation' => 'สำนักงานคณะกรรมการการศึกษาขั้นพื้นฐาน',
    'area_office' => 'สำนักงานเขตพื้นที่การศึกษามัธยมศึกษา',
    'address' => '',
    'phone' => '',
    'email' => '',
    'website' => '',
    'director' => '',
    'academic_year' => (string) (date('Y') + 543),
    'semester' => 1,
];

try {
    $row = db()->query('SELECT * FROM school_info ORDER BY id LIMIT 1')->fetch();
    if ($row) {
        $school = array_merge($school, $row);
    }
} catch (Throwable $e) {
    // database.php already renders a friendly setup page
}

function school(string $key, string $default = ''): string
{
    global $school;
    return (string) ($school[$key] ?? $default);
}

function academic_year(): string
{
    global $school;
    return (string) ($school['academic_year'] ?? ((int) date('Y') + 543));
}

function academic_semester(): int
{
    global $school;
    return (int) ($school['semester'] ?? 1);
}
