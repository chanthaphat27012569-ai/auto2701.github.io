<?php

require_once __DIR__ . '/includes/bootstrap.php';

$user = require_staff();
$pdo = db();

$month = get_str('month');
if ($month === '' || !preg_match('/^\d{4}-\d{2}$/', $month)) {
    $latest = $pdo->query("SELECT DATE_FORMAT(MAX(att_date), '%Y-%m') FROM attendance")->fetchColumn();
    $month = $latest ?: date('Y-m');
}
$monthStart = $month . '-01';
$monthEnd = date('Y-m-t', strtotime($monthStart));

$classes = $pdo->query("SELECT id, name FROM classes WHERE status = 'active' ORDER BY name")->fetchAll();
$classId = get_int('class_id');
$classFilter = $classId > 0 ? 'AND s.class_id = ' . $classId : '';

$stmt = $pdo->prepare("SELECT s.id, s.student_code, s.prefix, s.firstname, s.lastname, s.student_number,
        c.name AS class_name, c.id AS class_id,
        COUNT(a.id) AS recorded,
        COALESCE(SUM(a.status = 'present'), 0) AS present,
        COALESCE(SUM(a.status = 'late'), 0) AS late,
        COALESCE(SUM(a.status = 'sick'), 0) AS sick,
        COALESCE(SUM(a.status = 'business'), 0) AS business,
        COALESCE(SUM(a.status = 'absent'), 0) AS absent,
        COALESCE(SUM(a.status = 'truant'), 0) AS truant
    FROM students s
    LEFT JOIN classes c ON c.id = s.class_id
    LEFT JOIN attendance a ON a.student_id = s.id AND a.att_date BETWEEN ? AND ?
    WHERE s.status = 'studying' $classFilter
    GROUP BY s.id, s.student_code, s.prefix, s.firstname, s.lastname, s.student_number, c.name, c.id
    ORDER BY c.name, s.student_number, s.student_code");
$stmt->execute([$monthStart, $monthEnd]);
$rows = $stmt->fetchAll();

$dayStmt = $pdo->prepare('SELECT COUNT(DISTINCT att_date) FROM attendance WHERE att_date BETWEEN ? AND ?' . ($classId > 0 ? ' AND class_id = ' . $classId : ''));
$dayStmt->execute([$monthStart, $monthEnd]);
$schoolDays = (int) $dayStmt->fetchColumn();

$dayRows = [];
$dailyStmt = $pdo->prepare("SELECT att_date, COUNT(*) AS total, SUM(status IN ('present','late')) AS attended
    FROM attendance WHERE att_date BETWEEN ? AND ?" . ($classId > 0 ? ' AND class_id = ' . $classId : '') . '
    GROUP BY att_date ORDER BY att_date');
$dailyStmt->execute([$monthStart, $monthEnd]);
foreach ($dailyStmt->fetchAll() as $day) {
    $dayRows[$day['att_date']] = [
        'total' => (int) $day['total'],
        'rate' => (int) $day['total'] > 0 ? (int) $day['attended'] / (int) $day['total'] * 100 : 0,
    ];
}

$totals = ['recorded' => 0, 'present' => 0, 'late' => 0, 'sick' => 0, 'business' => 0, 'absent' => 0, 'truant' => 0];
foreach ($rows as $row) {
    foreach ($totals as $key => $value) {
        $totals[$key] += (int) $row[$key];
    }
}
$overallRate = attendance_rate([
    'present' => $totals['present'],
    'late' => $totals['late'],
    'sick' => $totals['sick'],
    'business' => $totals['business'],
    'absent' => $totals['absent'],
    'truant' => $totals['truant'],
]);
$missing = $totals['absent'] + $totals['truant'];
$className = '';
foreach ($classes as $class) {
    if ((int) $class['id'] === $classId) {
        $className = $class['name'];
    }
}

if (get_str('export') === 'csv') {
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="attendance-' . $month . '.csv"');
    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF");
    fputcsv($out, ['รายงานเวลาเรียน', month_label($month), $className ?: 'ทุกชั้นเรียน']);
    fputcsv($out, ['เลขที่', 'รหัสนักเรียน', 'ชื่อ-สกุล', 'ชั้นเรียน', 'มาเรียน', 'มาสาย', 'ลาป่วย', 'ลากิจ', 'ขาดเรียน', 'หนีเรียน', 'บันทึกทั้งหมด', 'อัตรามาเรียน (%)']);
    foreach ($rows as $row) {
        $rate = ((int) $row['present'] + (int) $row['late']) > 0 && (int) $row['recorded'] > 0
            ? ((int) $row['present'] + (int) $row['late']) / (int) $row['recorded'] * 100 : 0;
        fputcsv($out, [
            (int) $row['student_number'],
            $row['student_code'],
            student_name($row),
            $row['class_name'],
            (int) $row['present'],
            (int) $row['late'],
            (int) $row['sick'],
            (int) $row['business'],
            (int) $row['absent'],
            (int) $row['truant'],
            (int) $row['recorded'],
            number_format($rate, 1),
        ]);
    }
    fputcsv($out, ['รวม', '', '', '', $totals['present'], $totals['late'], $totals['sick'], $totals['business'], $totals['absent'], $totals['truant'], $totals['recorded'], number_format($overallRate, 1)]);
    fclose($out);
    exit;
}

$query = array_filter(['month' => $month, 'class_id' => $classId ?: '']);
$pageTitle = 'รายงานเวลาเรียน';
$pageSubtitle = 'สรุปการมาเรียนรายเดือน รายชั้นเรียน และรายบุคคล';
$activeNav = 'attendance-report';
$pageActions = '<a class="btn btn-ghost btn-sm" href="' . url('attendance-report.php?' . http_build_query(array_merge($query, ['export' => 'csv']))) . '">' . icon('download', 16) . '<span>ส่งออก CSV</span></a>'
    . '<button class="btn btn-ghost btn-sm" type="button" data-print>' . icon('printer', 16) . '<span>พิมพ์</span></button>';

require_once __DIR__ . '/includes/header.php';
?>

<form class="toolbar no-print" method="get" action="<?= url('attendance-report.php') ?>">
  <div class="toolbar-left">
    <div class="field" style="min-width:160px">
      <label>เดือน</label>
      <input class="input" type="month" name="month" value="<?= e($month) ?>" max="<?= date('Y-m') ?>">
    </div>
    <div class="field" style="min-width:170px">
      <label>ชั้นเรียน</label>
      <select class="select" name="class_id">
        <option value="">ทุกชั้นเรียน</option>
        <?php foreach ($classes as $class): ?>
          <option value="<?= (int) $class['id'] ?>" <?= $classId === (int) $class['id'] ? 'selected' : '' ?>><?= e($class['name']) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <button class="btn btn-primary btn-sm" type="submit"><?= icon('filter', 15) ?> แสดงรายงาน</button>
    <a class="btn btn-ghost btn-sm" href="<?= url('attendance-report.php') ?>"><?= icon('refresh', 15) ?> ดูเดือนล่าสุด</a>
  </div>
</form>

<div class="report-head mb-2">
  <div>
    <span class="hero-eyebrow" style="background:var(--brand-soft);color:var(--brand);border-color:var(--brand-line)"><?= icon('chart', 14) ?> รายงานเวลาเรียน</span>
    <h2 style="font-size:1.35rem;font-weight:800;margin-top:8px"><?= e(month_label($month)) ?> · <?= e($className ?: 'ทุกชั้นเรียน') ?></h2>
    <p class="text-sm text-muted"><?= number_format(count($rows)) ?> คน · <?= $schoolDays ?> วันที่มีการเช็คชื่อ · <?= number_format($totals['recorded']) ?> ระเบียน</p>
  </div>
  <div class="profile-stats">
    <div class="profile-stat"><b><?= number_format($overallRate, 1) ?>%</b><span>อัตรามาเรียน</span></div>
    <div class="profile-stat"><b><?= number_format($totals['late']) ?></b><span>มาสาย</span></div>
    <div class="profile-stat"><b><?= number_format($missing) ?></b><span>ขาด/หนี</span></div>
  </div>
</div>

<section class="stat-grid mb-3 no-print">
  <article class="stat-card" style="--accent:#10b981;--accent-soft:#ecfdf5;--i:0">
    <div class="stat-icon"><?= icon('check', 22) ?></div>
    <div class="stat-value num" data-count="<?= $totals['present'] + $totals['late'] ?>">0</div>
    <div class="stat-label">มาเรียน / มาสาย</div>
    <div class="stat-foot"><span class="stat-trend up"><?= icon('trending', 12) ?><?= number_format($overallRate, 1) ?>%</span></div>
  </article>
  <article class="stat-card" style="--accent:#3b82f6;--accent-soft:#eff6ff;--i:1">
    <div class="stat-icon"><?= icon('calendar', 22) ?></div>
    <div class="stat-value num" data-count="<?= $schoolDays ?>">0</div>
    <div class="stat-label">วันที่มีการเช็คชื่อ</div>
    <div class="stat-foot"><span class="stat-trend neutral"><?= icon('clock', 12) ?> ภายในเดือน</span></div>
  </article>
  <article class="stat-card" style="--accent:#f59e0b;--accent-soft:#fffbeb;--i:2">
    <div class="stat-icon"><?= icon('clock', 22) ?></div>
    <div class="stat-value num" data-count="<?= $totals['late'] ?>">0</div>
    <div class="stat-label">มาสายสะสม</div>
    <div class="stat-foot"><span class="stat-trend neutral"><?= icon('alert', 12) ?> ควรติดตาม</span></div>
  </article>
  <article class="stat-card" style="--accent:#ef4444;--accent-soft:#fff1f2;--i:3">
    <div class="stat-icon"><?= icon('x-circle', 22) ?></div>
    <div class="stat-value num" data-count="<?= $missing ?>">0</div>
    <div class="stat-label">ขาดเรียน / หนีเรียน</div>
    <div class="stat-foot"><span class="stat-trend down"><?= icon('alert', 12) ?> ต้องติดตาม</span></div>
  </article>
</section>

<?php if ($dayRows): ?>
<section class="card mb-3 no-print">
  <div class="card-head">
    <div><h3 class="card-title"><?= icon('trending', 19) ?> แนวโน้มรายวัน</h3><p class="card-sub">อัตรามาเรียนของแต่ละวันในเดือนนี้</p></div>
    <div class="card-actions"><span class="badge badge-success"><span class="dot"></span>มาเรียน</span></div>
  </div>
  <div class="card-body">
    <div class="bars" style="height:150px">
      <?php $i = 0; foreach ($dayRows as $dayDate => $day): ?>
        <div class="bar-col">
          <span class="bar-value"><?= (int) $day['rate'] ?>%</span>
          <div class="bar-track"><div class="bar-fill" style="height:<?= max(4, (int) $day['rate']) ?>%;--i:<?= $i ?>"></div></div>
          <span class="bar-label"><?= (int) date('j', strtotime($dayDate)) ?></span>
        </div>
      <?php $i++; endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<div class="table-wrap">
  <table class="table">
    <thead>
      <tr>
        <th style="width:52px">เลขที่</th>
        <th>นักเรียน</th>
        <?php if ($classId <= 0): ?><th>ชั้นเรียน</th><?php endif; ?>
        <th class="text-center">ม</th>
        <th class="text-center">ส</th>
        <th class="text-center">ป</th>
        <th class="text-center">ก</th>
        <th class="text-center">ข</th>
        <th class="text-center">ห</th>
        <th style="min-width:150px">อัตรามาเรียน</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach ($rows as $row): ?>
      <?php $rate = (int) $row['recorded'] > 0 ? ((int) $row['present'] + (int) $row['late']) / (int) $row['recorded'] * 100 : 0; ?>
      <tr>
        <td class="text-muted num"><?= (int) $row['student_number'] ?></td>
        <td>
          <div class="cell-user">
            <span class="avatar sm <?= avatar_class($row['firstname']) ?>"><?= e(name_initials($row['firstname'], $row['lastname'])) ?></span>
            <div><b><?= e(student_name($row)) ?></b><small><?= e($row['student_code']) ?></small></div>
          </div>
        </td>
        <?php if ($classId <= 0): ?><td><span class="badge badge-brand"><?= e($row['class_name'] ?: '—') ?></span></td><?php endif; ?>
        <td class="text-center num" style="color:#059669;font-weight:700"><?= (int) $row['present'] ?></td>
        <td class="text-center num" style="color:#b45309;font-weight:700"><?= (int) $row['late'] ?></td>
        <td class="text-center num" style="color:#1d4ed8"><?= (int) $row['sick'] ?></td>
        <td class="text-center num" style="color:#6d28d9"><?= (int) $row['business'] ?></td>
        <td class="text-center num" style="color:#b91c1c;font-weight:700"><?= (int) $row['absent'] ?></td>
        <td class="text-center num" style="color:#9f1239;font-weight:700"><?= (int) $row['truant'] ?></td>
        <td>
          <div class="row" style="gap:8px">
            <div class="meter <?= $rate >= 90 ? 'green' : ($rate >= 75 ? '' : 'rose') ?>" style="flex:1"><span data-meter="<?= round($rate, 1) ?>"></span></div>
            <b class="num" style="font-size:.76rem;min-width:44px;text-align:right"><?= number_format($rate, 1) ?>%</b>
          </div>
        </td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$rows): ?>
      <tr><td colspan="<?= $classId > 0 ? 9 : 10 ?>"><div class="empty-state"><div class="empty-ico"><?= icon('chart', 30) ?></div><h3>ไม่พบข้อมูลในเดือนนี้</h3><p>ลองเลือกเดือนหรือชั้นเรียนอื่น</p></div></td></tr>
    <?php endif; ?>
    </tbody>
    <?php if ($rows): ?>
      <tfoot>
        <tr style="background:#f8faff;font-weight:800">
          <td colspan="<?= $classId > 0 ? 2 : 3 ?>" class="text-right">รวมทั้งสิ้น</td>
          <td class="text-center num"><?= $totals['present'] ?></td>
          <td class="text-center num"><?= $totals['late'] ?></td>
          <td class="text-center num"><?= $totals['sick'] ?></td>
          <td class="text-center num"><?= $totals['business'] ?></td>
          <td class="text-center num"><?= $totals['absent'] ?></td>
          <td class="text-center num"><?= $totals['truant'] ?></td>
          <td class="num"><?= number_format($overallRate, 1) ?>%</td>
        </tr>
      </tfoot>
    <?php endif; ?>
  </table>
</div>

<p class="text-xs text-muted mt-2"><?= icon('info', 13) ?> อัตรามาเรียนคำนวณจาก (มาเรียน + มาสาย) ÷ จำนวนครั้งที่บันทึก · ข้อมูล ณ วันที่ <?= e(thai_date(date('Y-m-d'))) ?></p>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
