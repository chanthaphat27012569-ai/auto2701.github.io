<?php

require_once __DIR__ . '/includes/bootstrap.php';

$pdo = db();
$staff = current_staff();
$studentSession = current_student();
if (!$staff && !$studentSession) {
    flash('warning', 'กรุณาเข้าสู่ระบบก่อนเปิดเอกสาร');
    redirect('login.php');
}

$id = get_int('id');
$stmt = $pdo->prepare('SELECT d.*, s.prefix, s.firstname, s.lastname, s.student_code, s.gender, s.birth_date, s.birth_place,
        s.nationality, s.religion, s.citizen_id, s.address, s.parent_name, s.parent_relation, s.parent_phone, s.status AS student_status,
        c.name AS class_name, c.level, c.level_short, c.room
    FROM documents d
    JOIN students s ON s.id = d.student_id
    LEFT JOIN classes c ON c.id = s.class_id
    WHERE d.id = ? LIMIT 1');
$stmt->execute([$id]);
$doc = $stmt->fetch();
if (!$doc) {
    if ($staff) {
        flash('danger', 'ไม่พบเอกสารที่ต้องการพิมพ์');
        redirect('documents.php');
    }
    http_response_code(404);
    exit('ไม่พบเอกสารที่ต้องการเปิด');
}
if (!$staff && (int) $studentSession['id'] !== (int) $doc['student_id']) {
    http_response_code(403);
    exit('คุณไม่มีสิทธิ์เปิดเอกสารของนักเรียนคนอื่น');
}

$grades = [];
$gStmt = $pdo->prepare('SELECT g.score, g.grade, sub.code, sub.name, sub.credits
    FROM grades g JOIN subjects sub ON sub.id = g.subject_id
    WHERE g.student_id = ? AND g.academic_year = ? AND g.semester = ?
    ORDER BY sub.code');
$gStmt->execute([(int) $doc['student_id'], $doc['academic_year'], (int) $doc['semester']]);
$grades = $gStmt->fetchAll();

$points = [];
$creditSum = 0.0;
foreach ($grades as $row) {
    if (is_numeric($row['grade'])) {
        $points[] = (float) $row['grade'];
        $creditSum += (float) $row['credits'];
    }
}
$gpa = $points ? array_sum($points) / count($points) : 0.0;

$aStmt = $pdo->prepare("SELECT COUNT(*) AS total,
        SUM(status = 'present') AS present, SUM(status = 'late') AS late, SUM(status = 'sick') AS sick,
        SUM(status = 'business') AS business, SUM(status = 'absent') AS absent, SUM(status = 'truant') AS truant
    FROM attendance WHERE student_id = ?");
$aStmt->execute([(int) $doc['student_id']]);
$att = $aStmt->fetch() ?: [];
$attTotal = (int) ($att['total'] ?? 0);
$attRate = $attTotal > 0 ? ((int) $att['present'] + (int) $att['late']) / $attTotal * 100 : 0;

$type = doc_type($doc['doc_type']);
$isLetter = in_array($doc['doc_type'], ['pp4', 'pp7', 'pp9'], true);
$fullname = student_name($doc);
$classText = $doc['class_name'] ?: ($doc['level_short'] ?: '—');
$studentStatusMeta = student_status_meta();
$studentStatus = $studentStatusMeta[$doc['student_status']] ?? $studentStatusMeta['studying'];
$schoolName = school('name', APP_TITLE);

if ($staff) {
    $pageTitle = 'พิมพ์ ' . $type['label'];
    $pageSubtitle = $doc['doc_no'] . ' · ' . $fullname;
    $activeNav = 'documents';
    $pageActions = '<button class="btn btn-primary btn-sm" type="button" data-print>' . icon('printer', 16) . '<span>พิมพ์เอกสาร</span></button>'
        . '<a class="btn btn-ghost btn-sm" href="' . url('documents.php') . '">' . icon('arrow-left', 16) . '<span>กลับ</span></a>';
    require_once __DIR__ . '/includes/header.php';
} else {
    ?>
<!DOCTYPE html>
<html lang="th">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($type['label']) ?> · <?= e($schoolName) ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Itim&family=Sarabun:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= url('assets/css/app.css') ?>?v=<?= APP_VERSION ?>">
</head>
<body class="portal-body">
<div class="bg-aurora" aria-hidden="true"><span class="aurora a1"></span><span class="aurora a2"></span><span class="aurora a3"></span></div>
<header class="portal-topbar no-print">
  <a class="portal-brand" href="<?= url('portal.php') ?>">
    <span class="brand-logo" style="width:42px;height:42px"><?= school_logo_svg(42) ?></span>
    <span><strong><?= e($schoolName) ?></strong><small>เอกสารทางการศึกษา</small></span>
  </a>
  <div class="portal-user">
    <a class="btn btn-ghost btn-sm" href="<?= url('portal.php') ?>"><?= icon('arrow-left', 15) ?> กลับพอร์ทัล</a>
    <a class="btn btn-ghost btn-sm" href="<?= url('logout.php') ?>"><?= icon('logout', 15) ?> ออกจากระบบ</a>
  </div>
</header>
<main class="portal-wrap" style="max-width:1000px">
<?php
}
?>

<div class="doc-toolbar no-print">
  <div class="row wrap">
    <span class="doc-badge"><?= e($type['label']) ?></span>
    <span class="text-sm text-muted"><?= e($type['name']) ?></span>
    <span class="chip chip-soft"><?= icon('file', 13) ?> <?= e($doc['doc_no']) ?></span>
    <span class="chip"><?= icon('calendar', 13) ?> <?= e(thai_date($doc['issued_at'], 'short')) ?></span>
  </div>
  <div class="row">
    <button class="btn btn-primary btn-sm" type="button" data-print><?= icon('printer', 16) ?> พิมพ์ / บันทึก PDF</button>
  </div>
</div>

<div class="doc-preview-wrap">
  <article class="doc-sheet">
    <span class="doc-watermark"><?= school_logo_svg(360) ?></span>

    <header class="doc-head">
      <div class="doc-head-side">
        <?= school_logo_svg(74, 'doc-logo') ?>
      </div>
      <div class="doc-head-main">
        <h1><?= e($schoolName) ?></h1>
        <p><?= e(school('name_en')) ?></p>
        <p><?= e(school('affiliation')) ?></p>
        <p><?= e(school('address')) ?><?= school('phone') ? ' · โทร. ' . e(school('phone')) : '' ?></p>
      </div>
      <div class="doc-head-side doc-head-meta">
        <span>เลขที่</span>
        <b><?= e($doc['doc_no']) ?></b>
        <span>วันที่ออก</span>
        <b><?= e(thai_date($doc['issued_at'])) ?></b>
      </div>
    </header>

    <div class="doc-title">
      <h2><?= e($type['name']) ?></h2>
      <span><?= e($type['label']) ?></span>
    </div>

    <?php if ($isLetter): ?>
      <div class="doc-letter">
        <p class="doc-lead">หนังสือฉบับนี้ให้ไว้เพื่อรับรองว่า</p>
        <div class="doc-person">
          <p><span>ชื่อ-สกุล</span><b><?= e($fullname) ?></b></p>
          <p><span>รหัสนักเรียน</span><b><?= e($doc['student_code']) ?></b></p>
          <p><span>ระดับชั้น</span><b><?= e($classText) ?></b></p>
          <p><span>สถานะ</span><b><?= e($studentStatus['label']) ?></b></p>
        </div>
        <?php if ($doc['doc_type'] === 'pp9'): ?>
          <p>เป็นผู้สำเร็จการศึกษาตามหลักสูตรสถานศึกษา ปีการศึกษา <?= e($doc['academic_year']) ?>
            และมีผลการเรียนเฉลี่ยสะสม (GPA) <b><?= number_format($gpa, 2) ?></b>
            รวม <?= number_format($creditSum, 1) ?> หน่วยกิต</p>
        <?php elseif ($doc['doc_type'] === 'pp7'): ?>
          <p>เป็นนักเรียนที่กำลังศึกษาอยู่ในสถานศึกษาแห่งนี้ ในปีการศึกษา <?= e($doc['academic_year']) ?> ภาคเรียนที่ <?= (int) $doc['semester'] ?>
            มีผลการเรียนเฉลี่ย <?= number_format($gpa, 2) ?> และมีอัตรามาเรียนร้อยละ <?= number_format($attRate, 1) ?></p>
        <?php else: ?>
          <p>เป็นนักเรียนที่กำลังศึกษาอยู่ในสถานศึกษาแห่งนี้ ชั้น <?= e($classText) ?> ปีการศึกษา <?= e($doc['academic_year']) ?>
            และเป็นผู้มีความประพฤติเรียบร้อยดี</p>
        <?php endif; ?>
        <p>จึงออกหนังสือรับรองฉบับนี้ไว้ให้เพื่อเป็นหลักฐาน</p>
        <p class="doc-note"><?= e($doc['note'] ?: '') ?></p>
      </div>

      <div class="doc-signs">
        <div class="doc-sign">
          <span class="doc-sign-line"></span>
          <b>(<?= e($doc['issued_by']) ?>)</b>
          <small>ผู้รับรอง / ผู้ออกเอกสาร</small>
        </div>
        <div class="doc-sign">
          <span class="doc-sign-line"></span>
          <b>(<?= e(school('director') ?: '—') ?>)</b>
          <small>ผู้อำนวยการสถานศึกษา</small>
        </div>
      </div>
      <p class="doc-date-right">ออกให้ ณ วันที่ <?= e(thai_date($doc['issued_at'], 'day')) ?></p>
    <?php else: ?>
      <section class="doc-block">
        <h3>ข้อมูลนักเรียน</h3>
        <table class="doc-table doc-info-table">
          <tbody>
            <tr><th>ชื่อ-สกุล</th><td><?= e($fullname) ?></td><th>รหัสนักเรียน</th><td><?= e($doc['student_code']) ?></td></tr>
            <tr><th>ระดับชั้น</th><td><?= e($classText) ?></td><th>เลขประจำตัวประชาชน</th><td><?= e($doc['citizen_id'] ?: '—') ?></td></tr>
            <tr><th>วันเกิด</th><td><?= e($doc['birth_date'] ? thai_date($doc['birth_date']) : '—') ?></td><th>ศาสนา</th><td><?= e($doc['religion'] ?: '—') ?></td></tr>
            <tr><th>ที่อยู่</th><td colspan="3"><?= e($doc['address'] ?: '—') ?></td></tr>
            <tr><th>ผู้ปกครอง</th><td><?= e($doc['parent_name'] ?: '—') ?><?= $doc['parent_relation'] ? ' (' . e($doc['parent_relation']) . ')' : '' ?></td><th>โทรศัพท์</th><td><?= e($doc['parent_phone'] ?: '—') ?></td></tr>
            <tr><th>สถานะ</th><td><?= e($studentStatus['label']) ?></td><th>ปีการศึกษา / ภาคเรียน</th><td><?= e($doc['academic_year']) ?> / <?= (int) $doc['semester'] ?></td></tr>
          </tbody>
        </table>
      </section>

      <section class="doc-block">
        <h3>ผลการเรียน <?= e($doc['doc_type'] === 'pp3' || $doc['doc_type'] === 'pp7' || $doc['doc_type'] === 'pp8' ? 'ประจำภาคเรียน' : '') ?> ปีการศึกษา <?= e($doc['academic_year']) ?> ภาคเรียนที่ <?= (int) $doc['semester'] ?></h3>
        <?php if ($grades): ?>
          <table class="doc-table doc-grade-table">
            <thead>
              <tr><th style="width:14%">รหัสวิชา</th><th>รายวิชา</th><th style="width:12%">หน่วยกิต</th><th style="width:14%">คะแนน</th><th style="width:12%">เกรด</th></tr>
            </thead>
            <tbody>
              <?php foreach ($grades as $grade): ?>
                <tr>
                  <td class="text-center"><?= e($grade['code']) ?></td>
                  <td><?= e($grade['name']) ?></td>
                  <td class="text-center"><?= number_format((float) $grade['credits'], 1) ?></td>
                  <td class="text-center"><?= $grade['score'] !== null ? number_format((float) $grade['score'], 1) : '—' ?></td>
                  <td class="text-center"><b><?= e($grade['grade'] ?: '—') ?></b></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
            <tfoot>
              <tr><td colspan="2" class="text-right">รวม <?= count($grades) ?> รายวิชา</td><td class="text-center"><?= number_format($creditSum, 1) ?></td><td colspan="2" class="text-center">GPA <?= number_format($gpa, 2) ?></td></tr>
            </tfoot>
          </table>
        <?php else: ?>
          <p class="doc-empty">ยังไม่มีผลการเรียนที่บันทึกไว้สำหรับภาคเรียนนี้</p>
        <?php endif; ?>
      </section>

      <section class="doc-block doc-summary-block">
        <h3>สรุปเวลาเรียน</h3>
        <table class="doc-table doc-letter-table">
          <tbody>
            <tr>
              <th>มาเรียน</th><td><?= number_format((int) ($att['present'] ?? 0)) ?></td>
              <th>มาสาย</th><td><?= number_format((int) ($att['late'] ?? 0)) ?></td>
              <th>ลาป่วย</th><td><?= number_format((int) ($att['sick'] ?? 0)) ?></td>
              <th>ลากิจ</th><td><?= number_format((int) ($att['business'] ?? 0)) ?></td>
              <th>ขาด/หนี</th><td><?= number_format((int) ($att['absent'] ?? 0) + (int) ($att['truant'] ?? 0)) ?></td>
            </tr>
            <tr>
              <th>รวมบันทึก</th><td><?= number_format($attTotal) ?> ครั้ง</td>
              <th>อัตรามาเรียน</th><td colspan="7"><b><?= number_format($attRate, 1) ?>%</b></td>
            </tr>
          </tbody>
        </table>
      </section>

      <div class="doc-signs">
        <div class="doc-sign">
          <span class="doc-sign-line"></span>
          <b>(<?= e($doc['issued_by']) ?>)</b>
          <small>ผู้จัดทำ / นายทะเบียน</small>
        </div>
        <div class="doc-sign">
          <span class="doc-sign-line"></span>
          <b>(<?= e(school('director') ?: '—') ?>)</b>
          <small>ผู้อำนวยการสถานศึกษา</small>
        </div>
      </div>
    <?php endif; ?>

    <footer class="doc-foot">
      <span>เอกสารฉบับนี้พิมพ์จากระบบ <?= e(APP_TITLE) ?></span>
      <span><?= e($doc['doc_no']) ?></span>
      <span>พิมพ์เมื่อ <?= e(thai_date(date('Y-m-d'), 'short')) ?></span>
    </footer>
  </article>
</div>

<?php if ($staff): ?>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
<?php else: ?>
<script>window.SMS = { base: <?= json_encode(BASE_URL) ?>, version: <?= json_encode(APP_VERSION) ?> };</script>
<script src="<?= url('assets/js/app.js') ?>?v=<?= APP_VERSION ?>"></script>
</main>
</body>
</html>
<?php endif; ?>
