-- ============================================================
-- SMS School · Student Portal Extension
-- Profile · timetable · subject attendance · activities ·
-- behavior · clubs · electives
-- Safe to import after database.sql or database-hosting.sql
-- ============================================================

SET NAMES utf8mb4;
SET time_zone = '+07:00';

CREATE TABLE IF NOT EXISTS `student_profiles` (
  `student_id` INT UNSIGNED NOT NULL,
  `avatar` VARCHAR(255) NOT NULL DEFAULT '',
  `portal_hash` VARCHAR(255) NOT NULL DEFAULT '',
  `nickname` VARCHAR(80) NOT NULL DEFAULT '',
  `prefix_en` VARCHAR(20) NOT NULL DEFAULT '',
  `firstname_en` VARCHAR(80) NOT NULL DEFAULT '',
  `lastname_en` VARCHAR(80) NOT NULL DEFAULT '',
  `phone` VARCHAR(30) NOT NULL DEFAULT '',
  `birth_province` VARCHAR(100) NOT NULL DEFAULT '',
  `ethnicity` VARCHAR(50) NOT NULL DEFAULT '',
  `parent_marital_status` VARCHAR(50) NOT NULL DEFAULT '',
  `brothers_older` TINYINT UNSIGNED NOT NULL DEFAULT 0,
  `sisters_older` TINYINT UNSIGNED NOT NULL DEFAULT 0,
  `brothers_younger` TINYINT UNSIGNED NOT NULL DEFAULT 0,
  `sisters_younger` TINYINT UNSIGNED NOT NULL DEFAULT 0,
  `birth_order` TINYINT UNSIGNED NOT NULL DEFAULT 0,
  `siblings_studying` TINYINT UNSIGNED NOT NULL DEFAULT 0,
  `father_citizen_id` VARCHAR(20) NOT NULL DEFAULT '',
  `father_prefix` VARCHAR(20) NOT NULL DEFAULT '',
  `father_firstname` VARCHAR(80) NOT NULL DEFAULT '',
  `father_lastname` VARCHAR(80) NOT NULL DEFAULT '',
  `father_occupation` VARCHAR(100) NOT NULL DEFAULT '',
  `father_income` DECIMAL(12,2) NOT NULL DEFAULT 0,
  `father_phone` VARCHAR(30) NOT NULL DEFAULT '',
  `mother_citizen_id` VARCHAR(20) NOT NULL DEFAULT '',
  `mother_prefix` VARCHAR(20) NOT NULL DEFAULT '',
  `mother_firstname` VARCHAR(80) NOT NULL DEFAULT '',
  `mother_lastname` VARCHAR(80) NOT NULL DEFAULT '',
  `mother_occupation` VARCHAR(100) NOT NULL DEFAULT '',
  `mother_income` DECIMAL(12,2) NOT NULL DEFAULT 0,
  `mother_phone` VARCHAR(30) NOT NULL DEFAULT '',
  `guardian_citizen_id` VARCHAR(20) NOT NULL DEFAULT '',
  `guardian_relation` VARCHAR(30) NOT NULL DEFAULT '',
  `plan` VARCHAR(100) NOT NULL DEFAULT '',
  `application_no` VARCHAR(30) NOT NULL DEFAULT '',
  `student_type` VARCHAR(50) NOT NULL DEFAULT '',
  `gpa` DECIMAL(3,2) NOT NULL DEFAULT 0,
  `gpax_p6` DECIMAL(3,2) NOT NULL DEFAULT 0,
  `gpax_junior` DECIMAL(3,2) NOT NULL DEFAULT 0,
  `registered_house_code` VARCHAR(30) NOT NULL DEFAULT '',
  `registered_house_no` VARCHAR(30) NOT NULL DEFAULT '',
  `registered_moo` VARCHAR(10) NOT NULL DEFAULT '',
  `registered_road` VARCHAR(120) NOT NULL DEFAULT '',
  `registered_subdistrict` VARCHAR(80) NOT NULL DEFAULT '',
  `registered_district` VARCHAR(80) NOT NULL DEFAULT '',
  `registered_province` VARCHAR(80) NOT NULL DEFAULT '',
  `registered_postcode` VARCHAR(10) NOT NULL DEFAULT '',
  `current_house_code` VARCHAR(30) NOT NULL DEFAULT '',
  `current_house_no` VARCHAR(30) NOT NULL DEFAULT '',
  `current_moo` VARCHAR(10) NOT NULL DEFAULT '',
  `current_road` VARCHAR(120) NOT NULL DEFAULT '',
  `current_subdistrict` VARCHAR(80) NOT NULL DEFAULT '',
  `current_district` VARCHAR(80) NOT NULL DEFAULT '',
  `current_province` VARCHAR(80) NOT NULL DEFAULT '',
  `current_postcode` VARCHAR(10) NOT NULL DEFAULT '',
  `weight` DECIMAL(5,1) NOT NULL DEFAULT 0,
  `height` DECIMAL(5,1) NOT NULL DEFAULT 0,
  `accommodation` VARCHAR(100) NOT NULL DEFAULT '',
  `travel_method` VARCHAR(100) NOT NULL DEFAULT '',
  `travel_minutes` SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  `distance_dirt` DECIMAL(5,1) NOT NULL DEFAULT 0,
  `distance_asphalt` DECIMAL(5,1) NOT NULL DEFAULT 0,
  `distance_water` DECIMAL(5,1) NOT NULL DEFAULT 0,
  `shortage_uniform` VARCHAR(20) NOT NULL DEFAULT '',
  `shortage_stationery` VARCHAR(20) NOT NULL DEFAULT '',
  `shortage_books` VARCHAR(20) NOT NULL DEFAULT '',
  `shortage_lunch` VARCHAR(20) NOT NULL DEFAULT '',
  `disability` VARCHAR(190) NOT NULL DEFAULT '',
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`student_id`),
  CONSTRAINT `fk_profiles_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `timetable` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `class_id` INT UNSIGNED NOT NULL,
  `day_of_week` TINYINT UNSIGNED NOT NULL DEFAULT 1,
  `period` TINYINT UNSIGNED NOT NULL DEFAULT 1,
  `subject_id` INT UNSIGNED NOT NULL,
  `start_time` TIME NOT NULL DEFAULT '08:30:00',
  `end_time` TIME NOT NULL DEFAULT '09:20:00',
  `room` VARCHAR(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_timetable_slot` (`class_id`,`day_of_week`,`period`),
  KEY `idx_timetable_subject` (`subject_id`),
  CONSTRAINT `fk_timetable_class` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_timetable_subject` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `subject_attendance` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `student_id` INT UNSIGNED NOT NULL,
  `class_id` INT UNSIGNED NULL,
  `subject_id` INT UNSIGNED NOT NULL,
  `att_date` DATE NOT NULL,
  `period` TINYINT UNSIGNED NOT NULL DEFAULT 1,
  `status` ENUM('present','late','sick','business','absent','truant') NOT NULL DEFAULT 'present',
  `note` VARCHAR(255) NOT NULL DEFAULT '',
  `recorded_by` INT UNSIGNED NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_subject_attendance` (`student_id`,`subject_id`,`att_date`,`period`),
  KEY `idx_subject_attendance_date` (`att_date`),
  KEY `idx_subject_attendance_class` (`class_id`,`att_date`),
  CONSTRAINT `fk_sa_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sa_class` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_sa_subject` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sa_user` FOREIGN KEY (`recorded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `behavior_records` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `student_id` INT UNSIGNED NOT NULL,
  `category` VARCHAR(100) NOT NULL DEFAULT 'ทั่วไป',
  `points` SMALLINT NOT NULL DEFAULT 0,
  `reason` VARCHAR(255) NOT NULL DEFAULT '',
  `recorded_by` INT UNSIGNED NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_behavior_student` (`student_id`,`created_at`),
  CONSTRAINT `fk_behavior_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_behavior_user` FOREIGN KEY (`recorded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `activities` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` VARCHAR(190) NOT NULL,
  `description` VARCHAR(255) NOT NULL DEFAULT '',
  `activity_date` DATE NOT NULL,
  `location` VARCHAR(120) NOT NULL DEFAULT '',
  `class_id` INT UNSIGNED NULL,
  `academic_year` VARCHAR(4) NOT NULL DEFAULT '',
  `semester` TINYINT UNSIGNED NOT NULL DEFAULT 1,
  `created_by` INT UNSIGNED NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_activities_date` (`activity_date`),
  CONSTRAINT `fk_activities_class` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_activities_user` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `activity_attendance` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `activity_id` INT UNSIGNED NOT NULL,
  `student_id` INT UNSIGNED NOT NULL,
  `status` ENUM('present','late','leave','absent','truant') NOT NULL DEFAULT 'present',
  `note` VARCHAR(255) NOT NULL DEFAULT '',
  `recorded_by` INT UNSIGNED NULL,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_activity_attendance` (`activity_id`,`student_id`),
  KEY `idx_activity_attendance_student` (`student_id`),
  CONSTRAINT `fk_aa_activity` FOREIGN KEY (`activity_id`) REFERENCES `activities` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_aa_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_aa_user` FOREIGN KEY (`recorded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `clubs` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `code` VARCHAR(20) NOT NULL,
  `name` VARCHAR(120) NOT NULL,
  `description` VARCHAR(255) NOT NULL DEFAULT '',
  `teacher_name` VARCHAR(120) NOT NULL DEFAULT '',
  `teacher_position` VARCHAR(120) NOT NULL DEFAULT '',
  `location` VARCHAR(120) NOT NULL DEFAULT '',
  `capacity` SMALLINT UNSIGNED NOT NULL DEFAULT 30,
  `academic_year` VARCHAR(4) NOT NULL DEFAULT '',
  `semester` TINYINT UNSIGNED NOT NULL DEFAULT 1,
  `status` ENUM('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_clubs_code` (`code`),
  KEY `idx_clubs_term` (`academic_year`,`semester`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `club_registrations` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `club_id` INT UNSIGNED NOT NULL,
  `student_id` INT UNSIGNED NOT NULL,
  `academic_year` VARCHAR(4) NOT NULL,
  `semester` TINYINT UNSIGNED NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_club_registration_term` (`student_id`,`academic_year`,`semester`),
  KEY `idx_club_registration_club` (`club_id`),
  CONSTRAINT `fk_cr_club` FOREIGN KEY (`club_id`) REFERENCES `clubs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cr_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `elective_registrations` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `subject_id` INT UNSIGNED NOT NULL,
  `student_id` INT UNSIGNED NOT NULL,
  `academic_year` VARCHAR(4) NOT NULL,
  `semester` TINYINT UNSIGNED NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_elective_registration_term` (`student_id`,`academic_year`,`semester`),
  KEY `idx_elective_registration_subject` (`subject_id`),
  CONSTRAINT `fk_er_subject` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_er_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Demo profile data
-- ------------------------------------------------------------
INSERT IGNORE INTO `student_profiles` (
  `student_id`, `nickname`, `phone`, `birth_province`, `ethnicity`, `parent_marital_status`,
  `brothers_older`, `sisters_older`, `brothers_younger`, `sisters_younger`, `birth_order`, `siblings_studying`,
  `father_citizen_id`, `father_prefix`, `father_firstname`, `father_lastname`, `father_occupation`, `father_income`, `father_phone`,
  `mother_citizen_id`, `mother_prefix`, `mother_firstname`, `mother_lastname`, `mother_occupation`, `mother_income`, `mother_phone`,
  `guardian_citizen_id`, `guardian_relation`, `plan`, `application_no`, `student_type`, `gpa`, `gpax_p6`, `gpax_junior`,
  `registered_house_no`, `registered_moo`, `registered_province`, `current_house_no`, `current_moo`, `current_province`,
  `weight`, `height`, `accommodation`, `travel_method`, `travel_minutes`,
  `shortage_uniform`, `shortage_stationery`, `shortage_books`, `shortage_lunch`, `disability`
)
SELECT s.id,
  s.firstname,
  COALESCE(NULLIF(s.guardian_phone, ''), s.parent_phone),
  s.birth_place,
  'ไทย',
  'อยู่ด้วยกัน',
  0, 0, 0, 0, 1, 0,
  '',
  CASE WHEN s.parent_relation = 'บิดา' THEN SUBSTRING_INDEX(s.parent_name, ' ', 1) ELSE '' END,
  CASE WHEN s.parent_relation = 'บิดา' THEN SUBSTRING_INDEX(s.parent_name, ' ', -1) ELSE '' END,
  '',
  'รับจ้าง',
  15000,
  s.parent_phone,
  '',
  CASE WHEN s.parent_relation = 'มารดา' THEN SUBSTRING_INDEX(s.parent_name, ' ', 1) ELSE '' END,
  CASE WHEN s.parent_relation = 'มารดา' THEN SUBSTRING_INDEX(s.parent_name, ' ', -1) ELSE '' END,
  '',
  'ค้าขาย',
  12000,
  s.parent_phone,
  '',
  s.parent_relation,
  'วิทยาศาสตร์-คณิตศาสตร์',
  CONCAT('69', LPAD(s.id, 4, '0')),
  'ปกติ',
  3.25, 3.12, 3.05,
  '',
  '',
  s.birth_place,
  '',
  '',
  s.birth_place,
  45 + (s.id % 9),
  152 + (s.id % 18),
  'บ้านของบิดามารดา',
  'รถโดยสารประจำทาง',
  25,
  'ไม่ขาดแคลน', 'ไม่ขาดแคลน', 'ไม่ขาดแคลน', 'ไม่ขาดแคลน',
  ''
FROM `students` s;

-- ------------------------------------------------------------
-- Timetable (Mon-Fri, 8 periods, rotating subjects)
-- ------------------------------------------------------------
INSERT IGNORE INTO `timetable` (`class_id`, `day_of_week`, `period`, `subject_id`, `start_time`, `end_time`, `room`)
SELECT c.id, d.n, p.n, s.id,
  CASE p.n WHEN 1 THEN '08:30:00' WHEN 2 THEN '09:20:00' WHEN 3 THEN '10:20:00' WHEN 4 THEN '11:10:00'
           WHEN 5 THEN '13:00:00' WHEN 6 THEN '13:50:00' WHEN 7 THEN '14:50:00' ELSE '15:40:00' END,
  CASE p.n WHEN 1 THEN '09:20:00' WHEN 2 THEN '10:10:00' WHEN 3 THEN '11:10:00' WHEN 4 THEN '12:00:00'
           WHEN 5 THEN '13:50:00' WHEN 6 THEN '14:40:00' WHEN 7 THEN '15:40:00' ELSE '16:30:00' END,
  CONCAT('ห้อง ', c.room)
FROM `classes` c
JOIN (SELECT 1 AS n UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL SELECT 5) d
JOIN (SELECT 1 AS n UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4
      UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8) p
JOIN `subjects` s ON s.id = ((c.id + d.n + p.n - 2) % 8) + 1
WHERE c.status = 'active';

-- ------------------------------------------------------------
-- Today's flag attendance and subject attendance
-- ------------------------------------------------------------
INSERT IGNORE INTO `attendance` (`student_id`, `class_id`, `att_date`, `status`, `note`, `recorded_by`)
SELECT s.id, s.class_id, CURDATE(),
  CASE
    WHEN s.id % 19 = 0 THEN 'sick'
    WHEN s.id % 13 = 0 THEN 'late'
    WHEN s.id % 23 = 0 THEN 'business'
    ELSE 'present'
  END,
  '', 1
FROM `students` s
WHERE s.class_id IS NOT NULL AND s.status = 'studying';

INSERT IGNORE INTO `subject_attendance` (`student_id`, `class_id`, `subject_id`, `att_date`, `period`, `status`, `note`, `recorded_by`)
SELECT s.id, s.class_id, t.subject_id, CURDATE(), t.period,
  CASE
    WHEN (s.id + t.period) % 17 = 0 THEN 'absent'
    WHEN (s.id + t.period) % 11 = 0 THEN 'late'
    WHEN (s.id + t.period) % 29 = 0 THEN 'business'
    ELSE 'present'
  END,
  '', 1
FROM `students` s
JOIN `timetable` t ON t.class_id = s.class_id
  AND t.day_of_week = CASE WHEN WEEKDAY(CURDATE()) < 5 THEN WEEKDAY(CURDATE()) + 1 ELSE 1 END
WHERE s.class_id IS NOT NULL AND s.status = 'studying' AND t.period <= 4;

-- ------------------------------------------------------------
-- Behavior records
-- ------------------------------------------------------------
INSERT INTO `behavior_records` (`student_id`, `category`, `points`, `reason`, `recorded_by`, `created_at`)
SELECT s.id, 'วินัย', 5, 'แต่งกายถูกระเบียบและมีวินัยดี', 1, DATE_SUB(NOW(), INTERVAL 9 DAY)
FROM `students` s
WHERE NOT EXISTS (SELECT 1 FROM `behavior_records` b WHERE b.student_id = s.id);

INSERT INTO `behavior_records` (`student_id`, `category`, `points`, `reason`, `recorded_by`, `created_at`)
SELECT s.id, 'การเรียน', -2, 'ส่งงานไม่ตรงเวลา', 1, DATE_SUB(NOW(), INTERVAL 4 DAY)
FROM `students` s
WHERE NOT EXISTS (SELECT 1 FROM `behavior_records` b WHERE b.student_id = s.id AND b.points < 0);

INSERT INTO `behavior_records` (`student_id`, `category`, `points`, `reason`, `recorded_by`, `created_at`)
SELECT s.id, 'จิตอาสา', 8, 'ร่วมกิจกรรมบำเพ็ญประโยชน์ของโรงเรียน', 1, DATE_SUB(NOW(), INTERVAL 1 DAY)
FROM `students` s
WHERE s.id <= 12
  AND NOT EXISTS (SELECT 1 FROM `behavior_records` b WHERE b.student_id = s.id AND b.category = 'จิตอาสา');

-- ------------------------------------------------------------
-- Activities and participation
-- ------------------------------------------------------------
INSERT INTO `activities` (`title`, `description`, `activity_date`, `location`, `academic_year`, `semester`, `created_by`)
SELECT 'กิจกรรมหน้าเสาธง', 'เข้าแถวเคารพธงชาติและกิจกรรมสร้างสรรค์', DATE_SUB(CURDATE(), INTERVAL 14 DAY), 'ลานหน้าเสาธง',
  si.academic_year, si.semester, 1
FROM `school_info` si
WHERE NOT EXISTS (SELECT 1 FROM `activities` a WHERE a.title = 'กิจกรรมหน้าเสาธง');

INSERT INTO `activities` (`title`, `description`, `activity_date`, `location`, `academic_year`, `semester`, `created_by`)
SELECT 'วันวิทยาศาสตร์แห่งชาติ', 'นิทรรศการและกิจกรรมทดลองวิทยาศาสตร์', DATE_SUB(CURDATE(), INTERVAL 7 DAY), 'อาคารวิทยาศาสตร์',
  si.academic_year, si.semester, 1
FROM `school_info` si
WHERE NOT EXISTS (SELECT 1 FROM `activities` a WHERE a.title = 'วันวิทยาศาสตร์แห่งชาติ');

INSERT INTO `activities` (`title`, `description`, `activity_date`, `location`, `academic_year`, `semester`, `created_by`)
SELECT 'ปลูกต้นไม้เพิ่มพื้นที่สีเขียว', 'กิจกรรมจิตอาสาและอนุรักษ์สิ่งแวดล้อม', DATE_SUB(CURDATE(), INTERVAL 3 DAY), 'บริเวณโรงเรียน',
  si.academic_year, si.semester, 1
FROM `school_info` si
WHERE NOT EXISTS (SELECT 1 FROM `activities` a WHERE a.title = 'ปลูกต้นไม้เพิ่มพื้นที่สีเขียว');

INSERT INTO `activities` (`title`, `description`, `activity_date`, `location`, `academic_year`, `semester`, `created_by`)
SELECT 'อบรมความปลอดภัยทางถนน', 'ให้ความรู้เรื่องวินัยจราจรและความปลอดภัย', DATE_SUB(CURDATE(), INTERVAL 1 DAY), 'หอประชุมโรงเรียน',
  si.academic_year, si.semester, 1
FROM `school_info` si
WHERE NOT EXISTS (SELECT 1 FROM `activities` a WHERE a.title = 'อบรมความปลอดภัยทางถนน');

INSERT INTO `activities` (`title`, `description`, `activity_date`, `location`, `academic_year`, `semester`, `created_by`)
SELECT 'กิจกรรมชุมนุมครั้งที่ 1', 'พบครูที่ปรึกษาชุมนุมและวางแผนกิจกรรมภาคเรียน', CURDATE(), 'ห้องเรียนชุมนุม',
  si.academic_year, si.semester, 1
FROM `school_info` si
WHERE NOT EXISTS (SELECT 1 FROM `activities` a WHERE a.title = 'กิจกรรมชุมนุมครั้งที่ 1');

INSERT IGNORE INTO `activity_attendance` (`activity_id`, `student_id`, `status`, `note`, `recorded_by`, `updated_at`)
SELECT a.id, s.id,
  CASE
    WHEN (s.id + a.id) % 23 = 0 THEN 'absent'
    WHEN (s.id + a.id) % 17 = 0 THEN 'leave'
    WHEN (s.id + a.id) % 13 = 0 THEN 'late'
    WHEN (s.id + a.id) % 31 = 0 THEN 'truant'
    ELSE 'present'
  END,
  '', 1, DATE_ADD(a.activity_date, INTERVAL 1 DAY)
FROM `activities` a
JOIN `students` s ON s.class_id IS NOT NULL AND s.status = 'studying'
WHERE a.activity_date < CURDATE();

-- ------------------------------------------------------------
-- Clubs
-- ------------------------------------------------------------
INSERT IGNORE INTO `clubs` (`code`, `name`, `description`, `teacher_name`, `teacher_position`, `location`, `capacity`, `academic_year`, `semester`, `status`)
SELECT 'CLUB01', 'E-Sport', 'เรียนรู้การวางแผนเกม การทำงานเป็นทีม และการแข่งขันอีสปอร์ตอย่างสร้างสรรค์',
  'ดร.วรากร อินทนนท์', 'ครูชำนาญการ', 'ห้องคอมพิวเตอร์ 2', 30, si.academic_year, si.semester, 'active' FROM `school_info` si
WHERE NOT EXISTS (SELECT 1 FROM `clubs` WHERE `code` = 'CLUB01');
INSERT IGNORE INTO `clubs` (`code`, `name`, `description`, `teacher_name`, `teacher_position`, `location`, `capacity`, `academic_year`, `semester`, `status`)
SELECT 'CLUB02', 'ดนตรีสากล', 'ฝึกทักษะเครื่องดนตรี การร้องเพลง และการแสดงบนเวที',
  'นางสาวกานดา เมตตา', 'ครู คศ.2', 'ห้องดนตรี', 28, si.academic_year, si.semester, 'active' FROM `school_info` si
WHERE NOT EXISTS (SELECT 1 FROM `clubs` WHERE `code` = 'CLUB02');
INSERT IGNORE INTO `clubs` (`code`, `name`, `description`, `teacher_name`, `teacher_position`, `location`, `capacity`, `academic_year`, `semester`, `status`)
SELECT 'CLUB03', 'วิทยาศาสตร์สร้างสรรค์', 'ทดลองและสร้างโครงงานวิทยาศาสตร์เพื่อแข่งขัน',
  'นางสุนีย์ ใจดี', 'ครูชำนาญการพิเศษ', 'ห้องปฏิบัติการวิทยาศาสตร์', 32, si.academic_year, si.semester, 'active' FROM `school_info` si
WHERE NOT EXISTS (SELECT 1 FROM `clubs` WHERE `code` = 'CLUB03');
INSERT IGNORE INTO `clubs` (`code`, `name`, `description`, `teacher_name`, `teacher_position`, `location`, `capacity`, `academic_year`, `semester`, `status`)
SELECT 'CLUB04', 'ภาษาอังกฤษเพื่อการสื่อสาร', 'ฝึกสนทนา การนำเสนอ และกิจกรรมภาษาอังกฤษ',
  'Mr. John Smith', 'Teacher', 'ห้อง 204', 30, si.academic_year, si.semester, 'active' FROM `school_info` si
WHERE NOT EXISTS (SELECT 1 FROM `clubs` WHERE `code` = 'CLUB04');
INSERT IGNORE INTO `clubs` (`code`, `name`, `description`, `teacher_name`, `teacher_position`, `location`, `capacity`, `academic_year`, `semester`, `status`)
SELECT 'CLUB05', 'กีฬาและนันทนาการ', 'ส่งเสริมสุขภาพและทักษะกีฬาหลากหลายประเภท',
  'นายปิยะ ดูแลดี', 'เจ้าหน้าที่ฝ่ายกิจการนักเรียน', 'สนามกีฬาโรงเรียน', 40, si.academic_year, si.semester, 'active' FROM `school_info` si
WHERE NOT EXISTS (SELECT 1 FROM `clubs` WHERE `code` = 'CLUB05');
INSERT IGNORE INTO `clubs` (`code`, `name`, `description`, `teacher_name`, `teacher_position`, `location`, `capacity`, `academic_year`, `semester`, `status`)
SELECT 'CLUB06', 'ศิลปะและงานฝีมือ', 'สร้างสรรค์งานศิลปะ งานประดิษฐ์ และจัดแสดงผลงาน',
  'นางสาวกานดา เมตตา', 'ครู คศ.2', 'ห้องศิลปะ', 26, si.academic_year, si.semester, 'active' FROM `school_info` si
WHERE NOT EXISTS (SELECT 1 FROM `clubs` WHERE `code` = 'CLUB06');

INSERT IGNORE INTO `club_registrations` (`club_id`, `student_id`, `academic_year`, `semester`)
SELECT c.id, s.id, c.academic_year, c.semester
FROM `clubs` c
JOIN `students` s ON s.student_code = '1001'
WHERE c.code = 'CLUB01';

-- ------------------------------------------------------------
-- Elective subjects and registration
-- ------------------------------------------------------------
INSERT IGNORE INTO `subjects` (`code`, `name`, `category`, `department`, `hours`, `credits`, `status`) VALUES
('ท20208', 'ภาษาสร้างสรรค์', 'วิชาเพิ่มเติม', 'ภาษาไทย', 40, 1.0, 'active'),
('ศ20203', 'ดนตรีสากลเบื้องต้น', 'วิชาเพิ่มเติม', 'ศิลปะ', 40, 1.0, 'active'),
('อ20205', 'ภาษาอังกฤษเพื่อการสื่อสาร', 'วิชาเพิ่มเติม', 'ภาษาต่างประเทศ', 40, 1.0, 'active'),
('ว20207', 'หุ่นยนต์และโค้ดดิ้ง', 'วิชาเพิ่มเติม', 'วิทยาศาสตร์และเทคโนโลยี', 40, 1.0, 'active'),
('ง20201', 'งานช่างพื้นฐานสร้างสรรค์', 'วิชาเพิ่มเติม', 'การงานอาชีพ', 40, 1.0, 'active');

INSERT IGNORE INTO `elective_registrations` (`subject_id`, `student_id`, `academic_year`, `semester`)
SELECT sub.id, s.id, si.academic_year, si.semester
FROM `subjects` sub
JOIN `students` s ON s.student_code = '1001'
JOIN `school_info` si
WHERE sub.code = 'ท20208';
