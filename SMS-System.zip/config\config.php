<?php

define('APP_NAME', 'SMS School');
define('APP_TITLE', 'ระบบบริหารจัดการสถานศึกษา');
define('APP_VERSION', '5.0.0');

// Windows/XAMPP = เครื่องทดสอบในเครื่อง, Linux = โฮสต์จริง
$smsHost = $_SERVER['HTTP_HOST'] ?? $_SERVER['SERVER_NAME'] ?? '';
$smsLocal = DIRECTORY_SEPARATOR === '\\' || preg_match('/^(localhost|127\.0\.0\.1|\[::1\])(:\d+)?$/i', $smsHost) === 1;

define('DB_HOST', getenv('SMS_DB_HOST') ?: ($smsLocal ? '127.0.0.1' : 'sql106.ezyro.com'));
define('DB_PORT', getenv('SMS_DB_PORT') ?: '3306');
define('DB_NAME', getenv('SMS_DB_NAME') ?: ($smsLocal ? 'sms_school' : 'ezyro_43312596_auto96'));
define('DB_USER', getenv('SMS_DB_USER') ?: ($smsLocal ? 'root' : 'ezyro_43312596'));
define('DB_PASS', getenv('SMS_DB_PASS') ?: ($smsLocal ? '' : 'cb103559c8242d6'));

date_default_timezone_set('Asia/Bangkok');

if (!defined('BASE_URL')) {
    $script = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '/');
    $dir = rtrim(str_replace('\\', '/', dirname($script)), '/');
    define('BASE_URL', $dir === '/' ? '' : $dir);
}
