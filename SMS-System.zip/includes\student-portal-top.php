<?php
$flashes = pull_flashes();
$portalNav = [
    'home'       => ['portal.php', 'หน้าหลัก', 'home'],
    'profile'    => ['student-profile.php', 'ข้อมูลส่วนตัว', 'user'],
    'attendance' => ['student-attendance.php', 'ประวัติเช็คชื่อ', 'check'],
    'activities' => ['student-activities.php', 'กิจกรรม', 'star'],
    'behavior'   => ['student-behavior.php', 'คะแนนพฤติกรรม', 'award'],
    'clubs'      => ['student-clubs.php', 'ชุมนุม', 'users'],
    'electives'  => ['student-electives.php', 'วิชาเพิ่มเติม', 'book'],
    'grades'     => ['portal.php#tab-grades', 'ผลการเรียน', 'chart'],
    'documents'  => ['portal.php#tab-documents', 'เอกสาร', 'file'],
    'password'   => ['student-password.php', 'เปลี่ยนรหัสผ่าน', 'key'],
];
$previewPage = basename((string) ($_SERVER['SCRIPT_NAME'] ?? 'portal.php'));
?>
<!DOCTYPE html>
<html lang="th">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="theme-color" content="#4f46e5">
<title><?= e($pageTitle) ?> · <?= e($school['name']) ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Itim&family=Sarabun:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,400;1,700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= url('assets/css/app.css') ?>?v=<?= APP_VERSION ?>">
</head>
<body class="portal-body">
<a class="skip-link" href="#portalMain">ข้ามไปยังเนื้อหาหลัก</a>
<div class="page-progress" id="pageProgress"></div>
<div class="bg-aurora" aria-hidden="true"><span class="aurora a1"></span><span class="aurora a2"></span><span class="aurora a3"></span></div>

<header class="portal-topbar">
  <a class="portal-brand" href="<?= e(portal_url('portal.php')) ?>">
    <span class="brand-logo" style="width:42px;height:42px"><?= school_logo_svg(42) ?></span>
    <span><strong><?= e($school['name']) ?></strong><small>พอร์ทัลนักเรียน · ผู้ปกครอง</small></span>
  </a>
  <div class="portal-user">
    <div class="portal-identity">
      <?= student_avatar($student, 'sm') ?>
      <span class="portal-identity-text">
        <strong><?= e(student_name($student, false)) ?></strong>
        <small><?= e($classText ?: '—') ?> · <?= e($student['student_code']) ?></small>
      </span>
    </div>
    <a class="btn btn-ghost btn-sm" href="<?= url('logout.php') ?>"><?= icon('logout', 15) ?> <span class="hide-sm">ออกจากระบบ</span></a>
  </div>
</header>

<nav class="portal-menubar" aria-label="เมนูพอร์ทัลนักเรียน">
  <div class="portal-nav">
    <?php foreach ($portalNav as $key => $item): ?>
      <a class="<?= $portalActive === $key ? 'is-active' : '' ?>" href="<?= e(portal_url($item[0])) ?>">
        <?= icon($item[2], 15) ?><span><?= e($item[1]) ?></span>
      </a>
    <?php endforeach; ?>
  </div>
</nav>

<?php if ($isPreview): ?>
<div class="portal-preview">
  <div class="portal-wrap portal-preview-inner">
    <div class="notice notice-info" style="flex:1">
      <?= icon('eye', 18) ?>
      <div><strong>โหมดตัวอย่างสำหรับเจ้าหน้าที่</strong> กำลังดูพอร์ทัลในนามของ <?= e(student_name($student)) ?> — การแก้ไขและลงทะเบียนถูกปิดใช้งาน</div>
    </div>
    <form method="get" action="<?= url($previewPage) ?>" class="portal-preview-switch">
      <select class="select" name="student" data-auto-submit aria-label="เลือกนักเรียน">
        <?php foreach ($previewStudents as $previewStudent): ?>
          <option value="<?= (int) $previewStudent['id'] ?>" <?= (int) $previewStudent['id'] === (int) $student['id'] ? 'selected' : '' ?>>
            <?= e($previewStudent['student_code'] . ' · ' . student_name($previewStudent, false)) ?>
          </option>
        <?php endforeach; ?>
      </select>
      <a class="btn btn-ghost btn-sm" href="<?= url('dashboard.php') ?>"><?= icon('arrow-left', 15) ?> กลับระบบ</a>
    </form>
  </div>
</div>
<?php endif; ?>

<main class="portal-wrap" id="portalMain">
