<?php

require_once __DIR__ . '/includes/bootstrap.php';

require_admin();
$user = require_staff();
$pdo = db();

$errors = [];
$form = [
    'name' => $school['name'],
    'name_en' => $school['name_en'],
    'affiliation' => $school['affiliation'],
    'area_office' => $school['area_office'],
    'address' => $school['address'],
    'phone' => $school['phone'],
    'email' => $school['email'],
    'website' => $school['website'],
    'director' => $school['director'],
    'academic_year' => $school['academic_year'],
    'semester' => (int) $school['semester'],
];

if (is_post()) {
    verify_csrf();
    $action = post_str('action');

    if ($action === 'save_school') {
        foreach (['name', 'name_en', 'affiliation', 'area_office', 'address', 'phone', 'email', 'website', 'director', 'academic_year'] as $key) {
            $form[$key] = post_str($key);
        }
        $form['semester'] = (int) ($_POST['semester'] ?? 0);

        if ($form['name'] === '') {
            $errors['name'] = 'กรุณากรอกชื่อสถานศึกษา';
        }
        if (!preg_match('/^\d{4}$/', $form['academic_year'])) {
            $errors['academic_year'] = 'ปีการศึกษาต้องเป็นตัวเลข 4 หลัก';
        }
        if (!in_array($form['semester'], [1, 2], true)) {
            $errors['semester'] = 'กรุณาเลือกภาคเรียน';
        }
        if (!$errors) {
            $stmt = $pdo->prepare('UPDATE school_info SET name=?, name_en=?, affiliation=?, area_office=?, address=?, phone=?, email=?, website=?, director=?, academic_year=?, semester=? WHERE id = 1');
            $stmt->execute([$form['name'], $form['name_en'], $form['affiliation'], $form['area_office'], $form['address'], $form['phone'], $form['email'], $form['website'], $form['director'], $form['academic_year'], $form['semester']]);
            flash('success', 'บันทึกข้อมูลสถานศึกษาและปีการศึกษาเรียบร้อยแล้ว');
            redirect('settings.php');
        }
    }

    if ($action === 'change_password') {
        $current = post_str('current_password');
        $new = post_str('new_password');
        $confirm = post_str('confirm_password');
        $stmt = $pdo->prepare('SELECT password_hash FROM users WHERE id = ?');
        $stmt->execute([(int) $user['id']]);
        $hash = (string) $stmt->fetchColumn();

        if (!password_verify($current, $hash)) {
            $errors['current_password'] = 'รหัสผ่านปัจจุบันไม่ถูกต้อง';
        }
        if (mb_strlen($new) < 4) {
            $errors['new_password'] = 'รหัสผ่านใหม่ต้องมีอย่างน้อย 4 ตัวอักษร';
        }
        if ($new !== $confirm) {
            $errors['confirm_password'] = 'รหัสผ่านใหม่ทั้งสองช่องไม่ตรงกัน';
        }
        if (!$errors) {
            $update = $pdo->prepare('UPDATE users SET password_hash = ? WHERE id = ?');
            $update->execute([password_hash($new, PASSWORD_DEFAULT), (int) $user['id']]);
            flash('success', 'เปลี่ยนรหัสผ่านของคุณเรียบร้อยแล้ว');
            redirect('settings.php');
        }
    }
}

$counts = [
    'students' => (int) $pdo->query("SELECT COUNT(*) FROM students WHERE status = 'studying'")->fetchColumn(),
    'classes' => (int) $pdo->query("SELECT COUNT(*) FROM classes WHERE status = 'active'")->fetchColumn(),
    'subjects' => (int) $pdo->query("SELECT COUNT(*) FROM subjects WHERE status = 'active'")->fetchColumn(),
    'documents' => (int) $pdo->query('SELECT COUNT(*) FROM documents')->fetchColumn(),
    'attendance' => (int) $pdo->query('SELECT COUNT(*) FROM attendance')->fetchColumn(),
    'grades' => (int) $pdo->query('SELECT COUNT(*) FROM grades')->fetchColumn(),
];

$pageTitle = 'ตั้งค่าระบบ';
$pageSubtitle = 'ข้อมูลสถานศึกษา ปีการศึกษา และความปลอดภัยของบัญชี';
$activeNav = 'settings';
$pageActions = '';

require_once __DIR__ . '/includes/header.php';
?>

<div class="grid grid-2-1">
  <div class="stack">
    <section class="card">
      <div class="card-head bordered">
        <div>
          <h3 class="card-title"><?= icon('building', 19) ?> ข้อมูลสถานศึกษา</h3>
          <p class="card-sub">ข้อมูลนี้จะแสดงบนหน้าหลัก เอกสาร ปพ. และพอร์ทัลนักเรียน</p>
        </div>
        <div class="card-actions"><span class="badge badge-brand"><?= icon('shield', 12) ?> ผู้ดูแลระบบ</span></div>
      </div>
      <div class="card-body">
        <form method="post" action="<?= url('settings.php') ?>">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="save_school">
          <div class="form-grid">
            <div class="field span-2">
              <label>ชื่อสถานศึกษา (ภาษาไทย) <span class="req">*</span></label>
              <input class="input <?= isset($errors['name']) ? 'is-invalid' : '' ?>" type="text" name="name" value="<?= e($form['name']) ?>" required>
              <?php if (isset($errors['name'])): ?><span class="field-error"><?= e($errors['name']) ?></span><?php endif; ?>
            </div>
            <div class="field span-2">
              <label>ชื่อสถานศึกษา (ภาษาอังกฤษ)</label>
              <input class="input" type="text" name="name_en" value="<?= e($form['name_en']) ?>">
            </div>
            <div class="field">
              <label>สังกัด</label>
              <input class="input" type="text" name="affiliation" value="<?= e($form['affiliation']) ?>">
            </div>
            <div class="field">
              <label>สำนักงานเขตพื้นที่การศึกษา</label>
              <input class="input" type="text" name="area_office" value="<?= e($form['area_office']) ?>">
            </div>
            <div class="field span-2">
              <label>ที่อยู่</label>
              <textarea class="textarea" name="address" rows="2"><?= e($form['address']) ?></textarea>
            </div>
            <div class="field">
              <label>โทรศัพท์</label>
              <input class="input" type="tel" name="phone" value="<?= e($form['phone']) ?>" data-phone>
            </div>
            <div class="field">
              <label>อีเมล</label>
              <input class="input" type="email" name="email" value="<?= e($form['email']) ?>">
            </div>
            <div class="field">
              <label>เว็บไซต์</label>
              <input class="input" type="text" name="website" value="<?= e($form['website']) ?>" placeholder="www.school.ac.th">
            </div>
            <div class="field">
              <label>ผู้อำนวยการสถานศึกษา</label>
              <input class="input" type="text" name="director" value="<?= e($form['director']) ?>">
            </div>
            <div class="field">
              <label>ปีการศึกษา <span class="req">*</span></label>
              <input class="input <?= isset($errors['academic_year']) ? 'is-invalid' : '' ?>" type="text" name="academic_year" value="<?= e($form['academic_year']) ?>" maxlength="4">
              <?php if (isset($errors['academic_year'])): ?><span class="field-error"><?= e($errors['academic_year']) ?></span><?php endif; ?>
            </div>
            <div class="field">
              <label>ภาคเรียน <span class="req">*</span></label>
              <select class="select" name="semester">
                <option value="1" <?= (int) $form['semester'] === 1 ? 'selected' : '' ?>>ภาคเรียนที่ 1</option>
                <option value="2" <?= (int) $form['semester'] === 2 ? 'selected' : '' ?>>ภาคเรียนที่ 2</option>
              </select>
            </div>
          </div>
          <div class="form-actions">
            <button class="btn btn-primary" type="submit"><?= icon('save', 17) ?> บันทึกการตั้งค่า</button>
          </div>
        </form>
      </div>
    </section>

    <section class="card">
      <div class="card-head bordered">
        <div>
          <h3 class="card-title"><?= icon('lock', 19) ?> ความปลอดภัยของบัญชี</h3>
          <p class="card-sub">เปลี่ยนรหัสผ่านสำหรับ <?= e($user['username']) ?></p>
        </div>
      </div>
      <div class="card-body">
        <form method="post" action="<?= url('settings.php') ?>">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="change_password">
          <div class="form-grid">
            <div class="field span-2">
              <label>รหัสผ่านปัจจุบัน <span class="req">*</span></label>
              <input class="input <?= isset($errors['current_password']) ? 'is-invalid' : '' ?>" type="password" name="current_password" autocomplete="current-password" required>
              <?php if (isset($errors['current_password'])): ?><span class="field-error"><?= e($errors['current_password']) ?></span><?php endif; ?>
            </div>
            <div class="field">
              <label>รหัสผ่านใหม่ <span class="req">*</span></label>
              <input class="input <?= isset($errors['new_password']) ? 'is-invalid' : '' ?>" type="password" name="new_password" autocomplete="new-password" required>
              <?php if (isset($errors['new_password'])): ?><span class="field-error"><?= e($errors['new_password']) ?></span><?php endif; ?>
            </div>
            <div class="field">
              <label>ยืนยันรหัสผ่านใหม่ <span class="req">*</span></label>
              <input class="input <?= isset($errors['confirm_password']) ? 'is-invalid' : '' ?>" type="password" name="confirm_password" autocomplete="new-password" required>
              <?php if (isset($errors['confirm_password'])): ?><span class="field-error"><?= e($errors['confirm_password']) ?></span><?php endif; ?>
            </div>
          </div>
          <div class="form-actions">
            <button class="btn btn-success" type="submit"><?= icon('key', 17) ?> เปลี่ยนรหัสผ่าน</button>
          </div>
        </form>
      </div>
    </section>
  </div>

  <div class="stack">
    <article class="card">
      <div class="card-head">
        <div><h3 class="card-title"><?= icon('info', 19) ?> ข้อมูลระบบ</h3><p class="card-sub">สถานะฐานข้อมูลและเวอร์ชัน</p></div>
      </div>
      <div class="card-body">
        <div class="info-grid" style="grid-template-columns:1fr">
          <div class="info-item"><span>เวอร์ชันระบบ</span><b>SMS v<?= e(APP_VERSION) ?></b></div>
          <div class="info-item"><span>ฐานข้อมูล</span><b><?= e(DB_NAME) ?></b></div>
          <div class="info-item"><span>PHP</span><b><?= e(PHP_VERSION) ?></b></div>
          <div class="info-item"><span>เซิร์ฟเวอร์</span><b><?= e($_SERVER['SERVER_SOFTWARE'] ?? 'PHP Built-in') ?></b></div>
          <div class="info-item"><span>เขตเวลา</span><b><?= e(date_default_timezone_get()) ?></b></div>
        </div>
      </div>
    </article>

    <article class="card">
      <div class="card-head">
        <div><h3 class="card-title"><?= icon('chart', 19) ?> ข้อมูลในระบบ</h3><p class="card-sub">จำนวนระเบียนปัจจุบัน</p></div>
      </div>
      <div class="card-body">
        <div class="stack" style="gap:9px">
          <?php $labels = ['students' => ['นักเรียน', 'users'], 'classes' => ['ชั้นเรียน', 'building'], 'subjects' => ['รายวิชา', 'book'], 'attendance' => ['ระเบียนเช็คชื่อ', 'check'], 'grades' => ['ผลการเรียน', 'edit'], 'documents' => ['เอกสาร ปพ.', 'file']]; ?>
          <?php foreach ($labels as $key => $meta): ?>
            <div class="row-between" style="padding:8px 11px;border-radius:10px;background:#f8faff;border:1px solid #eef1f9">
              <span class="row" style="gap:8px;font-size:.8rem;color:var(--ink-2)"><?= icon($meta[1], 15) ?> <?= e($meta[0]) ?></span>
              <b class="num"><?= number_format($counts[$key]) ?></b>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
    </article>

    <div class="notice notice-warning">
      <?= icon('alert', 18) ?>
      <div><strong>สำรองข้อมูล</strong> ควรสำรองฐานข้อมูลสม่ำเสมอผ่าน phpMyAdmin หรือคำสั่ง mysqldump เพื่อความปลอดภัยของข้อมูลโรงเรียน</div>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
