<?php

require_once __DIR__ . '/includes/bootstrap.php';

$portalActive = 'activities';
$pageTitle = 'กิจกรรมและสถิติการเข้าร่วม';
$pageSubtitle = 'ติดตามการเข้าร่วมกิจกรรมของฉัน';
require __DIR__ . '/includes/student-context.php';

$studentId = (int) $student['id'];
$portalTablesReady = portal_tables_ready();
$statusMeta = activity_status_meta();
$statusOrder = ['present', 'late', 'leave', 'absent', 'truant'];

$activities = [];
$participation = ['present' => 0, 'late' => 0, 'leave' => 0, 'absent' => 0, 'truant' => 0];
$unrecorded = 0;
$recorded = 0;

if ($portalTablesReady) {
    $activityStmt = $pdo->prepare('SELECT a.*, c.name AS class_name,
            aa.status AS my_status, aa.note AS my_note, aa.updated_at AS recorded_at,
            u.fullname AS recorder
        FROM activities a
        LEFT JOIN activity_attendance aa ON aa.activity_id = a.id AND aa.student_id = ?
        LEFT JOIN classes c ON c.id = a.class_id
        LEFT JOIN users u ON u.id = aa.recorded_by
        WHERE a.academic_year = ? AND a.semester = ?
          AND (a.class_id IS NULL OR a.class_id = ?)
        ORDER BY a.activity_date DESC, a.id DESC');
    $activityStmt->execute([$studentId, $year, $semester, (int) ($student['class_id'] ?? 0)]);
    $activities = $activityStmt->fetchAll();

    foreach ($activities as $activity) {
        $status = (string) ($activity['my_status'] ?? '');
        if ($status === '' || !isset($participation[$status])) {
            $unrecorded++;
            continue;
        }
        $participation[$status]++;
        $recorded++;
    }
}

$attended = $participation['present'] + $participation['late'];
$participationRate = $recorded > 0 ? $attended / $recorded * 100 : 0.0;
$missed = $participation['absent'] + $participation['truant'];

require __DIR__ . '/includes/student-portal-top.php';
?>

<div class="page-heading">
  <div>
    <span class="hero-kicker dark"><?= icon('star', 15) ?> กิจกรรมของฉัน</span>
    <h1>สถิติเข้าร่วมกิจกรรม</h1>
    <p>กิจกรรม ปีการศึกษา <?= e($year) ?> ภาคเรียนที่ <?= $semester ?> · <?= e(student_name($student, false)) ?></p>
  </div>
  <span class="badge badge-<?= $participationRate >= 80 ? 'success' : ($participationRate >= 60 ? 'warning' : 'danger') ?>">
    <span class="dot"></span>เข้าร่วม <?= number_format($participationRate, 1) ?>%
  </span>
</div>

<?php if (!$portalTablesReady): ?>
  <div class="notice notice-warning mb-2"><?= icon('alert', 18) ?><div><strong>ยังไม่มีข้อมูลกิจกรรม</strong><br>กรุณาให้เจ้าหน้าที่นำเข้าไฟล์ <code>database/student-portal.sql</code> เพื่อเปิดใช้งานระบบกิจกรรม</div></div>
<?php endif; ?>

<div class="gb-summary activity-summary">
  <div class="gb-stat" style="--accent:#10b981"><b style="color:#059669"><?= number_format($activities ? count($activities) : 0) ?></b><span>กิจกรรมทั้งหมด</span></div>
  <div class="gb-stat" style="--accent:#10b981"><b style="color:#059669"><?= number_format($participation['present']) ?></b><span>เข้าร่วม</span></div>
  <div class="gb-stat" style="--accent:#f59e0b"><b style="color:#d97706"><?= number_format($participation['late']) ?></b><span>มาสาย</span></div>
  <div class="gb-stat" style="--accent:#3b82f6"><b style="color:#2563eb"><?= number_format($participation['leave']) ?></b><span>ลา</span></div>
  <div class="gb-stat" style="--accent:#ef4444"><b style="color:#dc2626"><?= number_format($missed) ?></b><span>ไม่เข้าร่วม / หนี</span></div>
  <div class="gb-stat" style="--accent:#94a3b8"><b style="color:#64748b"><?= number_format($unrecorded) ?></b><span>ยังไม่บันทึก</span></div>
</div>

<div class="grid grid-2-1">
  <article class="card">
    <div class="card-head bordered">
      <div><h3 class="card-title"><?= icon('calendar', 19) ?> รายการกิจกรรม</h3><p class="card-sub">เฉพาะกิจกรรมที่นักเรียนคนนี้ต้องเข้าร่วม</p></div>
      <div class="card-actions"><span class="chip"><?= icon('check-circle', 13) ?> บันทึกแล้ว <?= number_format($recorded) ?>/<?= number_format(count($activities)) ?></span></div>
    </div>
    <div class="card-body" style="padding-top:10px">
      <div class="stack" style="gap:9px">
        <?php foreach ($activities as $activity): ?>
          <?php
            $status = (string) ($activity['my_status'] ?? '');
            $meta = $statusMeta[$status] ?? ['label' => 'ยังไม่บันทึก', 'class' => 'muted'];
            $dateTs = strtotime((string) $activity['activity_date']);
          ?>
          <div class="activity-row">
            <div class="activity-date">
              <b><?= e($dateTs ? date('j', $dateTs) : '—') ?></b>
              <span><?= e($dateTs ? THAI_MONTHS_SHORT[(int) date('n', $dateTs)] : '') ?></span>
            </div>
            <div class="activity-main">
              <div class="row" style="gap:8px;flex-wrap:wrap">
                <b><?= e($activity['title']) ?></b>
                <span class="badge badge-<?= e($meta['class']) ?>"><?= e($meta['label']) ?></span>
                <?php if ($activity['class_id'] !== null): ?><span class="chip"><?= icon('users', 12) ?> <?= e($activity['class_name'] ?: 'เฉพาะชั้น') ?></span><?php else: ?><span class="chip"><?= icon('building', 12) ?> ทั้งโรงเรียน</span><?php endif; ?>
              </div>
              <?php if ($activity['description'] !== ''): ?><p class="text-muted text-sm"><?= e($activity['description']) ?></p><?php endif; ?>
              <div class="activity-meta">
                <span><?= icon('calendar', 13) ?> <?= e(thai_date($activity['activity_date'], 'short')) ?></span>
                <?php if ($activity['location'] !== ''): ?><span><?= icon('map-pin', 13) ?> <?= e($activity['location']) ?></span><?php endif; ?>
                <?php if ($activity['my_note'] !== ''): ?><span><?= icon('info', 13) ?> <?= e($activity['my_note']) ?></span><?php endif; ?>
                <?php if ($activity['recorder']): ?><span><?= icon('user', 13) ?> บันทึกโดย <?= e($activity['recorder']) ?></span><?php endif; ?>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
        <?php if (!$activities): ?>
          <div class="empty-state"><div class="empty-ico"><?= icon('star', 28) ?></div><h3>ยังไม่มีกิจกรรมในภาคเรียนนี้</h3><p>เมื่อครูสร้างกิจกรรม รายการจะแสดงที่นี่</p></div>
        <?php endif; ?>
      </div>
    </div>
  </article>

  <div class="stack">
    <article class="card">
      <div class="card-head"><div><h3 class="card-title"><?= icon('chart', 19) ?> อัตราการเข้าร่วม</h3><p class="card-sub">นับเฉพาะกิจกรรมที่บันทึกแล้ว</p></div></div>
      <div class="card-body" style="display:flex;flex-direction:column;align-items:center">
        <div class="donut-wrap">
          <svg class="donut-svg" viewBox="0 0 120 120" aria-hidden="true">
            <defs><linearGradient id="activityDonut" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#a78bfa"/><stop offset=".55" stop-color="#8b5cf6"/><stop offset="1" stop-color="#6d28d9"/></linearGradient></defs>
            <circle class="donut-track" cx="60" cy="60" r="48"/>
            <circle class="donut-value" cx="60" cy="60" r="48" data-donut="<?= round($participationRate, 1) ?>" style="stroke:url(#activityDonut)"/>
          </svg>
          <div class="donut-center"><b><?= number_format($participationRate, 1) ?><span style="font-size:.8rem">%</span></b><span>เข้าร่วม</span></div>
        </div>
        <div class="legend" style="width:100%;margin-top:16px">
          <?php foreach ($statusOrder as $key): ?>
            <?php $meta = $statusMeta[$key]; ?>
            <div class="legend-item">
              <span class="swatch" style="background:<?= ['present' => '#10b981', 'late' => '#f59e0b', 'leave' => '#3b82f6', 'absent' => '#ef4444', 'truant' => '#be123c'][$key] ?>"></span>
              <?= e($meta['label']) ?><b><?= number_format($participation[$key]) ?></b>
            </div>
          <?php endforeach; ?>
          <div class="legend-item">
            <span class="swatch" style="background:#cbd5e1"></span>
            ยังไม่บันทึก<b><?= number_format($unrecorded) ?></b>
          </div>
        </div>
      </div>
    </article>

    <article class="card">
      <div class="card-body">
        <div class="notice notice-info" style="margin:0">
          <?= icon('info', 18) ?>
          <div><strong>การเข้าร่วมกิจกรรม</strong><br>ครูเป็นผู้บันทึกสถานะการเข้าร่วมกิจกรรม นักเรียนสามารถตรวจสอบย้อนหลังได้เท่านั้น</div>
        </div>
      </div>
    </article>
  </div>
</div>

<?php require __DIR__ . '/includes/student-portal-bottom.php'; ?>
