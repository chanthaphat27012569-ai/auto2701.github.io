<?php

require_once __DIR__ . '/includes/bootstrap.php';

$portalActive = 'home';
$pageTitle = 'หน้าหลัก';
$pageSubtitle = 'ภาพรวมการเรียนและกิจกรรมของฉัน';
require __DIR__ . '/includes/student-context.php';

$studentId = (int) $student['id'];
$portalTablesReady = portal_tables_ready();
$today = date('Y-m-d');

$attStmt = $pdo->prepare("SELECT COUNT(*) AS total,
        SUM(status = 'present') AS present, SUM(status = 'late') AS late, SUM(status = 'sick') AS sick,
        SUM(status = 'business') AS business, SUM(status = 'absent') AS absent, SUM(status = 'truant') AS truant
    FROM attendance WHERE student_id = ?");
$attStmt->execute([$studentId]);
$att = $attStmt->fetch() ?: [];
$attCounts = [
    'present' => (int) ($att['present'] ?? 0),
    'late' => (int) ($att['late'] ?? 0),
    'sick' => (int) ($att['sick'] ?? 0),
    'business' => (int) ($att['business'] ?? 0),
    'absent' => (int) ($att['absent'] ?? 0),
    'truant' => (int) ($att['truant'] ?? 0),
];
$attRate = attendance_rate($attCounts);
$attTotal = array_sum($attCounts);
$missDays = $attCounts['absent'] + $attCounts['truant'];

$gradeStmt = $pdo->prepare('SELECT g.*, sub.code, sub.name, sub.credits
    FROM grades g JOIN subjects sub ON sub.id = g.subject_id
    WHERE g.student_id = ? AND g.academic_year = ? AND g.semester = ?
    ORDER BY sub.code');
$gradeStmt->execute([$studentId, $year, $semester]);
$currentGrades = $gradeStmt->fetchAll();

$allGradeStmt = $pdo->prepare('SELECT g.*, sub.code, sub.name, sub.credits
    FROM grades g JOIN subjects sub ON sub.id = g.subject_id
    WHERE g.student_id = ?
    ORDER BY g.academic_year DESC, g.semester DESC, sub.code');
$allGradeStmt->execute([$studentId]);
$allGrades = $allGradeStmt->fetchAll();

$points = [];
foreach ($currentGrades as $grade) {
    if (is_numeric($grade['grade'])) {
        $points[] = (float) $grade['grade'];
    }
}
$gpa = $points ? array_sum($points) / count($points) : 0.0;

$recentAttStmt = $pdo->prepare('SELECT att_date, status, note FROM attendance WHERE student_id = ? ORDER BY att_date DESC LIMIT 30');
$recentAttStmt->execute([$studentId]);
$recentAttendance = $recentAttStmt->fetchAll();

$docStmt = $pdo->prepare('SELECT * FROM documents WHERE student_id = ? ORDER BY issued_at DESC');
$docStmt->execute([$studentId]);
$documents = $docStmt->fetchAll();

$flagStmt = $pdo->prepare('SELECT a.*, u.fullname AS recorder FROM attendance a
    LEFT JOIN users u ON u.id = a.recorded_by
    WHERE a.student_id = ? AND a.att_date = ? LIMIT 1');
$flagStmt->execute([$studentId, $today]);
$todayFlag = $flagStmt->fetch() ?: null;

$todayWeekday = (int) date('N');
$todayTimetable = [];
$behaviorNet = 0;
$behaviorPlus = 0;
$behaviorMinus = 0;
$behaviorCount = 0;
$myClub = null;
$myElective = null;
$todaySubjectCounts = [];

if ($portalTablesReady) {
    if ($todayWeekday <= 5) {
        $ttStmt = $pdo->prepare('SELECT t.*, sub.code, sub.name AS subject_name, sub.credits,
                sa.status AS attendance_status, sa.note AS attendance_note
            FROM timetable t
            JOIN subjects sub ON sub.id = t.subject_id
            LEFT JOIN subject_attendance sa ON sa.student_id = ? AND sa.subject_id = t.subject_id
                AND sa.att_date = ? AND sa.period = t.period
            WHERE t.class_id = ? AND t.day_of_week = ?
            ORDER BY t.period');
        $ttStmt->execute([$studentId, $today, (int) ($student['class_id'] ?? 0), $todayWeekday]);
        $todayTimetable = $ttStmt->fetchAll();
    }

    $behaviorStmt = $pdo->prepare('SELECT COALESCE(SUM(points), 0) AS net,
            COALESCE(SUM(CASE WHEN points > 0 THEN points ELSE 0 END), 0) AS plus,
            COALESCE(SUM(CASE WHEN points < 0 THEN -points ELSE 0 END), 0) AS minus,
            COUNT(*) AS records
        FROM behavior_records WHERE student_id = ?');
    $behaviorStmt->execute([$studentId]);
    $behavior = $behaviorStmt->fetch() ?: [];
    $behaviorNet = (int) ($behavior['net'] ?? 0);
    $behaviorPlus = (int) ($behavior['plus'] ?? 0);
    $behaviorMinus = (int) ($behavior['minus'] ?? 0);
    $behaviorCount = (int) ($behavior['records'] ?? 0);

    $clubStmt = $pdo->prepare('SELECT c.*, r.created_at AS registered_at,
            (SELECT COUNT(*) FROM club_registrations cr WHERE cr.club_id = c.id AND cr.academic_year = r.academic_year AND cr.semester = r.semester) AS members
        FROM club_registrations r JOIN clubs c ON c.id = r.club_id
        WHERE r.student_id = ? AND r.academic_year = ? AND r.semester = ? LIMIT 1');
    $clubStmt->execute([$studentId, $year, $semester]);
    $myClub = $clubStmt->fetch() ?: null;

    $electiveStmt = $pdo->prepare('SELECT sub.*, r.created_at AS registered_at
        FROM elective_registrations r JOIN subjects sub ON sub.id = r.subject_id
        WHERE r.student_id = ? AND r.academic_year = ? AND r.semester = ? LIMIT 1');
    $electiveStmt->execute([$studentId, $year, $semester]);
    $myElective = $electiveStmt->fetch() ?: null;

    foreach ($todayTimetable as $slot) {
        $status = (string) ($slot['attendance_status'] ?? '');
        if ($status !== '') {
            $todaySubjectCounts[$status] = ($todaySubjectCounts[$status] ?? 0) + 1;
        }
    }
}

$behaviorScore = max(0, 100 + $behaviorNet);
$behaviorMeta = behavior_score_meta($behaviorScore);
$behaviorPercent = max(0, min(100, $behaviorScore));
$statusMeta = attendance_meta();
$badgeClass = ['present' => 'success', 'late' => 'warning', 'sick' => 'info', 'business' => 'violet', 'absent' => 'danger', 'truant' => 'danger'];
$todayFlagMeta = $todayFlag ? ($statusMeta[$todayFlag['status']] ?? $statusMeta['present']) : null;
$greetingName = trim((string) ($profile['nickname'] ?? '')) ?: (string) $student['firstname'];
$nowTime = date('H:i:s');
$hour = (int) date('G');
$greeting = $hour < 12 ? 'สวัสดีตอนเช้า' : ($hour < 17 ? 'สวัสดีตอนบ่าย' : 'สวัสดีตอนเย็น');

require __DIR__ . '/includes/student-portal-top.php';
?>

<section class="portal-hero portal-home-hero">
  <?= student_avatar($student, 'xl') ?>
  <div class="portal-hero-main">
    <span class="badge" style="background:rgba(255,255,255,.16);border-color:rgba(255,255,255,.24);color:#fff"><?= e($statusOfStudent['label']) ?></span>
    <span class="hero-kicker"><?= icon('sparkles', 15) ?> <?= e($greeting) ?></span>
    <h1><?= e($greetingName) ?> <?= e($student['lastname']) ?></h1>
    <p><?= e($classText ?: 'ไม่ระบุชั้นเรียน') ?> · เลขที่ <?= (int) $student['student_number'] ?> · รหัส <?= e($student['student_code']) ?></p>
    <p class="hero-date"><?= icon('calendar', 14) ?> <?= e(thai_date($today, 'day')) ?> · ปีการศึกษา <?= e($year) ?> ภาคเรียนที่ <?= (int) $semester ?></p>
  </div>
  <div class="hero-stats">
    <div><b><?= number_format($attRate, 1) ?>%</b><span>อัตรามาเรียน</span></div>
    <div><b><?= number_format($gpa, 2) ?></b><span>GPA ภาคนี้</span></div>
    <div><b><?= number_format($behaviorScore) ?></b><span>คะแนนพฤติกรรม</span></div>
    <div><b class="hero-status-text"><?= e($todayFlagMeta['label'] ?? 'ยังไม่เช็คชื่อ') ?></b><span>หน้าเสาธงวันนี้</span></div>
  </div>
</section>

<section class="portal-quick mt-3">
  <a class="quick-card" href="<?= e(portal_url('student-profile.php')) ?>">
    <span class="q-ico"><?= icon('user', 19) ?></span>
    <b>ข้อมูลส่วนตัว</b>
    <small>ดูและแก้ไขข้อมูลของฉัน</small>
    <?= icon('chevron-right', 15, 'quick-arrow') ?>
  </a>
  <a class="quick-card" href="<?= e(portal_url('student-attendance.php')) ?>">
    <span class="q-ico" style="background:#ecfdf5;color:#059669"><?= icon('check', 19) ?></span>
    <b>ประวัติเช็คชื่อ</b>
    <small>หน้าเสาธงและรายวิชา</small>
    <?= icon('chevron-right', 15, 'quick-arrow') ?>
  </a>
  <a class="quick-card" href="<?= e(portal_url('student-behavior.php')) ?>">
    <span class="q-ico" style="background:#fffbeb;color:#d97706"><?= icon('award', 19) ?></span>
    <b>คะแนนพฤติกรรม</b>
    <small>สะสม เพิ่ม และหักคะแนน</small>
    <?= icon('chevron-right', 15, 'quick-arrow') ?>
  </a>
  <a class="quick-card" href="<?= e(portal_url('student-clubs.php')) ?>">
    <span class="q-ico" style="background:#f5f3ff;color:#7c3aed"><?= icon('users', 19) ?></span>
    <b>ชุมนุมและวิชาเพิ่มเติม</b>
    <small>ตรวจสอบการลงทะเบียน</small>
    <?= icon('chevron-right', 15, 'quick-arrow') ?>
  </a>
</section>

<section class="portal-section mt-3">
  <div class="tabs portal-tabs" data-tab-group role="tablist" aria-label="ข้อมูลนักเรียน">
    <button type="button" class="tab is-active" data-tab="overview" role="tab" aria-selected="true"><?= icon('dashboard', 15) ?> ภาพรวม</button>
    <button type="button" class="tab" data-tab="attendance" role="tab" aria-selected="false"><?= icon('check', 15) ?> เวลาเรียน</button>
    <button type="button" class="tab" data-tab="grades" role="tab" aria-selected="false"><?= icon('award', 15) ?> ผลการเรียน</button>
    <button type="button" class="tab" data-tab="documents" role="tab" aria-selected="false"><?= icon('file', 15) ?> เอกสาร</button>
  </div>

  <div class="tab-panel is-active" data-tab-panel="overview" id="tab-overview">
    <?php if (!$portalTablesReady): ?>
      <div class="notice notice-warning mb-2"><?= icon('alert', 18) ?><div><strong>ยังไม่ได้เปิดใช้งานฟังก์ชันพอร์ทัลเต็มรูปแบบ</strong><br>กรุณาให้เจ้าหน้าที่นำเข้าไฟล์ <code>database/student-portal.sql</code> เพื่อใช้งานตารางเรียน เช็คชื่อรายวิชา พฤติกรรม ชุมนุม และวิชาเพิ่มเติม</div></div>
    <?php endif; ?>

    <div class="grid grid-2-1">
      <div class="stack">
        <article class="card portal-today">
          <div class="card-head bordered">
            <div><h3 class="card-title"><?= icon('clock', 19) ?> ภาพรวมวันนี้</h3><p class="card-sub"><?= e(thai_date($today, 'day')) ?></p></div>
            <div class="card-actions"><span class="chip chip-soft"><?= icon('calendar', 13) ?> <?= e(date('d/m/') . (date('Y') + 543)) ?></span></div>
          </div>
          <div class="card-body">
            <div class="today-grid">
              <div class="today-box">
                <span class="today-box-label"><?= icon('check-circle', 15) ?> เช็คชื่อหน้าเสาธง</span>
                <div class="today-box-main">
                  <span class="att-orb att-<?= e($todayFlag['status'] ?? 'none') ?>"><?= e($todayFlagMeta['short'] ?? '?') ?></span>
                  <div>
                    <b><?= e($todayFlagMeta['label'] ?? 'ยังไม่เช็คชื่อ') ?></b>
                    <small><?= $todayFlag ? 'บันทึกโดย ' . e($todayFlag['recorder'] ?: 'ครูผู้รับผิดชอบ') : 'รอครูบันทึกการเช็คชื่อ' ?></small>
                  </div>
                  <a class="btn btn-ghost btn-sm" href="<?= e(portal_url('student-attendance.php')) ?>">ประวัติ <?= icon('arrow-right', 13) ?></a>
                </div>
              </div>
              <div class="today-box">
                <span class="today-box-label"><?= icon('award', 15) ?> คะแนนพฤติกรรมปัจจุบัน</span>
                <div class="today-box-main">
                  <span class="score-orb" style="--score:<?= $behaviorPercent ?>;--score-color:<?= e($behaviorMeta['color']) ?>"><b><?= number_format($behaviorScore) ?></b></span>
                  <div>
                    <b><?= e($behaviorMeta['label']) ?></b>
                    <small>เพิ่ม <?= number_format($behaviorPlus) ?> · หัก <?= number_format($behaviorMinus) ?> · <?= number_format($behaviorCount) ?> รายการ</small>
                  </div>
                  <a class="btn btn-ghost btn-sm" href="<?= e(portal_url('student-behavior.php')) ?>">รายละเอียด <?= icon('arrow-right', 13) ?></a>
                </div>
              </div>
            </div>
          </div>
        </article>

        <article class="card">
          <div class="card-head">
            <div><h3 class="card-title"><?= icon('calendar', 19) ?> ตารางเรียนวันนี้</h3><p class="card-sub"><?= $todayWeekday <= 5 ? count($todayTimetable) . ' คาบเรียน' : 'วันหยุดเรียน' ?></p></div>
            <div class="card-actions"><span class="badge badge-brand"><?= e($classText ?: '—') ?></span></div>
          </div>
          <div class="card-body" style="padding-top:8px">
            <?php if ($todayTimetable): ?>
              <div class="tt-list">
                <?php foreach ($todayTimetable as $slot): ?>
                  <?php
                    $start = substr((string) $slot['start_time'], 0, 5);
                    $end = substr((string) $slot['end_time'], 0, 5);
                    $isNow = $nowTime >= $slot['start_time'] && $nowTime < $slot['end_time'];
                    $isDone = $nowTime >= $slot['end_time'];
                    $slotStatus = (string) ($slot['attendance_status'] ?? '');
                  ?>
                  <div class="tt-row <?= $isNow ? 'is-now' : ($isDone ? 'is-done' : '') ?>">
                    <span class="tt-period">คาบ <?= (int) $slot['period'] ?></span>
                    <span class="tt-main">
                      <b><?= e($slot['subject_name']) ?></b>
                      <small><?= e($slot['code']) ?> · <?= e($start) ?>–<?= e($end) ?> น. · <?= e($slot['room'] ?: '—') ?></small>
                    </span>
                    <?php if ($slotStatus !== ''): ?>
                      <span class="badge badge-<?= e($badgeClass[$slotStatus] ?? 'muted') ?>"><?= e($statusMeta[$slotStatus]['label'] ?? $slotStatus) ?></span>
                    <?php else: ?>
                      <span class="badge badge-muted"><?= $isNow ? 'กำลังเรียน' : 'ยังไม่เช็ค' ?></span>
                    <?php endif; ?>
                  </div>
                <?php endforeach; ?>
              </div>
            <?php else: ?>
              <div class="empty-state" style="padding:32px 16px">
                <div class="empty-ico"><?= icon('calendar', 27) ?></div>
                <h3><?= $todayWeekday > 5 ? 'วันนี้เป็นวันหยุด' : 'ยังไม่มีตารางเรียน' ?></h3>
                <p><?= $todayWeekday > 5 ? 'พักผ่อนให้เต็มที่ แล้วกลับมาเรียนในวันเรียนถัดไป' : 'ตารางเรียนจะแสดงเมื่อโรงเรียนจัดตารางสอน' ?></p>
              </div>
            <?php endif; ?>
          </div>
        </article>
      </div>

      <div class="stack">
        <article class="card">
          <div class="card-head">
            <div><h3 class="card-title"><?= icon('check-circle', 19) ?> เช็คชื่อรายวิชาวันนี้</h3><p class="card-sub"><?= $todaySubjectCounts ? 'มีบันทึกแล้ว ' . array_sum($todaySubjectCounts) . ' คาบ' : 'ยังไม่มีบันทึก' ?></p></div>
          </div>
          <div class="card-body" style="padding-top:6px">
            <div class="stack" style="gap:7px">
              <?php foreach ($todayTimetable as $slot): ?>
                <?php $slotStatus = (string) ($slot['attendance_status'] ?? ''); ?>
                <div class="subject-att-row">
                  <span class="subject-att-period"><?= (int) $slot['period'] ?></span>
                  <span class="subject-att-name">
                    <b><?= e($slot['subject_name']) ?></b>
                    <small><?= e(substr((string) $slot['start_time'], 0, 5)) ?>–<?= e(substr((string) $slot['end_time'], 0, 5)) ?></small>
                  </span>
                  <?php if ($slotStatus !== ''): ?>
                    <span class="badge badge-<?= e($badgeClass[$slotStatus] ?? 'muted') ?>"><?= e($statusMeta[$slotStatus]['label'] ?? $slotStatus) ?></span>
                  <?php else: ?>
                    <span class="badge badge-muted">รอเช็ค</span>
                  <?php endif; ?>
                </div>
              <?php endforeach; ?>
              <?php if (!$todayTimetable): ?>
                <div class="empty-state" style="padding:20px 10px"><p><?= $todayWeekday > 5 ? 'วันหยุดเรียน' : 'ยังไม่มีคาบเรียนวันนี้' ?></p></div>
              <?php endif; ?>
            </div>
            <div class="today-att-summary">
              <span><span class="dot" style="background:#10b981"></span>มา <?= (int) ($todaySubjectCounts['present'] ?? 0) ?></span>
              <span><span class="dot" style="background:#f59e0b"></span>สาย <?= (int) ($todaySubjectCounts['late'] ?? 0) ?></span>
              <span><span class="dot" style="background:#ef4444"></span>ขาด <?= (int) (($todaySubjectCounts['absent'] ?? 0) + ($todaySubjectCounts['truant'] ?? 0)) ?></span>
              <a href="<?= e(portal_url('student-attendance.php')) ?>">ทั้งหมด <?= icon('arrow-right', 12) ?></a>
            </div>
          </div>
        </article>

        <article class="card">
          <div class="card-head">
            <div><h3 class="card-title"><?= icon('book', 19) ?> การลงทะเบียนของฉัน</h3><p class="card-sub">ปี <?= e($year) ?> · ภาคเรียนที่ <?= (int) $semester ?></p></div>
          </div>
          <div class="card-body" style="padding-top:6px">
            <div class="stack" style="gap:9px">
              <a class="registration-row" href="<?= e(portal_url('student-clubs.php')) ?>">
                <span class="q-ico" style="background:#f5f3ff;color:#7c3aed"><?= icon('users', 18) ?></span>
                <span><small>ชุมนุม</small><b><?= e($myClub['name'] ?? 'ยังไม่ได้ลงทะเบียน') ?></b></span>
                <?= icon('chevron-right', 15) ?>
              </a>
              <a class="registration-row" href="<?= e(portal_url('student-electives.php')) ?>">
                <span class="q-ico" style="background:#eff6ff;color:#2563eb"><?= icon('book', 18) ?></span>
                <span><small>วิชาเพิ่มเติม</small><b><?= e($myElective['name'] ?? 'ยังไม่ได้ลงทะเบียน') ?></b></span>
                <?= icon('chevron-right', 15) ?>
              </a>
              <a class="registration-row" href="<?= e(portal_url('student-password.php')) ?>">
                <span class="q-ico" style="background:#fffbeb;color:#d97706"><?= icon('lock', 18) ?></span>
                <span><small>ความปลอดภัย</small><b>เปลี่ยนรหัสผ่านพอร์ทัล</b></span>
                <?= icon('chevron-right', 15) ?>
              </a>
            </div>
          </div>
        </article>

        <article class="card">
          <div class="card-head">
            <div><h3 class="card-title"><?= icon('bell', 19) ?> ประกาศและเอกสาร</h3><p class="card-sub">เอกสาร ปพ. ล่าสุด</p></div>
            <div class="card-actions"><span class="badge badge-brand"><?= count($documents) ?></span></div>
          </div>
          <div class="card-body" style="padding-top:6px">
            <?php if ($documents): ?>
              <div class="stack" style="gap:7px">
                <?php foreach (array_slice($documents, 0, 3) as $doc): ?>
                  <?php $type = doc_type($doc['doc_type']); ?>
                  <a class="doc-mini" href="<?= url('document-print.php?id=' . (int) $doc['id']) ?>" target="_blank" rel="noopener">
                    <span class="q-ico" style="background:var(--brand-soft);color:var(--brand)"><?= icon($type['icon'], 17) ?></span>
                    <span><b><?= e($type['label']) ?> · <?= e($type['name']) ?></b><small><?= e($doc['doc_no']) ?> · <?= e(thai_date($doc['issued_at'], 'short')) ?></small></span>
                    <?= icon('printer', 15) ?>
                  </a>
                <?php endforeach; ?>
              </div>
            <?php else: ?>
              <div class="empty-state" style="padding:20px 10px"><p>ยังไม่มีเอกสารที่ออกให้</p></div>
            <?php endif; ?>
          </div>
        </article>
      </div>
    </div>

    <article class="card mt-3">
      <div class="card-head">
        <div><h3 class="card-title"><?= icon('check-circle', 19) ?> การเข้าเรียนล่าสุด</h3><p class="card-sub">10 ระเบียนล่าสุด · อัตรามาเรียน <?= number_format($attRate, 1) ?>%</p></div>
        <div class="card-actions"><a class="btn btn-ghost btn-sm" href="<?= e(portal_url('student-attendance.php')) ?>">ดูทั้งหมด <?= icon('arrow-right', 14) ?></a></div>
      </div>
      <div class="card-body" style="padding-top:6px">
        <div class="att-strip">
          <?php foreach (array_slice($recentAttendance, 0, 10) as $row): ?>
            <?php $meta = $statusMeta[$row['status']] ?? $statusMeta['present']; ?>
            <div class="att-strip-item">
              <span class="att-orb att-<?= e($row['status']) ?>"><?= e($meta['short']) ?></span>
              <span><b><?= e(thai_date($row['att_date'], 'short')) ?></b><small>วัน<?= e(THAI_DAYS[(int) date('w', strtotime($row['att_date']))]) ?></small></span>
              <span class="badge badge-<?= e($badgeClass[$row['status']] ?? 'muted') ?>"><?= e($meta['label']) ?></span>
            </div>
          <?php endforeach; ?>
          <?php if (!$recentAttendance): ?><div class="empty-state" style="padding:22px"><p>ยังไม่มีบันทึกการเข้าเรียน</p></div><?php endif; ?>
        </div>
      </div>
    </article>
  </div>

  <div class="tab-panel" data-tab-panel="attendance" id="tab-attendance">
    <div class="stat-grid mb-2">
      <article class="stat-card" style="--accent:#10b981;--accent-soft:#ecfdf5;--i:0"><div class="stat-icon"><?= icon('check', 22) ?></div><div class="stat-value num" data-count="<?= $attCounts['present'] ?>">0</div><div class="stat-label">มาเรียน</div></article>
      <article class="stat-card" style="--accent:#f59e0b;--accent-soft:#fffbeb;--i:1"><div class="stat-icon"><?= icon('clock', 22) ?></div><div class="stat-value num" data-count="<?= $attCounts['late'] ?>">0</div><div class="stat-label">มาสาย</div></article>
      <article class="stat-card" style="--accent:#3b82f6;--accent-soft:#eff6ff;--i:2"><div class="stat-icon"><?= icon('file', 22) ?></div><div class="stat-value num" data-count="<?= $attCounts['sick'] + $attCounts['business'] ?>">0</div><div class="stat-label">ลา (ป่วย/กิจ)</div></article>
      <article class="stat-card" style="--accent:#ef4444;--accent-soft:#fff1f2;--i:3"><div class="stat-icon"><?= icon('x-circle', 22) ?></div><div class="stat-value num" data-count="<?= $missDays ?>">0</div><div class="stat-label">ขาด / หนีเรียน</div></article>
    </div>
    <article class="card">
      <div class="card-head bordered">
        <div><h3 class="card-title"><?= icon('calendar', 19) ?> ประวัติการเข้าเรียน</h3><p class="card-sub">30 ระเบียนล่าสุด · รวม <?= number_format($attTotal) ?> ครั้ง</p></div>
        <div class="card-actions"><span class="badge badge-success"><span class="dot"></span><?= number_format($attRate, 1) ?>% มาเรียน</span></div>
      </div>
      <div class="table-wrap" style="border:0;box-shadow:none;border-radius:0">
        <table class="table">
          <thead><tr><th>วันที่</th><th>วัน</th><th>สถานะ</th><th>หมายเหตุ</th></tr></thead>
          <tbody>
            <?php foreach ($recentAttendance as $row): ?>
              <?php $meta = $statusMeta[$row['status']] ?? $statusMeta['present']; ?>
              <tr>
                <td class="text-sm"><?= e(thai_date($row['att_date'], 'short')) ?></td>
                <td class="text-sm text-muted">วัน<?= e(THAI_DAYS[(int) date('w', strtotime($row['att_date']))]) ?></td>
                <td><span class="badge badge-<?= e($badgeClass[$row['status']] ?? 'muted') ?>"><?= e($meta['label']) ?></span></td>
                <td class="text-sm text-muted"><?= e($row['note'] ?: '—') ?></td>
              </tr>
            <?php endforeach; ?>
            <?php if (!$recentAttendance): ?><tr><td colspan="4"><div class="empty-state"><div class="empty-ico"><?= icon('calendar', 28) ?></div><h3>ยังไม่มีประวัติการเข้าเรียน</h3></div></td></tr><?php endif; ?>
          </tbody>
        </table>
      </div>
    </article>
  </div>

  <div class="tab-panel" data-tab-panel="grades" id="tab-grades">
    <div class="gb-summary">
      <div class="gb-stat"><b><?= number_format($gpa, 2) ?></b><span>เกรดเฉลี่ยภาคนี้</span></div>
      <div class="gb-stat"><b><?= count($currentGrades) ?></b><span>รายวิชาภาคนี้</span></div>
      <div class="gb-stat"><b><?= count(array_filter($currentGrades, fn($g) => is_numeric($g['grade']) && (float) $g['grade'] >= 1)) ?></b><span>ผ่านรายวิชา</span></div>
      <div class="gb-stat"><b><?= number_format(array_sum(array_map(fn($g) => is_numeric($g['score']) ? (float) $g['score'] : 0, $currentGrades)) / max(1, count(array_filter($currentGrades, fn($g) => is_numeric($g['score'])))), 1) ?></b><span>คะแนนเฉลี่ย</span></div>
    </div>
    <article class="card">
      <div class="card-head bordered">
        <div><h3 class="card-title"><?= icon('award', 19) ?> ผลการเรียน ปีการศึกษา <?= e($year) ?> ภาคเรียนที่ <?= $semester ?></h3><p class="card-sub">เกณฑ์ผ่านรายวิชา ตั้งแต่ 1.0 ขึ้นไป</p></div>
      </div>
      <div class="table-wrap" style="border:0;box-shadow:none;border-radius:0">
        <table class="table">
          <thead><tr><th>รหัสวิชา</th><th>รายวิชา</th><th class="text-right">หน่วยกิต</th><th class="text-right">คะแนน</th><th class="text-center">เกรด</th></tr></thead>
          <tbody>
            <?php foreach ($currentGrades as $grade): ?>
              <tr>
                <td><span class="doc-no"><?= e($grade['code']) ?></span></td>
                <td><b style="font-weight:600"><?= e($grade['name']) ?></b></td>
                <td class="text-right num"><?= number_format((float) $grade['credits'], 1) ?></td>
                <td class="text-right num"><?= $grade['score'] !== null ? number_format((float) $grade['score'], 1) : '—' ?></td>
                <td class="text-center"><span class="grade-chip <?= $grade['grade'] !== '' ? grade_class($grade['grade']) : 'g0' ?>"><?= e($grade['grade'] ?: '—') ?></span></td>
              </tr>
            <?php endforeach; ?>
            <?php if (!$currentGrades): ?><tr><td colspan="5"><div class="empty-state"><div class="empty-ico"><?= icon('award', 28) ?></div><h3>ยังไม่มีผลการเรียนภาคนี้</h3><p>ผลการเรียนจะแสดงเมื่อครูบันทึกคะแนน</p></div></td></tr><?php endif; ?>
          </tbody>
        </table>
      </div>
    </article>

    <?php if (count($allGrades) > count($currentGrades)): ?>
      <article class="card mt-2">
        <div class="card-head bordered"><div><h3 class="card-title"><?= icon('book', 19) ?> ผลการเรียนย้อนหลัง</h3><p class="card-sub">ทุกปีการศึกษาและภาคเรียน</p></div></div>
        <div class="table-wrap" style="border:0;box-shadow:none;border-radius:0">
          <table class="table">
            <thead><tr><th>ปี / ภาค</th><th>รหัสวิชา</th><th>รายวิชา</th><th class="text-center">เกรด</th></tr></thead>
            <tbody>
              <?php foreach ($allGrades as $grade): ?>
                <tr>
                  <td class="text-sm"><?= e($grade['academic_year']) ?> · ภาค <?= (int) $grade['semester'] ?></td>
                  <td><span class="doc-no"><?= e($grade['code']) ?></span></td>
                  <td class="text-sm"><?= e($grade['name']) ?></td>
                  <td class="text-center"><span class="grade-chip <?= $grade['grade'] !== '' ? grade_class($grade['grade']) : 'g0' ?>"><?= e($grade['grade'] ?: '—') ?></span></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </article>
    <?php endif; ?>
  </div>

  <div class="tab-panel" data-tab-panel="documents" id="tab-documents">
    <article class="card">
      <div class="card-head bordered">
        <div><h3 class="card-title"><?= icon('file', 19) ?> เอกสารทางการศึกษา</h3><p class="card-sub">เอกสาร ปพ. ที่ออกให้กับนักเรียนแล้ว</p></div>
        <div class="card-actions"><span class="badge badge-brand"><?= count($documents) ?> ฉบับ</span></div>
      </div>
      <div class="card-body">
        <?php if ($documents): ?>
          <div class="stack" style="gap:10px">
            <?php foreach ($documents as $doc): ?>
              <?php $type = doc_type($doc['doc_type']); ?>
              <div class="row-between wrap" style="padding:12px 14px;border-radius:12px;background:#f8faff;border:1px solid #eef1f9">
                <div class="row" style="gap:12px;min-width:0">
                  <span class="q-ico" style="display:grid;place-items:center;width:40px;height:40px;border-radius:11px;background:var(--brand-soft);color:var(--brand)"><?= icon($type['icon'], 19) ?></span>
                  <span style="min-width:0">
                    <b style="display:block;font-size:.84rem"><?= e($type['label']) ?> · <?= e($type['name']) ?></b>
                    <small class="text-muted" style="font-size:.71rem"><?= e($doc['doc_no']) ?> · ออกเมื่อ <?= e(thai_date($doc['issued_at'], 'short')) ?></small>
                  </span>
                </div>
                <a class="btn btn-ghost btn-sm" href="<?= url('document-print.php?id=' . (int) $doc['id']) ?>" target="_blank" rel="noopener"><?= icon('printer', 14) ?> เปิดเอกสาร</a>
              </div>
            <?php endforeach; ?>
          </div>
        <?php else: ?>
          <div class="empty-state"><div class="empty-ico"><?= icon('file', 30) ?></div><h3>ยังไม่มีเอกสาร</h3><p>เมื่อโรงเรียนออกเอกสาร ปพ. เอกสารจะแสดงที่นี่</p></div>
        <?php endif; ?>
      </div>
    </article>
  </div>
</section>

<?php require __DIR__ . '/includes/student-portal-bottom.php'; ?>
