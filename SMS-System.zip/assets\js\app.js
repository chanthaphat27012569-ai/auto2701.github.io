/* ============================================================
   SMS School · UI interactions
   ============================================================ */
(function () {
  'use strict';

  var reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var SMS = window.SMS = window.SMS || {};

  function $(selector, root) { return (root || document).querySelector(selector); }
  function $$(selector, root) { return Array.prototype.slice.call((root || document).querySelectorAll(selector)); }

  /* ---------- page progress ---------- */
  var progress = $('#pageProgress');
  if (progress) {
    requestAnimationFrame(function () { progress.style.width = '72%'; });
    window.addEventListener('load', function () {
      progress.style.width = '100%';
      setTimeout(function () { progress.style.opacity = '0'; }, 450);
    });
    document.addEventListener('click', function (e) {
      var link = e.target.closest && e.target.closest('a[href]');
      if (!link || link.target === '_blank' || link.hasAttribute('download')) return;
      var href = link.getAttribute('href') || '';
      if (!href || href.charAt(0) === '#' || href.indexOf('javascript:') === 0) return;
      if (link.origin && link.origin !== window.location.origin) return;
      progress.style.opacity = '1';
      progress.style.width = '38%';
    });
  }

  /* ---------- sidebar ---------- */
  var sidebar = $('#sidebar');
  var overlay = $('#sidebarOverlay');
  function closeSidebar() {
    if (!sidebar) return;
    sidebar.classList.remove('is-open');
    if (overlay) overlay.classList.remove('is-open');
    document.body.style.overflow = '';
  }
  function openSidebar() {
    if (!sidebar) return;
    sidebar.classList.add('is-open');
    if (overlay) overlay.classList.add('is-open');
    document.body.style.overflow = 'hidden';
  }
  var toggle = $('#sidebarToggle');
  if (toggle) toggle.addEventListener('click', function () { openSidebar(); });
  var closeBtn = $('#sidebarClose');
  if (closeBtn) closeBtn.addEventListener('click', closeSidebar);
  if (overlay) overlay.addEventListener('click', closeSidebar);
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeSidebar(); });

  /* ---------- user menu ---------- */
  var userMenu = $('#userMenu');
  var userToggle = $('#userMenuToggle');
  if (userMenu && userToggle) {
    userToggle.addEventListener('click', function (e) {
      e.stopPropagation();
      var open = userMenu.classList.toggle('open');
      userToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
    document.addEventListener('click', function (e) {
      if (!userMenu.contains(e.target)) {
        userMenu.classList.remove('open');
        userToggle.setAttribute('aria-expanded', 'false');
      }
    });
  }

  /* ---------- toasts ---------- */
  function dismissToast(toast) {
    if (!toast || toast.classList.contains('is-out')) return;
    toast.classList.add('is-out');
    setTimeout(function () { toast.remove(); }, 320);
  }
  function showToast(message, type) {
    var stack = $('#toastStack');
    if (!stack) return;
    var icons = {
      success: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.1V12a10 10 0 1 1-5.93-9.14"/><path d="m9 11 3 3L22 4"/></svg>',
      danger: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="m15 9-6 6M9 9l6 6"/></svg>',
      warning: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0Z"/><path d="M12 9v4M12 17h.01"/></svg>',
      info: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/></svg>'
    };
    var toast = document.createElement('div');
    toast.className = 'toast toast-' + (type || 'info');
    toast.setAttribute('data-toast', '');
    toast.innerHTML = '<span class="toast-icon">' + (icons[type] || icons.info) + '</span>' +
      '<p></p><button type="button" class="toast-close" data-toast-close aria-label="ปิด">×</button><span class="toast-timer"></span>';
    toast.querySelector('p').textContent = message;
    stack.appendChild(toast);
    toast.querySelector('[data-toast-close]').addEventListener('click', function () { dismissToast(toast); });
    setTimeout(function () { dismissToast(toast); }, 5000);
  }
  SMS.toast = showToast;
  $$('[data-toast]').forEach(function (toast) {
    var close = toast.querySelector('[data-toast-close]');
    if (close) close.addEventListener('click', function () { dismissToast(toast); });
    setTimeout(function () { dismissToast(toast); }, 5200);
  });

  /* ---------- confirm modal ---------- */
  var modal = $('#confirmModal');
  var pendingForm = null;
  if (modal) {
    var modalText = $('#confirmText');
    var modalOk = $('#confirmOk');
    $$('form[data-confirm]').forEach(function (form) {
      form.addEventListener('submit', function (e) {
        if (form.getAttribute('data-confirmed') === '1') return;
        e.preventDefault();
        pendingForm = form;
        var msg = form.getAttribute('data-confirm') || 'ต้องการดำเนินการต่อหรือไม่';
        if (modalText) modalText.textContent = msg;
        modal.classList.add('is-open');
        modal.setAttribute('aria-hidden', 'false');
        setTimeout(function () { if (modalOk) modalOk.focus(); }, 120);
      });
    });
    function closeModal() {
      modal.classList.remove('is-open');
      modal.setAttribute('aria-hidden', 'true');
      pendingForm = null;
    }
    $$('[data-modal-close]', modal).forEach(function (el) { el.addEventListener('click', closeModal); });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && modal.classList.contains('is-open')) closeModal();
    });
    if (modalOk) {
      modalOk.addEventListener('click', function () {
        if (!pendingForm) return;
        var form = pendingForm;
        form.setAttribute('data-confirmed', '1');
        modal.classList.remove('is-open');
        modal.setAttribute('aria-hidden', 'true');
        pendingForm = null;
        HTMLFormElement.prototype.submit.call(form);
      });
    }
  }

  /* ---------- tabs ---------- */
  $$('[data-tab-group]').forEach(function (group) {
    var buttons = $$('[data-tab]', group);
    var panelsRoot = group.parentElement;
    function activate(name) {
      buttons.forEach(function (btn) {
        btn.classList.toggle('is-active', btn.getAttribute('data-tab') === name);
        btn.setAttribute('aria-selected', btn.getAttribute('data-tab') === name ? 'true' : 'false');
      });
      $$('[data-tab-panel]', panelsRoot).forEach(function (panel) {
        panel.classList.toggle('is-active', panel.getAttribute('data-tab-panel') === name);
      });
    }
    buttons.forEach(function (btn) {
      btn.addEventListener('click', function () { activate(btn.getAttribute('data-tab')); });
    });
  });

  /* ---------- password toggle ---------- */
  $$('[data-pwd-toggle]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var input = document.getElementById(btn.getAttribute('data-pwd-toggle'));
      if (!input) return;
      var show = input.type === 'password';
      input.type = show ? 'text' : 'password';
      btn.classList.toggle('is-on', show);
      btn.setAttribute('aria-label', show ? 'ซ่อนรหัสผ่าน' : 'แสดงรหัสผ่าน');
    });
  });

  /* ---------- login tabs ---------- */
  $$('[data-auth-tab]').forEach(function (tab) {
    tab.addEventListener('click', function () {
      var name = tab.getAttribute('data-auth-tab');
      $$('[data-auth-tab]').forEach(function (t) {
        t.classList.toggle('is-active', t === tab);
        t.setAttribute('aria-selected', t === tab ? 'true' : 'false');
      });
      $$('[data-auth-panel]').forEach(function (panel) {
        panel.classList.toggle('hidden', panel.getAttribute('data-auth-panel') !== name);
      });
      var focusEl = document.querySelector('[data-auth-panel="' + name + '"] input');
      if (focusEl) setTimeout(function () { focusEl.focus(); }, 100);
    });
  });
  $$('[data-demo-user]').forEach(function (chip) {
    chip.addEventListener('click', function () {
      var user = document.getElementById('loginUsername');
      var pass = document.getElementById('loginPassword');
      if (user) user.value = chip.getAttribute('data-demo-user');
      if (pass) pass.value = '1234';
      var tab = document.querySelector('[data-auth-tab="staff"]');
      if (tab) tab.click();
    });
  });
  $$('[data-demo-student]').forEach(function (chip) {
    chip.addEventListener('click', function () {
      var code = document.getElementById('studentCode');
      var pin = document.getElementById('studentPin');
      if (code) code.value = chip.getAttribute('data-demo-student');
      if (pin) pin.value = chip.getAttribute('data-demo-pin') || chip.getAttribute('data-demo-student');
      var tab = document.querySelector('[data-auth-tab="student"]');
      if (tab) tab.click();
    });
  });

  /* ---------- counters ---------- */
  function formatNumber(value, decimals) {
    return Number(value).toLocaleString('th-TH', { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
  }
  $$('[data-count]').forEach(function (el) {
    var target = parseFloat(el.getAttribute('data-count')) || 0;
    var decimals = parseInt(el.getAttribute('data-decimals') || '0', 10);
    var suffix = el.getAttribute('data-suffix') || '';
    if (reduceMotion) {
      el.textContent = formatNumber(target, decimals) + suffix;
      return;
    }
    var duration = 1100;
    var start = performance.now();
    function tick(now) {
      var p = Math.min(1, (now - start) / duration);
      var eased = 1 - Math.pow(1 - p, 3);
      el.textContent = formatNumber(target * eased, decimals) + suffix;
      if (p < 1) requestAnimationFrame(tick);
    }
    requestAnimationFrame(tick);
  });

  /* ---------- meters & donuts ---------- */
  setTimeout(function () {
    $$('[data-meter]').forEach(function (el) {
      el.style.width = Math.max(0, Math.min(100, parseFloat(el.getAttribute('data-meter')) || 0)) + '%';
    });
    $$('[data-donut]').forEach(function (el) {
      var p = Math.max(0, Math.min(100, parseFloat(el.getAttribute('data-donut')) || 0));
      var circumference = 2 * Math.PI * 48;
      el.style.strokeDasharray = circumference;
      el.style.strokeDashoffset = circumference * (1 - p / 100);
    });
  }, 180);

  /* ---------- attendance ---------- */
  var roster = $('#attRoster');
  if (roster) {
    var countEls = $$('[data-att-count]');
    var updateCounts = function () {
      var counts = { present: 0, late: 0, sick: 0, business: 0, absent: 0, truant: 0 };
      $$('.att-row', roster).forEach(function (row) {
        var checked = row.querySelector('input[type="radio"]:checked');
        if (checked && counts[checked.value] !== undefined) counts[checked.value]++;
      });
      countEls.forEach(function (el) {
        var key = el.getAttribute('data-att-count');
        el.textContent = counts[key] || 0;
      });
      var total = Object.keys(counts).reduce(function (sum, key) { return sum + counts[key]; }, 0);
      var rate = total ? Math.round(((counts.present + counts.late) / total) * 1000) / 10 : 0;
      var rateEl = $('[data-att-rate]');
      if (rateEl) rateEl.textContent = rate.toFixed(1) + '%';
      var totalEl = $('[data-att-total]');
      if (totalEl) totalEl.textContent = total;
      $$('[data-att-donut]').forEach(function (el) {
        var circ = 2 * Math.PI * 48;
        el.style.strokeDasharray = circ;
        el.style.strokeDashoffset = circ * (1 - rate / 100);
      });
    };
    roster.addEventListener('change', function (e) {
      if (e.target.matches('input[type="radio"]')) updateCounts();
    });
    $$('[data-mark-all]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var value = btn.getAttribute('data-mark-all');
        $$('.att-row', roster).forEach(function (row) {
          var input = row.querySelector('input[type="radio"][value="' + value + '"]');
          if (input) input.checked = true;
        });
        updateCounts();
        showToast('ตั้งสถานะทุกคนเป็น "' + btn.getAttribute('data-label') + '" แล้ว', 'info');
      });
    });
    var rowSearch = $('#attSearch');
    if (rowSearch) {
      rowSearch.addEventListener('input', function () {
        var q = rowSearch.value.trim().toLowerCase();
        $$('.att-row', roster).forEach(function (row) {
          row.style.display = !q || (row.textContent || '').toLowerCase().indexOf(q) !== -1 ? '' : 'none';
        });
      });
    }
    updateCounts();
  }

  /* ---------- gradebook ---------- */
  var gradeTable = $('#gradeTable');
  if (gradeTable) {
    var gradeFromScore = function (score) {
      if (score === '' || isNaN(score)) return '—';
      score = Number(score);
      if (score >= 80) return '4.0';
      if (score >= 75) return '3.5';
      if (score >= 70) return '3.0';
      if (score >= 65) return '2.5';
      if (score >= 60) return '2.0';
      if (score >= 55) return '1.5';
      if (score >= 50) return '1.0';
      return '0.0';
    };
    var gradeClass = function (grade) {
      return ({ '4.0': 'g4', '3.5': 'g35', '3.0': 'g3', '2.5': 'g25', '2.0': 'g2', '1.5': 'g15', '1.0': 'g1', '0.0': 'g0' })[grade] || 'g0';
    };
    var updateGrades = function () {
      var total = 0;
      var count = 0;
      var dist = { '4.0': 0, '3.5': 0, '3.0': 0, '2.5': 0, '2.0': 0, '1.5': 0, '1.0': 0, '0.0': 0 };
      $$('input[data-grade-input]', gradeTable).forEach(function (input) {
        var chip = input.closest('tr').querySelector('[data-grade-chip]');
        var grade = gradeFromScore(input.value);
        if (chip) {
          chip.textContent = grade;
          chip.className = 'grade-chip grade-live ' + gradeClass(grade);
        }
        if (input.value !== '' && !isNaN(input.value)) {
          total += Number(input.value);
          count++;
          if (dist[grade] !== undefined) dist[grade]++;
        }
      });
      var avgEl = $('#gbAverage');
      if (avgEl) avgEl.textContent = count ? (total / count).toFixed(1) : '—';
      Object.keys(dist).forEach(function (grade) {
        var el = document.querySelector('[data-dist="' + grade + '"]');
        if (el) el.textContent = dist[grade];
      });
    };
    gradeTable.addEventListener('input', function (e) {
      if (e.target.matches('input[data-grade-input]')) updateGrades();
    });
    updateGrades();
    var fillDefault = $('[data-fill-score]');
    if (fillDefault) {
      fillDefault.addEventListener('click', function () {
        var value = prompt('กรอกคะแนนที่ต้องการใช้กับทุกคน (0-100)', '80');
        if (value === null) return;
        var num = Math.max(0, Math.min(100, Number(value) || 0));
        $$('input[data-grade-input]', gradeTable).forEach(function (input) { input.value = num; });
        updateGrades();
        showToast('ใส่คะแนน ' + num + ' ให้ทุกคนแล้ว', 'info');
      });
    }
  }

  /* ---------- client table filter ---------- */
  $$('[data-table-search]').forEach(function (input) {
    var target = document.querySelector(input.getAttribute('data-table-search'));
    if (!target) return;
    input.addEventListener('input', function () {
      var q = input.value.trim().toLowerCase();
      $$('tbody tr', target).forEach(function (row) {
        if (row.hasAttribute('data-empty-row')) return;
        row.style.display = !q || (row.textContent || '').toLowerCase().indexOf(q) !== -1 ? '' : 'none';
      });
    });
  });

  /* ---------- auto submit selects ---------- */
  $$('[data-auto-submit]').forEach(function (el) {
    el.addEventListener('change', function () { if (el.form) el.form.submit(); });
  });

  /* ---------- print ---------- */
  $$('[data-print]').forEach(function (btn) {
    btn.addEventListener('click', function () { window.print(); });
  });

  /* ---------- ripple ---------- */
  if (!reduceMotion) {
    document.addEventListener('click', function (e) {
      var btn = e.target.closest && e.target.closest('.btn');
      if (!btn || btn.disabled) return;
      var rect = btn.getBoundingClientRect();
      var ripple = document.createElement('span');
      var size = Math.max(rect.width, rect.height);
      ripple.style.cssText = 'position:absolute;border-radius:50%;pointer-events:none;background:rgba(255,255,255,.35);width:' + size + 'px;height:' + size + 'px;left:' + (e.clientX - rect.left - size / 2) + 'px;top:' + (e.clientY - rect.top - size / 2) + 'px;transform:scale(0);opacity:1;transition:transform .55s ease,opacity .6s ease;';
      btn.appendChild(ripple);
      requestAnimationFrame(function () {
        ripple.style.transform = 'scale(2.6)';
        ripple.style.opacity = '0';
      });
      setTimeout(function () { ripple.remove(); }, 650);
    });
  }

  /* ---------- phone input formatting ---------- */
  $$('input[data-phone]').forEach(function (input) {
    input.addEventListener('input', function () {
      var digits = input.value.replace(/\D/g, '').slice(0, 10);
      if (digits.length > 3) digits = digits.slice(0, 3) + '-' + digits.slice(3, 6);
      if (digits.length > 7) digits = digits.slice(0, 7) + '-' + digits.slice(7);
      input.value = digits;
    });
  });
})();
