<?php

require_once __DIR__ . '/includes/bootstrap.php';

$portalActive = 'password';
$pageTitle = 'เปลี่ยนรหัสผ่าน';
$pageSubtitle = 'ตั้งรหัสผ่านใหม่สำหรับเข้าพอร์ทัลนักเรียน';
require __DIR__ . '/includes/student-context.php';

$studentId = (int) $student['id'];
$portalTablesReady = portal_tables_ready();
$errors = [];

if (is_post() && post_str('action') === 'change_password') {
    verify_csrf();

    if ($isPreview) {
        flash('warning', 'โหมดตัวอย่างไม่สามารถเปลี่ยนรหัสผ่านได้');
        redirect('student-password.php');
    }

    $currentPin = post_str('current_pin');
    $newPin = post_str('new_pin');
    $confirmPin = post_str('confirm_pin');

    if ($currentPin === '') {
        $errors[] = 'กรุณากรอกรหัสผ่านปัจจุบัน';
    }
    if (!preg_match('/^\d{4,10}$/', $newPin)) {
        $errors[] = 'รหัสผ่านใหม่ต้องเป็นตัวเลข 4–10 หลัก';
    }
    if ($newPin !== $confirmPin) {
        $errors[] = 'รหัสผ่านใหม่และยืนยันรหัสผ่านไม่ตรงกัน';
    }
    if ($newPin !== '' && $newPin === $currentPin) {
        $errors[] = 'รหัสผ่านใหม่ต้องไม่ซ้ำกับรหัสผ่านปัจจุบัน';
    }
    if (!$portalTablesReady) {
        $errors[] = 'ระบบยังไม่พร้อมใช้งาน กรุณาให้เจ้าหน้าที่นำเข้า student-portal.sql';
    }

    if (!$errors) {
        $profileRow = student_profile($studentId, true);
        $storedHash = (string) ($profileRow['portal_hash'] ?? '');
        $plainPin = (string) ($student['portal_pin'] ?? '');

        $currentValid = $storedHash !== ''
            ? password_verify($currentPin, $storedHash)
            : ($plainPin !== '' && hash_equals($plainPin, $currentPin));

        if (!$currentValid) {
            $errors[] = 'รหัสผ่านปัจจุบันไม่ถูกต้อง';
        }
    }

    if (!$errors) {
        try {
            $pdo->beginTransaction();
            $ensureStmt = $pdo->prepare('INSERT INTO student_profiles (student_id) VALUES (?) ON DUPLICATE KEY UPDATE student_id = student_id');
            $ensureStmt->execute([$studentId]);
            $updateStmt = $pdo->prepare('UPDATE student_profiles SET portal_hash = ? WHERE student_id = ?');
            $updateStmt->execute([password_hash($newPin, PASSWORD_DEFAULT), $studentId]);
            $clearStmt = $pdo->prepare('UPDATE students SET portal_pin = "" WHERE id = ?');
            $clearStmt->execute([$studentId]);
            $pdo->commit();

            flash('success', 'เปลี่ยนรหัสผ่านเรียบร้อยแล้ว กรุณาใช้รหัสผ่านใหม่ในการเข้าสู่ระบบครั้งถัดไป');
            redirect('student-password.php');
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $errors[] = 'ไม่สามารถบันทึกรหัสผ่านใหม่ได้ กรุณาลองใหม่อีกครั้ง';
        }
    }

    if ($errors) {
        foreach ($errors as $message) {
            flash('danger', $message);
        }
        redirect('student-password.php');
    }
}

$hasHashedPin = trim((string) ($profile['portal_hash'] ?? '')) !== '';
$hasPlainPin = trim((string) ($student['portal_pin'] ?? '')) !== '';

require __DIR__ . '/includes/student-portal-top.php';
?>

<div class="page-heading">
  <div>
    <span class="hero-kicker dark"><?= icon('key', 15) ?> ความปลอดภัยของบัญชี</span>
    <h1>เปลี่ยนรหัสผ่าน</h1>
    <p>รหัสผ่านใช้สำหรับเข้าสู่พอร์ทัลนักเรียน · <?= e(student_name($student, false)) ?></p>
  </div>
  <span class="badge badge-<?= $hasHashedPin ? 'success' : 'warning' ?>"><span class="dot"></span><?= $hasHashedPin ? 'ตั้งรหัสผ่านแล้ว' : 'ใช้รหัสผ่านเริ่มต้น' ?></span>
</div>

<?php if (!$portalTablesReady): ?>
  <div class="notice notice-warning mb-2"><?= icon('alert', 18) ?><div><strong>ยังไม่สามารถเปลี่ยนรหัสผ่านได้</strong><br>กรุณาให้เจ้าหน้าที่นำเข้าไฟล์ <code>database/student-portal.sql</code> ก่อนใช้งานระบบรหัสผ่าน</div></div>
<?php endif; ?>

<?php if ($isPreview): ?>
  <div class="notice notice-info mb-2"><?= icon('eye', 18) ?><div>โหมดตัวอย่างสำหรับเจ้าหน้าที่ — ไม่สามารถเปลี่ยนรหัสผ่านแทนนักเรียนได้</div></div>
<?php endif; ?>

<div class="grid grid-1-2">
  <div class="stack">
    <article class="card">
      <div class="card-body" style="text-align:center">
        <?= student_avatar($student, 'lg') ?>
        <h3 style="margin-top:12px;font-weight:800"><?= e(student_name($student)) ?></h3>
        <p class="text-sm text-muted">รหัสนักเรียน <?= e($student['student_code']) ?> · <?= e($classText ?: 'ไม่ระบุชั้นเรียน') ?></p>
        <div class="profile-chips" style="justify-content:center;margin-top:12px">
          <span class="chip"><?= icon('user', 13) ?> <?= e($statusOfStudent['label']) ?></span>
          <span class="chip"><?= icon('lock', 13) ?> <?= $hasHashedPin ? 'เข้ารหัสแล้ว' : 'รหัสเริ่มต้น' ?></span>
        </div>
      </div>
    </article>

    <article class="card">
      <div class="card-head"><div><h3 class="card-title"><?= icon('shield', 19) ?> คำแนะนำด้านความปลอดภัย</h3></div></div>
      <div class="card-body" style="padding-top:8px">
        <div class="stack" style="gap:10px">
          <div class="security-tip"><?= icon('check-circle', 16) ?><span>ใช้ตัวเลข 4–10 หลักที่จำได้ง่าย แต่ผู้อื่นคาดเดาไม่ได้</span></div>
          <div class="security-tip"><?= icon('check-circle', 16) ?><span>ไม่บอกหรือแชร์รหัสผ่านให้ผู้อื่น รวมถึงเพื่อนสนิท</span></div>
          <div class="security-tip"><?= icon('check-circle', 16) ?><span>เปลี่ยนรหัสผ่านทันทีหากสงสัยว่ามีผู้อื่นทราบ</span></div>
          <div class="security-tip"><?= icon('info', 16, 'tip-info') ?><span>หากลืมรหัสผ่าน กรุณาติดต่อครูที่ปรึกษาหรือฝ่ายทะเบียน</span></div>
        </div>
      </div>
    </article>
  </div>

  <article class="card">
    <div class="card-head bordered">
      <div><h3 class="card-title"><?= icon('key', 19) ?> ตั้งรหัสผ่านใหม่</h3><p class="card-sub">กรอกรหัสผ่านปัจจุบันเพื่อยืนยันตัวตน</p></div>
      <div class="card-actions"><?= icon('lock', 18) ?></div>
    </div>
    <div class="card-body">
      <?php foreach ($errors as $message): ?>
        <div class="notice notice-danger" style="margin-bottom:12px"><?= icon('alert', 17) ?><div><?= e($message) ?></div></div>
      <?php endforeach; ?>

      <form method="post" action="<?= e(portal_url('student-password.php')) ?>" autocomplete="off">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="change_password">

        <div class="stack" style="gap:16px">
          <div class="field">
            <label for="currentPin">รหัสผ่านปัจจุบัน <span class="req">*</span></label>
            <div class="pwd-field">
              <?= icon('lock', 17) ?>
              <input class="input" id="currentPin" type="password" name="current_pin" inputmode="numeric" pattern="[0-9]{4,10}" maxlength="10" placeholder="กรอกรหัสผ่านปัจจุบัน" autocomplete="current-password" required style="padding-right:44px">
              <button type="button" class="pwd-toggle" data-pwd-toggle="currentPin" aria-label="แสดงรหัสผ่าน"><?= icon('eye', 17) ?></button>
            </div>
            <?php if (!$hasHashedPin && $hasPlainPin): ?><small class="text-muted">รหัสผ่านเริ่มต้นคือรหัสนักเรียนของฉัน</small><?php endif; ?>
          </div>

          <div class="field">
            <label for="newPin">รหัสผ่านใหม่ <span class="req">*</span></label>
            <div class="pwd-field">
              <?= icon('key', 17) ?>
              <input class="input" id="newPin" type="password" name="new_pin" inputmode="numeric" pattern="[0-9]{4,10}" maxlength="10" placeholder="ตัวเลข 4–10 หลัก" autocomplete="new-password" required style="padding-right:44px">
              <button type="button" class="pwd-toggle" data-pwd-toggle="newPin" aria-label="แสดงรหัสผ่าน"><?= icon('eye', 17) ?></button>
            </div>
            <div class="pin-strength" id="pinStrength" aria-hidden="true"><span></span><span></span><span></span><span></span></div>
            <small class="text-muted">ใช้ตัวเลข 4–10 หลัก และไม่ซ้ำกับรหัสผ่านปัจจุบัน</small>
          </div>

          <div class="field">
            <label for="confirmPin">ยืนยันรหัสผ่านใหม่ <span class="req">*</span></label>
            <div class="pwd-field">
              <?= icon('shield', 17) ?>
              <input class="input" id="confirmPin" type="password" name="confirm_pin" inputmode="numeric" pattern="[0-9]{4,10}" maxlength="10" placeholder="กรอกรหัสผ่านใหม่อีกครั้ง" autocomplete="new-password" required style="padding-right:44px">
              <button type="button" class="pwd-toggle" data-pwd-toggle="confirmPin" aria-label="แสดงรหัสผ่าน"><?= icon('eye', 17) ?></button>
            </div>
          </div>

          <div class="row" style="gap:10px;flex-wrap:wrap">
            <button type="submit" class="btn btn-primary" <?= (!$portalTablesReady || $isPreview) ? 'disabled' : '' ?>><?= icon('save', 17) ?> บันทึกรหัสผ่านใหม่</button>
            <a class="btn btn-ghost" href="<?= e(portal_url('portal.php')) ?>"><?= icon('arrow-left', 16) ?> กลับหน้าหลัก</a>
          </div>
        </div>
      </form>
    </div>
  </article>
</div>

<script>
  (function () {
    var input = document.getElementById('newPin');
    var meter = document.getElementById('pinStrength');
    if (!input || !meter) return;
    var bars = meter.querySelectorAll('span');
    input.addEventListener('input', function () {
      var value = input.value.replace(/\D/g, '');
      var score = value.length >= 8 ? 4 : value.length >= 6 ? 3 : value.length >= 5 ? 2 : value.length >= 4 ? 1 : 0;
      bars.forEach(function (bar, index) {
        bar.style.background = index < score
          ? ['#ef4444', '#f59e0b', '#3b82f6', '#10b981'][Math.max(0, score - 1)]
          : '#e2e8f0';
      });
      meter.classList.toggle('is-on', score > 0);
    });
  })();
</script>

<?php require __DIR__ . '/includes/student-portal-bottom.php'; ?>
