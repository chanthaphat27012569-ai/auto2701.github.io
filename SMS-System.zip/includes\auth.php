<?php

function staff_login(string $username, string $password): ?array
{
    $stmt = db()->prepare('SELECT * FROM users WHERE username = ? AND status = "active" LIMIT 1');
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($password, $user['password_hash'])) {
        return null;
    }

    session_regenerate_id(true);
    $_SESSION['staff'] = [
        'id' => (int) $user['id'],
        'username' => $user['username'],
        'fullname' => $user['fullname'],
        'role' => $user['role'],
        'position' => $user['position'],
        'department' => $user['department'],
    ];
    unset($_SESSION['student_id']);

    $update = db()->prepare('UPDATE users SET last_login = NOW() WHERE id = ?');
    $update->execute([(int) $user['id']]);

    return $user;
}

function student_login(string $studentCode, string $pin): ?array
{
    $stmt = db()->prepare('SELECT * FROM students WHERE student_code = ? AND status IN ("studying","graduated") LIMIT 1');
    $stmt->execute([$studentCode]);
    $student = $stmt->fetch();

    if (!$student) {
        return null;
    }

    $profile = student_profile((int) $student['id']);
    $hash = (string) ($profile['portal_hash'] ?? '');
    $valid = $hash !== ''
        ? password_verify($pin, $hash)
        : hash_equals((string) $student['portal_pin'], $pin);

    if (!$valid) {
        return null;
    }

    session_regenerate_id(true);
    $_SESSION['student_id'] = (int) $student['id'];
    unset($_SESSION['staff']);

    return $student;
}

function current_staff(): ?array
{
    return $_SESSION['staff'] ?? null;
}

function current_student(): ?array
{
    $id = (int) ($_SESSION['student_id'] ?? 0);
    if ($id <= 0) {
        return null;
    }
    static $student = null;
    if ($student && (int) $student['id'] === $id) {
        return $student;
    }
    $stmt = db()->prepare('SELECT s.*, c.name AS class_name, c.level, c.level_short, c.room
        FROM students s LEFT JOIN classes c ON c.id = s.class_id WHERE s.id = ? LIMIT 1');
    $stmt->execute([$id]);
    $student = $stmt->fetch() ?: null;
    if ($student) {
        $student['profile'] = student_profile($id);
        $student['avatar'] = (string) ($student['profile']['avatar'] ?? '');
    }
    return $student;
}

function require_staff(): array
{
    $user = current_staff();
    if (!$user) {
        flash('warning', 'กรุณาเข้าสู่ระบบก่อนใช้งาน');
        redirect('login.php');
    }
    return $user;
}

function require_student(): array
{
    $student = current_student();
    if (!$student) {
        flash('warning', 'กรุณาเข้าสู่ระบบด้วยรหัสนักเรียน');
        redirect('login.php?tab=student');
    }
    return $student;
}

function is_admin(): bool
{
    $user = current_staff();
    return $user && in_array($user['role'], ['admin', 'director'], true);
}

function can_manage(): bool
{
    $user = current_staff();
    return $user && in_array($user['role'], ['admin', 'director', 'deputy', 'registrar'], true);
}

function require_admin(): void
{
    require_staff();
    if (!is_admin()) {
        flash('danger', 'คุณไม่มีสิทธิ์เข้าถึงหน้านี้');
        redirect('dashboard.php');
    }
}

function require_manage(): void
{
    require_staff();
    if (!can_manage()) {
        flash('danger', 'คุณไม่มีสิทธิ์แก้ไขข้อมูลส่วนนี้');
        redirect('dashboard.php');
    }
}

function logout_staff(): void
{
    unset($_SESSION['staff']);
    session_regenerate_id(true);
}

function logout_student(): void
{
    unset($_SESSION['student_id']);
    session_regenerate_id(true);
}
